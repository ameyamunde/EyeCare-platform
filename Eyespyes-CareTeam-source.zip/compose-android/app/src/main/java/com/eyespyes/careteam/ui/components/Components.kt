@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.eyespyes.careteam.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eyespyes.careteam.data.model.Patient
import com.eyespyes.careteam.data.model.Refraction
import com.eyespyes.careteam.data.model.Visit
import com.eyespyes.careteam.ui.theme.*
import java.time.LocalDate
import java.time.Period
import kotlin.math.abs

fun dio(v: Double?): String = when { v == null -> "—"; v > 0 -> "+%.2f".format(v); v < 0 -> "−%.2f".format(abs(v)); else -> "0.00" }
fun rxText(r: Refraction?): String = if (r == null) "—" else dio(r.sph) + (if (r.cyl != 0.0) " / ${dio(r.cyl)} × ${r.axis ?: 0}°" else " DS") + (if (r.add != 0.0) " Add ${dio(r.add)}" else "")
fun ageOf(dob: String): Int = runCatching { Period.between(LocalDate.parse(dob), LocalDate.now()).years }.getOrDefault(0)

/** Patient banner on every clinical screen (CT-02-05) */
@Composable
fun PatientBanner(p: Patient, token: Int? = null) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                token?.let { Pill("Token $it", Brand) }
            }
            Text("${ageOf(p.dob)} y · ${p.sex} · ${p.uhid} · ${p.phone}", style = MaterialTheme.typography.bodySmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                p.allergies.forEach { Pill("Allergy: $it", OdRed) }
                if (p.diabetic) Pill("Diabetic", Warn)
                if (p.glaucoma) Pill("Glaucoma", OsBlue)
            }
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.12f), contentColor = color, shape = RoundedCornerShape(10.dp)) {
        Text(text, Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Stepper for dioptres / axis / IOP (CT-04-04): no keyboard, 48 dp targets.
 * [deviceImported] outlines values that came from a device until confirmed (CT-04-12).
 */
@Composable
fun Stepper(label: String, value: Double?, step: Double, min: Double, max: Double, format: (Double?) -> String = ::dio, deviceImported: Boolean = false, onChange: (Double) -> Unit) {
    OutlinedCard(border = BorderStroke(if (deviceImported) 2.dp else 1.dp, if (deviceImported) Warn else MaterialTheme.colorScheme.outlineVariant), modifier = Modifier.padding(vertical = 3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onChange(((value ?: 0.0) - step).coerceIn(min, max)) }, modifier = Modifier.semantics { contentDescription = "Decrease $label" }) { Icon(Icons.Default.Remove, null) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, style = MaterialTheme.typography.labelSmall)
                Text(format(value), fontWeight = FontWeight.SemiBold)
            }
            IconButton(onClick = { onChange(((value ?: 0.0) + step).coerceIn(min, max)) }, modifier = Modifier.semantics { contentDescription = "Increase $label" }) { Icon(Icons.Default.Add, null) }
        }
    }
}

/** OD (right, red) and OS (left, blue) side by side — right eye on the left, as the clinician faces the patient */
@Composable
fun EyeColumns(od: @Composable ColumnScope.() -> Unit, os: @Composable ColumnScope.() -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f).background(OdSoft, RoundedCornerShape(10.dp)).padding(8.dp)) { Text("OD · Right", color = OdRed, fontWeight = FontWeight.Bold); od() }
        Column(Modifier.weight(1f).background(OsSoft, RoundedCornerShape(10.dp)).padding(8.dp)) { Text("OS · Left", color = OsBlue, fontWeight = FontWeight.Bold); os() }
    }
}

@Composable
fun QueueCard(v: Visit, waitMinutes: Long, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Brand, contentColor = Color.White, shape = RoundedCornerShape(10.dp), modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("${v.token}", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(v.patient.name, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill(v.stage.label, Brand)
                    Text("$waitMinutes min in stage", style = MaterialTheme.typography.bodySmall, color = if (waitMinutes >= 60) OdRed else if (waitMinutes >= 30) Warn else Ok)
                }
            }
        }
    }
}
