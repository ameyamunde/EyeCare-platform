package com.eyespyes.careteam.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import com.eyespyes.careteam.R
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.eyespyes.careteam.data.mock.MockRepository
import com.eyespyes.careteam.data.model.*
import com.eyespyes.careteam.ui.components.*
import com.eyespyes.careteam.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(vm: SessionViewModel, mock: MockRepository?) {
    var phone by remember { mutableStateOf("9000000002") }
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Image(painterResource(R.drawable.eyespyes_logo), contentDescription = "Eyespyes", modifier = Modifier.height(96.dp).align(Alignment.CenterHorizontally))
        Text("Care Team", style = MaterialTheme.typography.titleMedium, color = Brand, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Demo build · fictional data · PIN 1234", style = MaterialTheme.typography.bodySmall)
        mock?.demoUsers?.forEach { u ->
            OutlinedButton(onClick = { mock.loginAs(u.id) }, modifier = Modifier.fillMaxWidth()) { Text("${u.name} — ${u.roles.joinToString { it.label }}") }
        }
        OutlinedTextField(phone, { phone = it.filter(Char::isDigit).take(10) }, label = { Text("Registered mobile") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pin, { pin = it.take(6) }, label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.login(phone, pin) }, modifier = Modifier.fillMaxWidth()) { Text("Sign in") }
    }
}

/** Role-based home: queue for front desk / optometrist / doctor (Epic 3) */
@Composable
fun QueueScreen(vm: QueueViewModel, role: Role, openVisit: (String) -> Unit) {
    val queue by vm.queue.collectAsState()
    val now = System.currentTimeMillis()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        if (role == Role.DOCTOR || role == Role.OPTOMETRIST) {
            Button(onClick = { vm.callNext(openVisit) }, modifier = Modifier.fillMaxWidth()) { Text("Call next patient") }
            Spacer(Modifier.height(8.dp))
        }
        Text("${queue.size} in clinic", style = MaterialTheme.typography.titleMedium)
        LazyColumn { items(queue, key = { it.id }) { v -> QueueCard(v, (now - v.stageSince) / 60_000) { openVisit(v.id) } } }
    }
}

/** Visit workspace — refraction and IOP tabs shown; other tabs follow the same pattern (Epic 4) */
@Composable
fun VisitScreen(vm: VisitViewModel, role: Role, openRx: () -> Unit) {
    val v by vm.visit.collectAsState()
    val saving by vm.saving.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val visit = v ?: run { Box(Modifier.fillMaxSize()) { CircularProgressIndicator(Modifier.padding(32.dp)) }; return }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PatientBanner(visit.patient, visit.token)
        Text(if (saving) "Saving…" else "Autosave on", style = MaterialTheme.typography.labelSmall)
        TabRow(tab) { listOf("Refraction", "IOP", "Plan").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) } }
        when (tab) {
            0 -> {
                val fin = visit.exam.finalRefraction ?: PerEye(Refraction(), Refraction())
                val dev = visit.exam.sources["refraction"] == "device"
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { vm.importDevice("autorefractor") }) { Text("Auto-refractor") }
                    OutlinedButton(onClick = { vm.copyOdToOs() }) { Text("Copy OD → OS") }
                }
                if (dev) AssistChip(onClick = { vm.confirmDevice("refraction") }, label = { Text("Device values — tap to confirm") })
                EyeColumns(
                    od = { RefractionSteppers(fin.od, dev) { vm.updateRefraction(it, fin.os) } },
                    os = { RefractionSteppers(fin.os, dev) { vm.updateRefraction(fin.od, it) } })
            }
            1 -> {
                val iop = visit.exam.iop ?: Iop()
                FilledTonalButton(onClick = { vm.importDevice("nct") }) { Text("Import from NCT") }
                if ((iop.od ?: 0) > 21 || (iop.os ?: 0) > 21) Pill("IOP above 21 mmHg", OdRed)
                EyeColumns(
                    od = { Stepper("mmHg", iop.od?.toDouble(), 1.0, 2.0, 70.0, { it?.toInt()?.toString() ?: "—" }, visit.exam.sources["iop"] == "device") { vm.updateIop(it.toInt(), iop.os) } },
                    os = { Stepper("mmHg", iop.os?.toDouble(), 1.0, 2.0, 70.0, { it?.toInt()?.toString() ?: "—" }, visit.exam.sources["iop"] == "device") { vm.updateIop(iop.od, it.toInt()) } })
            }
            else -> {
                Text("Diagnosis: ${visit.rx.diagnoses.joinToString { "${it.name} (${it.eye})" }.ifBlank { "none yet" }}")
                Text("Stage: ${visit.stage.label}")
                if (role == Role.DOCTOR && visit.rx.signedAt == null) Button(onClick = openRx, modifier = Modifier.fillMaxWidth()) { Text("Open Smart Rx") }
            }
        }
        if (role == Role.OPTOMETRIST && visit.stage in listOf(Stage.ARRIVED, Stage.WORKUP)) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::startDilation) { Text("Start dilation") }
            Button(onClick = vm::sendToDoctor) { Text("Send to doctor") }
        }
    }
}

@Composable
private fun RefractionSteppers(r: Refraction, device: Boolean, onChange: (Refraction) -> Unit) {
    Stepper("Sphere", r.sph, 0.25, -30.0, 30.0, deviceImported = device) { onChange(r.copy(sph = it)) }
    Stepper("Cylinder", r.cyl, 0.25, -10.0, 10.0, deviceImported = device) { onChange(r.copy(cyl = it)) }
    Stepper("Axis", r.axis?.toDouble(), 5.0, 5.0, 180.0, { it?.let { a -> "${a.toInt()}°" } ?: "—" }, device) { onChange(r.copy(axis = it.toInt())) }
    Stepper("Add", r.add, 0.25, 0.0, 4.0) { onChange(r.copy(add = it)) }
}

/** Smart Rx skeleton (Epic 5): diagnosis + template + allergy check; full composer in the hybrid build */
@Composable
fun RxScreen(vm: VisitViewModel, done: () -> Unit) {
    val v by vm.visit.collectAsState()
    val visit = v ?: return
    var useTemplate by remember { mutableStateOf(false) }
    val drugs = if (useTemplate) listOf(DrugLine("DRG001", "Moxifloxacin 0.5% eye drops", Eye.OU, "4 times/day", "1 week"), DrugLine("DRG004", "Carboxymethylcellulose 0.5% eye drops", Eye.OU, "4 times/day", "4 weeks"))
        else listOf(DrugLine("DRG004", "Carboxymethylcellulose 0.5% eye drops", Eye.OU, "4 times/day", "1 month"))
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PatientBanner(visit.patient, visit.token)
        Text("Diagnosis: Presbyopia (H52.4) · OU", fontWeight = FontWeight.SemiBold)
        Row { Checkbox(useTemplate, { useTemplate = it }); Text("Apply template with Moxifloxacin (try on an allergic patient)", Modifier.padding(top = 12.dp)) }
        drugs.forEach { Text("• ${it.name} — ${it.eye}, ${it.frequency}, ${it.duration}") }
        visit.exam.finalRefraction?.let { Text("Spectacle Rx: OD ${rxText(it.od)} · OS ${rxText(it.os)}") }
        Button(onClick = { vm.signQuickRx(Diagnosis("H52.4", "Presbyopia", Eye.OU), drugs, onDone = done) }, modifier = Modifier.fillMaxWidth()) { Text("Sign and send") }
    }
}

@Composable
fun DashboardScreen(vm: DashboardViewModel) {
    val k by vm.kpis.collectAsState()
    LaunchedEffect(Unit) { vm.load() }
    val d = k ?: return
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Patients today" to "${d.patientsToday} (${d.newPatients} new)", "Waiting now" to "${d.waitingNow}", "Avg wait to doctor" to "${d.avgWaitMinutes} min",
            "Collections" to "₹${d.collections}", "Surgeries" to "${d.surgeriesDone} / ${d.surgeriesBooked}", "Approvals waiting" to "${d.pendingApprovals}").forEach { (l, v) ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(l, style = MaterialTheme.typography.labelMedium); Text(v, style = MaterialTheme.typography.titleLarge) } }
        }
    }
}

/** Demo centre (mock only): simulators to show the working without a backend */
@Composable
fun DemoScreen(mock: MockRepository?, message: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (mock == null) { Text("Demo centre is available only in the mock build."); return@Column }
        Button(onClick = { scope.launch { val v = mock.simulateArrival(); message("Token ${v.token}: ${v.patient.name} arrived") } }, Modifier.fillMaxWidth()) { Text("Simulate walk-in arrival") }
        OutlinedButton(onClick = { mock.fastForward(20); message("Clock +20 min") }, Modifier.fillMaxWidth()) { Text("Fast-forward 20 minutes") }
        Text("The hybrid demo APK contains the full Demo centre (guided story, offline mode, plans, API log).", style = MaterialTheme.typography.bodySmall)
    }
}
