package com.eyespyes.careteam.data.repository

import com.eyespyes.careteam.data.model.*
import kotlinx.coroutines.flow.Flow

/**
 * DATA CONTRACT for the Care Team app — hand-off point for the DBMS / backend team.
 * Same operations as the hybrid demo's js/data/contract.js (route in each KDoc).
 * Two implementations: [com.eyespyes.careteam.data.mock.MockRepository] (demo) and
 * [com.eyespyes.careteam.data.remote.ApiRepository] (to be completed against the database).
 * Rules marked [SERVER RULE] must be enforced by the backend, not only in the app.
 */
interface CareTeamRepository {
    // ---- Auth (Epic 1) ----
    /** POST /auth/login {phone, pin} */
    suspend fun login(phone: String, pin: String): Session
    /** POST /auth/logout */
    suspend fun logout()
    val session: Flow<Session?>
    /** POST /auth/role {role} */
    suspend fun switchRole(role: Role): Session

    // ---- Patients (Epic 2) ----
    /** GET /patients?q= */
    suspend fun searchPatients(query: String): List<Patient>
    /** POST /patients/duplicates */
    suspend fun findDuplicates(name: String, phone: String, age: Int?): List<Patient>
    /** POST /patients — [SERVER RULE] treatment-communication consent required (DPDP) */
    suspend fun createPatient(draft: Patient): Patient

    // ---- Queue (Epic 3) ----
    /** GET /queue?branchId= — production: push via WebSocket/SSE, < 3 s (CT-03-04) */
    fun observeQueue(): Flow<List<Visit>>
    /** POST /visits {patientId, type, priority} */
    suspend fun checkIn(patientId: String, type: String, doctorId: String, priority: List<Priority>): Visit
    /** POST /queue/call-next {stage} */
    suspend fun callNext(): Visit?
    /** POST /visits/:id/stage */
    suspend fun moveVisit(visitId: String, stage: Stage, reason: String? = null): Visit

    // ---- Exam (Epic 4) ----
    /** GET /visits/:id */
    suspend fun getVisit(visitId: String): Visit
    /** PUT /visits/:id/exam — [SERVER RULE] rejected once the visit is signed (CT-04-15) */
    suspend fun saveExam(visitId: String, exam: Exam): Visit
    /** POST /visits/:id/dilation */
    suspend fun startDilation(visitId: String, drops: String, minutes: Int): Visit
    /** POST /visits/:id/device-import {device} — values come from the clinic-side device bridge */
    suspend fun importDevice(visitId: String, device: String): Visit

    // ---- Rx (Epic 5) ----
    /** POST /visits/:id/rx/sign — [SERVER RULE] allergy check, doctor role, registration number */
    suspend fun signRx(visitId: String, rx: Prescription, allergyOverrides: Map<String, String>): Visit

    // ---- Dashboard (Epic 14) ----
    /** GET /dashboard */
    suspend fun dashboard(): DashboardKpis

    // Remaining contract methods (optical, pharmacy, billing, IPD, OT, inbox, reports, audit) follow the same
    // pattern; see docs/DATA_CONTRACT.md and the working mock in the hybrid build.
}
