package com.eyespyes.careteam.data.remote

import com.eyespyes.careteam.data.model.*
import com.eyespyes.careteam.data.repository.CareTeamRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * STUB for the DBMS / backend team.
 * Implement each method against the REST routes in docs/DATA_CONTRACT.md
 * (Ktor client or Retrofit + kotlinx.serialization), cache in Room for offline use,
 * and queue offline writes with WorkManager. Until then every call fails clearly.
 */
class ApiRepository(private val baseUrl: String) : CareTeamRepository {
    private fun todo(route: String): Nothing = throw NotImplementedError("Backend route not implemented yet: $route ($baseUrl)")
    override val session: Flow<Session?> = MutableStateFlow(null)

    override suspend fun login(phone: String, pin: String): Session = todo("POST /auth/login")
    override suspend fun logout() { todo("POST /auth/logout") }
    override suspend fun switchRole(role: Role): Session = todo("POST /auth/role")
    override suspend fun searchPatients(query: String): List<Patient> = todo("GET /patients?q=")
    override suspend fun findDuplicates(name: String, phone: String, age: Int?): List<Patient> = todo("POST /patients/duplicates")
    override suspend fun createPatient(draft: Patient): Patient = todo("POST /patients")
    override fun observeQueue(): Flow<List<Visit>> = todo("WS /queue/stream (or GET /queue polling)")
    override suspend fun checkIn(patientId: String, type: String, doctorId: String, priority: List<Priority>): Visit = todo("POST /visits")
    override suspend fun callNext(): Visit? = todo("POST /queue/call-next")
    override suspend fun moveVisit(visitId: String, stage: Stage, reason: String?): Visit = todo("POST /visits/:id/stage")
    override suspend fun getVisit(visitId: String): Visit = todo("GET /visits/:id")
    override suspend fun saveExam(visitId: String, exam: Exam): Visit = todo("PUT /visits/:id/exam")
    override suspend fun startDilation(visitId: String, drops: String, minutes: Int): Visit = todo("POST /visits/:id/dilation")
    override suspend fun importDevice(visitId: String, device: String): Visit = todo("POST /visits/:id/device-import")
    override suspend fun signRx(visitId: String, rx: Prescription, allergyOverrides: Map<String, String>): Visit = todo("POST /visits/:id/rx/sign")
    override suspend fun dashboard(): DashboardKpis = todo("GET /dashboard")
}
