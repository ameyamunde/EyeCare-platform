package com.eyespyes.careteam.data.model

import kotlinx.serialization.Serializable

/*
 * Domain model shared by the UI and the data layer.
 * Mirrors docs/DATA_CONTRACT.md. The DBMS team owns persistence; these are the
 * shapes the app expects back from the repository.
 */

enum class Role(val label: String) {
    OWNER("Owner / admin"), DOCTOR("Ophthalmologist"), OPTOMETRIST("Optometrist"), FRONT_DESK("Front desk"),
    COUNSELLOR("Counsellor"), OPTICIAN("Optician"), NURSE("Nurse / ward"), OT("OT coordinator"),
    PHARMACIST("Pharmacist"), BILLING("Billing")
}

enum class Plan { SOLO, CLINIC, HOSPITAL, ENTERPRISE }

enum class Eye { OD, OS, OU }

enum class Stage(val label: String) {
    BOOKED("Booked"), ARRIVED("Waiting"), WORKUP("Work-up"), DILATING("Dilating"), DOCTOR("Doctor"),
    INVESTIGATIONS("Tests"), COUNSELLING("Counselling"), OPTICAL("Optical"), PHARMACY("Pharmacy"),
    BILLING("Billing"), COMPLETED("Done"), LWBS("Left")
}

enum class Priority { EMERGENCY, POSTOP, CHILD, ELDERLY, VIP }

@Serializable
data class User(
    val id: String, val name: String, val roles: List<Role>, val branchIds: List<String>,
    val phone: String, val regNo: String? = null, val qualification: String? = null
)

@Serializable
data class Session(val user: User, val activeRole: Role, val branchId: String, val plan: Plan, val token: String)

@Serializable
data class Consent(val treatment: Boolean, val marketing: Boolean, val version: String, val recordedAt: Long)

@Serializable
data class Patient(
    val id: String, val uhid: String, val name: String, val sex: String, val dob: String, val phone: String,
    val city: String = "", val abha: String? = null, val allergies: List<String> = emptyList(),
    val diabetic: Boolean = false, val glaucoma: Boolean = false, val payer: String = "Self",
    val consent: Consent
)

/** One refraction value for one eye. Sphere/cylinder in 0.25 D steps; axis 1–180. */
@Serializable
data class Refraction(val sph: Double = 0.0, val cyl: Double = 0.0, val axis: Int? = null, val add: Double = 0.0)

@Serializable
data class PerEye<T>(val od: T, val os: T)

@Serializable
data class VisualAcuity(
    val unaided: PerEye<String?> = PerEye(null, null), val pinhole: PerEye<String?> = PerEye(null, null),
    val bestCorrected: PerEye<String?> = PerEye(null, null), val near: PerEye<String?> = PerEye(null, null)
)

@Serializable
data class Iop(val method: String = "NCT", val od: Int? = null, val os: Int? = null, val measuredAt: Long? = null)

@Serializable
data class Exam(
    val vision: VisualAcuity? = null,
    val autoRefraction: PerEye<Refraction>? = null,
    val finalRefraction: PerEye<Refraction>? = null,
    val pd: Int? = null,
    val iop: Iop? = null,
    val anterior: PerEye<Map<String, String>>? = null,
    val posterior: PerEye<Map<String, String>>? = null,
    /** section -> "device" while device-imported values are unconfirmed (CT-04-12) */
    val sources: Map<String, String> = emptyMap()
)

@Serializable
data class Diagnosis(val code: String, val name: String, val eye: Eye)

@Serializable
data class DrugLine(
    val sku: String, val name: String, val eye: Eye, val frequency: String, val duration: String,
    val taper: List<String>? = null, val qty: Int = 1
)

@Serializable
data class SpectacleRx(val refraction: PerEye<Refraction>, val pd: Int, val lensAdvice: String, val coating: String, val validMonths: Int = 12)

@Serializable
data class Prescription(
    val diagnoses: List<Diagnosis> = emptyList(), val drugs: List<DrugLine> = emptyList(), val spectacle: SpectacleRx? = null,
    val advice: List<String> = emptyList(), val followUpDays: Int? = null, val procedureAdvised: String? = null,
    val signedAt: Long? = null, val signedBy: String? = null, val awaitingCountersign: Boolean = false
)

@Serializable
data class StageEvent(val stage: Stage, val at: Long, val by: String?)

@Serializable
data class Dilation(val startedAt: Long, val minutes: Int, val drops: String)

@Serializable
data class Visit(
    val id: String, val patient: Patient, val token: Int, val type: String, val stage: Stage,
    val doctorId: String, val assigneeId: String? = null, val priority: List<Priority> = emptyList(),
    val arrivedAt: Long, val stageLog: List<StageEvent>, val dilation: Dilation? = null,
    val exam: Exam = Exam(), val rx: Prescription = Prescription(), val signedAt: Long? = null
) {
    val stageSince: Long get() = stageLog.lastOrNull()?.at ?: arrivedAt
}

@Serializable
data class DashboardKpis(
    val patientsToday: Int, val newPatients: Int, val waitingNow: Int, val avgWaitMinutes: Int,
    val collections: Long, val surgeriesDone: Int, val surgeriesBooked: Int, val pendingApprovals: Int
)

class RuleViolation(message: String, val code: String = "rule") : Exception(message)
