package com.eyespyes.careteam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.eyespyes.careteam.data.model.Role
import com.eyespyes.careteam.ui.screens.*
import com.eyespyes.careteam.ui.theme.EyespyesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as EyespyesApp
        setContent { EyespyesTheme { CareTeamApp(app) } }
    }
}

private class Factory(private val create: () -> ViewModel) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = create() as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CareTeamApp(app: EyespyesApp) {
    val sessionVm: SessionViewModel = viewModel(factory = Factory { SessionViewModel(app.repo) })
    val session by sessionVm.session.collectAsState()
    val snack = remember { SnackbarHostState() }
    val loginMsg by sessionVm.message.collectAsState()
    LaunchedEffect(loginMsg) { loginMsg?.let { snack.showSnackbar(it.text) } }

    val s = session
    if (s == null) {
        Scaffold(snackbarHost = { SnackbarHost(snack) }) { p -> androidx.compose.foundation.layout.Box(Modifier.padding(p)) { LoginScreen(sessionVm, app.mock) } }
        return
    }
    val nav = rememberNavController()
    val route by nav.currentBackStackEntryAsState()
    val home = if (s.activeRole == Role.OWNER) "dashboard" else "queue"
    Scaffold(
        topBar = { TopAppBar(title = { Text("${s.user.name} · ${s.activeRole.label}") }, actions = { TextButton(onClick = { nav.navigate("demo") }) { Text("DEMO") } }) },
        bottomBar = {
            NavigationBar {
                listOf(Triple(home, "Home", Icons.Default.Home), Triple("queue", "Queue", Icons.Default.People), Triple("demo", "Demo", Icons.Default.Science)).forEach { (r, l, i) ->
                    NavigationBarItem(selected = route?.destination?.route == r, onClick = { nav.navigate(r) { launchSingleTop = true } }, icon = { Icon(i, null) }, label = { Text(l) })
                }
                NavigationBarItem(selected = false, onClick = { sessionVm.logout() }, icon = { Icon(Icons.Default.Logout, null) }, label = { Text("Sign out") })
            }
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        NavHost(nav, startDestination = home, modifier = Modifier.padding(pad)) {
            composable("queue") {
                val vm: QueueViewModel = viewModel(factory = Factory { QueueViewModel(app.repo) })
                val msg by vm.message.collectAsState(); LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it.text) } }
                QueueScreen(vm, s.activeRole) { id -> nav.navigate("visit/$id") }
            }
            composable("dashboard") { DashboardScreen(viewModel(factory = Factory { DashboardViewModel(app.repo) })) }
            composable("visit/{id}") { e ->
                val id = e.arguments?.getString("id")!!
                val vm: VisitViewModel = viewModel(key = "visit-$id", factory = Factory { VisitViewModel(app.repo, id) })
                val msg by vm.message.collectAsState(); LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it.text) } }
                VisitScreen(vm, s.activeRole) { nav.navigate("rx/$id") }
            }
            composable("rx/{id}") { e ->
                val id = e.arguments?.getString("id")!!
                val vm: VisitViewModel = viewModel(key = "visit-$id", factory = Factory { VisitViewModel(app.repo, id) })
                val msg by vm.message.collectAsState(); LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it.text) } }
                RxScreen(vm) { nav.popBackStack(home, inclusive = false) }
            }
            composable("demo") {
                var m by remember { mutableStateOf<String?>(null) }
                LaunchedEffect(m) { m?.let { snack.showSnackbar(it) } }
                DemoScreen(app.mock) { m = it }
            }
        }
    }
}
