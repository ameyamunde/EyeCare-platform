package com.eyespyes.careteam.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eyespyes.careteam.data.model.*
import com.eyespyes.careteam.data.repository.CareTeamRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** One-shot UI messages (toasts / snackbars) */
data class UiMessage(val text: String, val id: Long = System.nanoTime())

class SessionViewModel(private val repo: CareTeamRepository) : ViewModel() {
    val session = repo.session.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val message = MutableStateFlow<UiMessage?>(null)
    fun login(phone: String, pin: String) = viewModelScope.launch {
        runCatching { repo.login(phone, pin) }.onFailure { message.value = UiMessage(it.message ?: "Login failed") }
    }
    fun logout() = viewModelScope.launch { repo.logout() }
}

class QueueViewModel(private val repo: CareTeamRepository) : ViewModel() {
    val queue = repo.observeQueue().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val message = MutableStateFlow<UiMessage?>(null)
    fun callNext(onCalled: (String) -> Unit) = viewModelScope.launch {
        runCatching { repo.callNext() }.onSuccess { v -> if (v == null) message.value = UiMessage("No one waiting") else { message.value = UiMessage("Token ${v.token} called"); onCalled(v.id) } }
            .onFailure { message.value = UiMessage(it.message ?: "Error") }
    }
}

/** Visit workspace: autosaves the exam (CT-04-14) */
class VisitViewModel(private val repo: CareTeamRepository, private val visitId: String) : ViewModel() {
    val visit = MutableStateFlow<Visit?>(null)
    val message = MutableStateFlow<UiMessage?>(null)
    val saving = MutableStateFlow(false)
    init { viewModelScope.launch { visit.value = repo.getVisit(visitId) } }

    fun updateRefraction(od: Refraction, os: Refraction) = edit { it.copy(finalRefraction = PerEye(od, os)) }
    fun updateIop(od: Int?, os: Int?) = edit { it.copy(iop = (it.iop ?: Iop()).copy(od = od, os = os, measuredAt = System.currentTimeMillis())) }
    fun copyOdToOs() = edit { e -> e.finalRefraction?.let { e.copy(finalRefraction = PerEye(it.od, it.od)) } ?: e }
    fun confirmDevice(section: String) = edit { it.copy(sources = it.sources - section) }

    private fun edit(f: (Exam) -> Exam) {
        val v = visit.value ?: return
        val updated = v.copy(exam = f(v.exam)); visit.value = updated
        viewModelScope.launch {
            saving.value = true
            runCatching { repo.saveExam(visitId, updated.exam) }.onFailure { message.value = UiMessage(it.message ?: "Save failed") }
            saving.value = false
        }
    }
    fun importDevice(device: String) = viewModelScope.launch {
        message.value = UiMessage("Waiting for $device…")
        runCatching { repo.importDevice(visitId, device) }.onSuccess { visit.value = it; message.value = UiMessage("Imported from $device — confirm values") }
    }
    fun startDilation() = viewModelScope.launch { visit.value = repo.startDilation(visitId, "Tropicamide + phenylephrine", 20) }
    fun sendToDoctor() = viewModelScope.launch { visit.value = repo.moveVisit(visitId, Stage.DOCTOR, "Work-up complete") }

    /** Smart Rx (Epic 5): demo signs a presbyopia Rx with the final refraction as spectacle Rx */
    fun signQuickRx(diagnosis: Diagnosis, drugs: List<DrugLine>, overrides: Map<String, String> = emptyMap(), onDone: () -> Unit) = viewModelScope.launch {
        val v = visit.value ?: return@launch
        val spec = v.exam.finalRefraction?.let { SpectacleRx(it, v.exam.pd ?: 62, "Progressive", "Anti-reflective") }
        runCatching { repo.signRx(visitId, Prescription(listOf(diagnosis), drugs, spec, followUpDays = 365), overrides) }
            .onSuccess { visit.value = it; message.value = UiMessage("Signed — routed to ${it.stage.label}"); onDone() }
            .onFailure { message.value = UiMessage(it.message ?: "Could not sign") }
    }
}

class DashboardViewModel(private val repo: CareTeamRepository) : ViewModel() {
    val kpis = MutableStateFlow<DashboardKpis?>(null)
    fun load() = viewModelScope.launch { kpis.value = repo.dashboard() }
}
