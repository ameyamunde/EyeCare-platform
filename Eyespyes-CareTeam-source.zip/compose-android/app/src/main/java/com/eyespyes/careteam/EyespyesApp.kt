package com.eyespyes.careteam

import android.app.Application
import com.eyespyes.careteam.data.mock.MockRepository
import com.eyespyes.careteam.data.remote.ApiRepository
import com.eyespyes.careteam.data.repository.CareTeamRepository

/** Minimal service locator. Swap to Hilt when the production data layer lands. */
class EyespyesApp : Application() {
    lateinit var repo: CareTeamRepository
        private set
    val mock: MockRepository? get() = repo as? MockRepository

    override fun onCreate() {
        super.onCreate()
        repo = if (BuildConfig.DATA_MODE == "api") ApiRepository(BuildConfig.API_BASE) else MockRepository()
    }
}
