package com.eyespyes.careteam.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Eyespyes sky blue: Brand passes WCAG AA with white text (4.8:1); Sky is for accents and gradients */
val Brand = Color(0xFF0277BD)
val BrandStrong = Color(0xFF0369A1)
val Sky = Color(0xFF0EA5E9)
val SkySoft = Color(0xFFE0F2FE)
val Navy = Color(0xFF0B1F5C) // logo wordmark navy
val Accent = Color(0xFFF59E0B)
/** Eye colour convention used on every clinical screen and printout */
val OdRed = Color(0xFFC62828)
val OsBlue = Color(0xFF4338CA) // OS kept indigo so it never blends with the brand sky
val OdSoft = Color(0xFFFDECEC)
val OsSoft = Color(0xFFEEEDFD)
val Ok = Color(0xFF15803D)
val Warn = Color(0xFFB45309)

private val Light = lightColorScheme(primary = Brand, onPrimary = Color.White, primaryContainer = SkySoft, onPrimaryContainer = Navy, secondary = Sky, tertiary = Accent, background = Color(0xFFF4F9FD), surface = Color.White, onSurface = Color(0xFF0F2A43))
private val Dark = darkColorScheme(primary = Color(0xFF38BDF8), secondary = Sky, tertiary = Accent, background = Color(0xFF0B1622), surface = Color(0xFF111F2E))

@Composable
fun EyespyesTheme(darkRoom: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkRoom) Dark else Light, content = content)
}
