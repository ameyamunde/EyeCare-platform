package com.eyespyes.careteam.data.mock

import com.eyespyes.careteam.data.model.*
import com.eyespyes.careteam.data.repository.CareTeamRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlin.random.Random

/** In-memory demo implementation with fictional data. Also exposes demo simulators. */
class MockRepository : CareTeamRepository {
    private val now get() = System.currentTimeMillis() + clockOffset
    var clockOffset = 0L
        private set
    private val sessionFlow = MutableStateFlow<Session?>(null)
    override val session: Flow<Session?> = sessionFlow.asStateFlow()

    private val users = listOf(
        User("u_owner", "Rahul Deshpande", listOf(Role.OWNER), listOf("br_1"), "9000000001"),
        User("u_doc1", "Dr. Anjali Rao", listOf(Role.DOCTOR), listOf("br_1"), "9000000002", "MMC-2011-04567", "MS (Ophth)"),
        User("u_opt1", "Sneha Patil", listOf(Role.OPTOMETRIST), listOf("br_1"), "9000000004", "OPT-MH-3321"),
        User("u_desk", "Pooja Jadhav", listOf(Role.FRONT_DESK), listOf("br_1"), "9000000005")
    )
    val demoUsers: List<User> get() = users

    private val patients = mutableListOf(
        patient("p01", "Asha Patil", "F", "1958-03-12", "9822001101", diabetic = true),
        patient("p02", "Ramesh Kulkarni", "M", "1961-07-04", "9822001102", glaucoma = true, allergies = listOf("Brimonidine")),
        patient("p05", "Lakshmi Iyer", "F", "1949-09-30", "9822001105", allergies = listOf("Fluoroquinolone"))
    )
    private val visits = MutableStateFlow<List<Visit>>(emptyList())

    init {
        val t = System.currentTimeMillis()
        visits.value = listOf(
            visit("v1", patients[0], 23, Stage.DOCTOR, t - 58 * MIN, exam = Exam(finalRefraction = PerEye(Refraction(0.75, -1.0, 95, 2.5), Refraction(0.5, -0.75, 80, 2.5)), pd = 63, iop = Iop("NCT", 17, 18))),
            visit("v2", patients[1], 19, Stage.ARRIVED, t - 12 * MIN),
            visit("v3", patients[2], 24, Stage.WORKUP, t - 22 * MIN, priority = listOf(Priority.POSTOP))
        )
    }

    private fun patient(id: String, name: String, sex: String, dob: String, phone: String, diabetic: Boolean = false, glaucoma: Boolean = false, allergies: List<String> = emptyList()) =
        Patient(id, "DEC-" + (24100 + id.drop(1).toInt()), name, sex, dob, phone, "Pune", null, allergies, diabetic, glaucoma, "Self", Consent(true, false, "v1.2", 0))

    private fun visit(id: String, p: Patient, token: Int, stage: Stage, arrived: Long, exam: Exam = Exam(), priority: List<Priority> = emptyList()) =
        Visit(id, p, token, "review", stage, "u_doc1", null, priority, arrived, listOf(StageEvent(Stage.ARRIVED, arrived, "u_desk"), StageEvent(stage, arrived + 5 * MIN, null)), exam = exam)

    private suspend fun latency() = delay(Random.nextLong(40, 120))
    private fun update(id: String, f: (Visit) -> Visit): Visit {
        var out: Visit? = null
        visits.value = visits.value.map { if (it.id == id) f(it).also { v -> out = v } else it }
        return out ?: throw RuleViolation("Visit not found", "not_found")
    }

    // ---- Auth ----
    override suspend fun login(phone: String, pin: String): Session {
        latency()
        val u = users.firstOrNull { it.phone == phone } ?: throw RuleViolation("This mobile number is not registered.")
        if (pin != "1234") throw RuleViolation("Wrong PIN. 5 wrong attempts lock login for 15 minutes.")
        return loginAs(u.id)
    }
    fun loginAs(userId: String): Session {
        val u = users.first { it.id == userId }
        return Session(u, u.roles.first(), u.branchIds.first(), Plan.HOSPITAL, "demo-token").also { sessionFlow.value = it }
    }
    override suspend fun logout() { sessionFlow.value = null }
    override suspend fun switchRole(role: Role): Session = sessionFlow.value!!.copy(activeRole = role).also { sessionFlow.value = it }

    // ---- Patients ----
    override suspend fun searchPatients(query: String): List<Patient> { latency(); val q = query.lowercase(); return patients.filter { q.isBlank() || it.name.lowercase().contains(q) || it.phone.contains(q) || it.uhid.lowercase().contains(q) } }
    override suspend fun findDuplicates(name: String, phone: String, age: Int?) = patients.filter { it.phone == phone && it.name.substringBefore(' ').equals(name.substringBefore(' '), true) }
    override suspend fun createPatient(draft: Patient): Patient {
        latency()
        if (!draft.consent.treatment) throw RuleViolation("Treatment-communication consent must be recorded (DPDP).")
        val p = draft.copy(id = "p" + (100 + patients.size), uhid = "DEC-" + (24200 + patients.size)); patients += p; return p
    }

    // ---- Queue ----
    override fun observeQueue(): Flow<List<Visit>> = visits.map { list -> list.filter { it.stage != Stage.COMPLETED }.sortedBy { it.arrivedAt } }
    override suspend fun checkIn(patientId: String, type: String, doctorId: String, priority: List<Priority>): Visit {
        latency()
        val p = patients.first { it.id == patientId }
        if (visits.value.any { it.patient.id == patientId && it.stage != Stage.COMPLETED }) throw RuleViolation("${p.name} is already in today's queue.")
        val v = Visit("v" + (visits.value.size + 1), p, (visits.value.maxOfOrNull { it.token } ?: 0) + 1, type, Stage.ARRIVED, doctorId, null, priority, now, listOf(StageEvent(Stage.ARRIVED, now, sessionFlow.value?.user?.id)))
        visits.value = visits.value + v; return v
    }
    override suspend fun callNext(): Visit? {
        latency()
        val s = sessionFlow.value ?: return null
        val (from, to) = when (s.activeRole) { Role.OPTOMETRIST -> Stage.ARRIVED to Stage.WORKUP; Role.DOCTOR -> Stage.DOCTOR to Stage.DOCTOR; else -> return null }
        val next = visits.value.filter { it.stage == from && it.assigneeId == null || (s.activeRole == Role.DOCTOR && it.stage == Stage.DILATING && dilationDone(it)) }.minByOrNull { it.arrivedAt } ?: return null
        return update(next.id) { it.copy(stage = to, assigneeId = s.user.id, stageLog = it.stageLog + StageEvent(to, now, s.user.id)) }
    }
    private fun dilationDone(v: Visit) = v.dilation != null && now - v.dilation.startedAt >= v.dilation.minutes * MIN
    override suspend fun moveVisit(visitId: String, stage: Stage, reason: String?) = update(visitId) { it.copy(stage = stage, assigneeId = null, stageLog = it.stageLog + StageEvent(stage, now, sessionFlow.value?.user?.id)) }

    // ---- Exam ----
    override suspend fun getVisit(visitId: String): Visit { latency(); return visits.value.first { it.id == visitId } }
    override suspend fun saveExam(visitId: String, exam: Exam): Visit {
        val v = getVisit(visitId); if (v.signedAt != null) throw RuleViolation("Visit is signed. Add an addendum instead.", "locked")
        return update(visitId) { it.copy(exam = exam) }
    }
    override suspend fun startDilation(visitId: String, drops: String, minutes: Int) = update(visitId) { it.copy(stage = Stage.DILATING, dilation = Dilation(now, minutes, drops), stageLog = it.stageLog + StageEvent(Stage.DILATING, now, null)) }
    override suspend fun importDevice(visitId: String, device: String): Visit {
        delay(900)
        fun r(a: Double, b: Double) = Math.round((a + Random.nextDouble() * (b - a)) * 4) / 4.0
        return update(visitId) { v ->
            when (device) {
                "autorefractor" -> { val e = { Refraction(r(-3.0, 1.5), -r(0.0, 1.5), (Random.nextInt(1, 36) * 5)) }; val auto = PerEye(e(), e())
                    v.copy(exam = v.exam.copy(autoRefraction = auto, finalRefraction = v.exam.finalRefraction ?: auto, sources = v.exam.sources + ("refraction" to "device"))) }
                "nct" -> v.copy(exam = v.exam.copy(iop = Iop("NCT", Random.nextInt(12, 24), Random.nextInt(12, 24), now), sources = v.exam.sources + ("iop" to "device")))
                else -> v
            }
        }
    }

    // ---- Rx ----
    override suspend fun signRx(visitId: String, rx: Prescription, allergyOverrides: Map<String, String>): Visit {
        latency()
        val s = sessionFlow.value ?: throw RuleViolation("Not signed in")
        if (s.activeRole != Role.DOCTOR) throw RuleViolation("Only a doctor can sign prescriptions.", "forbidden")
        if (rx.diagnoses.isEmpty()) throw RuleViolation("Add at least one diagnosis with the eye.")
        val v = getVisit(visitId)
        rx.drugs.forEach { d -> v.patient.allergies.firstOrNull { a -> d.name.contains(a, true) || (a == "Fluoroquinolone" && d.name.contains("floxacin", true)) }
            ?.let { a -> if (d.sku !in allergyOverrides) throw RuleViolation("Allergy: ${v.patient.name} is allergic to $a.", "allergy") } }
        val next = when { rx.procedureAdvised != null -> Stage.COUNSELLING; rx.spectacle != null -> Stage.OPTICAL; rx.drugs.isNotEmpty() -> Stage.PHARMACY; else -> Stage.BILLING }
        return update(visitId) { it.copy(rx = rx.copy(signedAt = now, signedBy = s.user.id), signedAt = now, stage = next, assigneeId = null, stageLog = it.stageLog + StageEvent(next, now, s.user.id)) }
    }

    override suspend fun dashboard(): DashboardKpis {
        val list = visits.value
        return DashboardKpis(list.size, list.count { it.type == "new" }, list.count { it.stage != Stage.COMPLETED }, 28, 44_913, 1, 3, 2)
    }

    // ---- Demo simulators (mock only) ----
    suspend fun simulateArrival(): Visit {
        val names = listOf("Shreya Kapoor" to "F", "Mahendra Salunkhe" to "M", "Zoya Khan" to "F", "Leela Menon" to "F")
        val (n, sex) = names.random()
        val p = createPatient(Patient("", "", n, sex, "1970-04-15", "97" + Random.nextInt(10_000_000, 99_999_999), consent = Consent(true, false, "v1.2", now)))
        return checkIn(p.id, "new", "u_doc1", emptyList())
    }
    fun fastForward(minutes: Int) { clockOffset += minutes * MIN; visits.value = visits.value.toList() }

    companion object { const val MIN = 60_000L }
}
