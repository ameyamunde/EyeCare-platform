#!/usr/bin/env python3
"""Bundles the web UI (assets/www) into one self-contained HTML file for browser use / hosting."""
import re, pathlib, sys
www = pathlib.Path(__file__).parent / 'app/src/main/assets/www'
out = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else 'build/eyespyes-careteam-web.html')
html = (www / 'index.html').read_text()
css = (www / 'css/app.css').read_text()
html = html.replace('<link rel="stylesheet" href="css/app.css">', '<style>\n' + css + '\n</style>')
def inline(m):
    js = (www / m.group(1)).read_text().replace('</script', '<\\/script')
    return '<script>\n/* ' + m.group(1) + ' */\n' + js + '\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
# Hosted build: keep routes in memory (embedded viewers do not pass #/path hashes)
html = html.replace('<script>\n/* js/core/util.js */', '<script>window.EYESPYES_MEMORY_ROUTER = true;</script>\n<script>\n/* js/core/util.js */', 1)
html = html.replace('<meta name="theme-color" content="#0277BD">', '<meta name="theme-color" content="#0277BD">\n<meta name="description" content="Eyespyes Care Team: demo web app for eye clinics and hospitals. Fictional data stays in this browser.">')
out.parent.mkdir(parents=True, exist_ok=True); out.write_text(html)
print(out, len(html), 'bytes')
