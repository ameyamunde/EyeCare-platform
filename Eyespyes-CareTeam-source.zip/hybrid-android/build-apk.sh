#!/usr/bin/env bash
# Builds a signed debug APK with the plain Android SDK tools (no Gradle needed).
# Requires: aapt2, javac (JDK 8+), dx or d8, zipalign, apksigner, keytool, platform android.jar.
# Debian/Ubuntu: apt install android-sdk-platform-23 android-sdk-build-tools dalvik-exchange apksigner zipalign
set -euo pipefail
cd "$(dirname "$0")"
SDK_JAR="${ANDROID_JAR:-/usr/lib/android-sdk/platforms/android-23/android.jar}"
APP=app/src/main
OUT=build
rm -rf "$OUT"; mkdir -p "$OUT"/{res,gen,classes}

echo "1/6 compile resources"
aapt2 compile --dir "$APP/res" -o "$OUT/res/res.zip"

echo "2/6 link manifest + resources + assets"
aapt2 link -o "$OUT/unsigned.apk" -I "$SDK_JAR" --manifest "$APP/AndroidManifest.xml" \
  --java "$OUT/gen" -A "$APP/assets" --min-sdk-version 23 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0.0-demo --auto-add-overlay "$OUT/res/res.zip"

echo "3/6 compile Java"
javac -nowarn --release 8 -Xlint:-options -classpath "$SDK_JAR" -d "$OUT/classes" \
  $(find "$APP/java" "$OUT/gen" -name '*.java')

echo "4/6 dex"
if command -v d8 >/dev/null; then d8 --release --min-api 23 --lib "$SDK_JAR" --output "$OUT" $(find "$OUT/classes" -name '*.class');
else dalvik-exchange --dex --min-sdk-version=23 --output="$OUT/classes.dex" "$OUT/classes"; fi
(cd "$OUT" && zip -q -j unsigned.apk classes.dex)

echo "5/6 align"
zipalign -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "6/6 sign (demo key)"
KS=demo-release.keystore
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass eyespyesdemo -keypass eyespyesdemo -alias eyespyes \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Eyespyes Care Team Demo, O=Eyespyes, C=IN" >/dev/null 2>&1
fi
apksigner sign --ks "$KS" --ks-pass pass:eyespyesdemo --key-pass pass:eyespyesdemo --ks-key-alias eyespyes \
  --out "$OUT/Eyespyes-CareTeam-demo.apk" "$OUT/aligned.apk"
apksigner verify --print-certs "$OUT/Eyespyes-CareTeam-demo.apk" | head -2
ls -la "$OUT/Eyespyes-CareTeam-demo.apk"
