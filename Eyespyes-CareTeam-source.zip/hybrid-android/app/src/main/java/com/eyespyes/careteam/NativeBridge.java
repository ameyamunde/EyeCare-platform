package com.eyespyes.careteam;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 * Methods callable from JavaScript as window.AndroidBridge.*
 * Keep this surface small: every method is reachable from page script.
 */
public class NativeBridge {
    private final Activity activity;

    NativeBridge(Activity activity) { this.activity = activity; }

    /** Opens the Android share sheet (WhatsApp, email, Drive...). */
    @JavascriptInterface
    public void share(final String title, final String text) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title);
                send.putExtra(Intent.EXTRA_TEXT, text);
                activity.startActivity(Intent.createChooser(send, title));
            }
        });
    }

    @JavascriptInterface
    public void toast(final String msg) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    @SuppressWarnings("deprecation")
    @JavascriptInterface
    public void vibrate(int ms) {
        Vibrator v = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null && v.hasVibrator()) v.vibrate(Math.max(10, Math.min(ms, 500)));
    }

    /** Opens the dialler with the number filled in (no CALL_PHONE permission needed). */
    @JavascriptInterface
    public void dial(final String phone) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try { activity.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.replaceAll("[^0-9+]", "")))); }
                catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public String appInfo() {
        String version = "1.0.0-demo";
        try { version = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionName; } catch (Exception ignored) { }
        return "{\"platform\":\"android\",\"version\":\"" + version + "\",\"sdk\":" + Build.VERSION.SDK_INT
            + ",\"device\":\"" + (Build.MANUFACTURER + " " + Build.MODEL).replace("\"", "") + "\"}";
    }
}
