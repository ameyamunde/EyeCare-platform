/* Smart Rx (PRD Epic 5): diagnosis with laterality, templates, taper builder, allergy check,
   spectacle Rx from final refraction, advice/procedure/follow-up, preview, sign & route, countersign */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var st = null, masters = null;
  var FREQ = ['Once daily', 'Once daily at bedtime', '2 times/day', '3 times/day', '4 times/day', '6 times/day', 'Every 2 hours', 'taper'];
  var DUR = ['3 days', '5 days', '7 days', '1 week', '2 weeks', '4 weeks', '1 month', '3 months', 'Long term'];
  var ADVICE = ['Wear glasses full time', 'Use glasses for near work', 'Avoid rubbing eyes', 'Cold compresses', 'Eye shield at night', 'Avoid head bath for 1 week', 'Bring all drops at next visit', 'Dilate at next visit', 'Control blood sugar', '20-20-20 screen breaks'];
  var PROCS = ['None', 'Cataract surgery', 'YAG capsulotomy', 'Laser PRP', 'Intravitreal injection', 'Trabeculectomy', 'Pterygium excision'];
  var FU = [['0', 'None'], ['7', '1 wk'], ['14', '2 wk'], ['30', '1 mo'], ['90', '3 mo'], ['180', '6 mo'], ['365', '1 yr']];
  var HI = { 'Once daily': 'दिन में 1 बार', '2 times/day': 'दिन में 2 बार', '3 times/day': 'दिन में 3 बार', '4 times/day': 'दिन में 4 बार', '6 times/day': 'दिन में 6 बार', 'Once daily at bedtime': 'रात को सोते समय' };

  function load(visitId) {
    return Promise.all([K.data.getVisit(visitId), K.data.listDiagnosisMaster(), K.data.listDrugMaster(), K.data.listRxTemplates()]).then(function (r) {
      var v = r[0]; masters = { dx: r[1], drugs: r[2], tpl: r[3] };
      if (!st || st.visitId !== visitId) {
        var rx = v.rx || {}, fin = v.exam.refraction && v.exam.refraction.final;
        st = { visitId: visitId, diagnoses: U.clone(v.diagnoses || []), drugs: U.clone(rx.drugs || []), overrides: U.clone(rx.overrides || []),
          includeSpec: !!(rx.spectacle || (fin && K.session.activeRole === 'optometrist')),
          spectacle: rx.spectacle ? U.clone(rx.spectacle) : fin ? { OD: U.clone(fin.OD), OS: U.clone(fin.OS), pd: v.exam.refraction.pd || 62, lensAdvice: (fin.OD.add || fin.OS.add) ? 'Progressive' : 'Single vision', coating: 'Anti-reflective', validMonths: 12 } : null,
          advice: U.clone(rx.advice || []), followUpDays: rx.followUpDays || 0, procedure: rx.procedure ? U.clone(rx.procedure) : { name: 'None', eye: 'OD', note: '' },
          investigations: (v.exam.investigations && v.exam.investigations.ordered) || [], dxQ: '' };
      }
      return v;
    });
  }
  function drugLine(l, i, p) {
    var hit = K.domain.allergyHit ? K.domain.allergyHit(p, l.sku) : null, ov = st.overrides.filter(function (o) { return o.sku === l.sku; })[0];
    return '<div class="card" style="' + (hit && !ov ? 'border-color:var(--crit);background:var(--crit-soft)' : '') + '"><div class="row between"><b class="grow">' + esc(l.name) + '</b><button class="icon-btn" style="color:var(--muted)" data-act="rmDrug" data-i="' + i + '" aria-label="Remove">&#10005;</button></div>' +
      (hit ? (ov ? '<div class="small" style="color:var(--warn)">Allergy override: ' + esc(ov.reason) + '</div>' : '<div class="small" style="color:var(--crit)"><b>Blocked: allergy to ' + esc(hit) + '.</b> <button class="btn danger sm" data-act="override" data-sku="' + esc(l.sku) + '">Override with reason</button></div>') : '') +
      '<div class="grid3" style="margin-top:6px"><div><label class="small">Eye</label>' + C.select('d_eye_' + i, ['OD', 'OS', 'OU'], l.eye) + '</div><div><label class="small">Frequency</label>' + C.select('d_freq_' + i, FREQ, l.freq) + '</div><div><label class="small">Duration</label>' + C.select('d_dur_' + i, DUR.indexOf(l.duration) >= 0 ? DUR : DUR.concat([l.duration]), l.duration) + '</div></div>' +
      (l.freq === 'taper' ? '<div class="small" style="margin-top:6px"><b>Taper:</b> ' + (l.taper || []).map(esc).join(' → ') + ' <button class="btn ghost sm" data-act="taper" data-i="' + i + '">Edit taper</button></div>' : '') + '</div>';
  }
  function readLines() {
    var root = document.getElementById('content');
    st.drugs.forEach(function (l, i) { var e = C.fieldVal(root, 'd_eye_' + i); if (e) { l.eye = e; l.freq = C.fieldVal(root, 'd_freq_' + i); l.duration = C.fieldVal(root, 'd_dur_' + i); if (l.freq === 'taper' && !l.taper) l.taper = ['6 times/day x 1 week', '4 times/day x 1 week', '3 times/day x 1 week', '2 times/day x 1 week']; } });
    st.diagnoses.forEach(function (d, i) { var e = C.fieldVal(root, 'dx_eye_' + i); if (e) d.eye = e; });
    var pn = C.fieldVal(root, 'proc'); if (pn !== null) { st.procedure.name = pn; st.procedure.eye = C.fieldVal(root, 'proc_eye') || 'OD'; st.procedure.note = C.fieldVal(root, 'proc_note') || ''; }
    if (st.spectacle && document.querySelector('[data-step=sp_sph_OD]')) {
      ['OD', 'OS'].forEach(function (e) { st.spectacle[e] = { sph: C.stepVal(root, 'sp_sph_' + e), cyl: C.stepVal(root, 'sp_cyl_' + e), axis: C.stepVal(root, 'sp_axis_' + e), add: C.stepVal(root, 'sp_add_' + e) || 0 }; });
      st.spectacle.pd = C.stepVal(root, 'sp_pd'); st.spectacle.lensAdvice = C.fieldVal(root, 'sp_lens'); st.spectacle.coating = C.fieldVal(root, 'sp_coat'); st.spectacle.validMonths = Number(C.fieldVal(root, 'sp_valid'));
    }
    var fu = C.segVal(root, 'fu'); if (fu !== null) st.followUpDays = Number(fu);
  }
  function addDrug(sku, extra) {
    var d = masters.drugs.filter(function (x) { return x.sku === sku; })[0]; if (!d) return;
    if (st.drugs.some(function (l) { return l.sku === sku; })) { K.ui.toast(d.name + ' is already on the Rx'); return; }
    st.drugs.push(Object.assign({ sku: sku, name: d.name, eye: 'OU', freq: '4 times/day', duration: '1 week', taper: null, qty: 1 }, extra || {}));
  }

  K.screens.rx = {
    title: 'Smart Rx', tab: 'home', noTabs: true,
    render: function (pr) {
      return load(pr[0]).then(function (v) {
        var p = v.patient, role = K.session.activeRole, optom = role === 'optometrist';
        if (v.rx && v.rx.signedAt) { setTimeout(function () { K.go('rxview/' + v.id, true); }, 0); return ''; }
        var counters = v.rx && v.rx.awaitingCountersign;
        var q = st.dxQ.toLowerCase();
        var dxList = q ? masters.dx.filter(function (d) { return d.name.toLowerCase().indexOf(q) >= 0 || d.code.toLowerCase().indexOf(q) >= 0; }).slice(0, 8) : masters.dx.slice(0, 8);
        var sp = st.spectacle;
        var specHtml = sp ? '<div class="eyes">' + ['OD', 'OS'].map(function (e) {
          return '<div class="eye ' + e.toLowerCase() + '"><div class="eye-h"><span>' + e + '</span></div>' + C.stepper('sp_sph_' + e, 'Sphere', sp[e].sph, { min: -30, max: 30, inc: 0.25 }) + C.stepper('sp_cyl_' + e, 'Cylinder', sp[e].cyl, { min: -10, max: 10, inc: 0.25 }) +
            C.stepper('sp_axis_' + e, 'Axis', sp[e].axis, { fmt: 'axis', min: 1, max: 180, inc: 5 }) + C.stepper('sp_add_' + e, 'Add', sp[e].add, { min: 0, max: 4, inc: 0.25 }) + '</div>';
        }).join('') + '</div><div class="grid2" style="margin-top:8px"><div>' + C.stepper('sp_pd', 'PD (mm)', sp.pd, { fmt: 'int', min: 40, max: 80, inc: 1 }) + '</div><div><label class="small">Valid for</label>' + C.select('sp_valid', ['3', '6', '12', '24'], String(sp.validMonths || 12)) + ' <span class="small muted">months</span></div></div>' +
          '<div class="grid2"><div><label class="small">Lens advice</label>' + C.select('sp_lens', ['Single vision', 'Bifocal', 'Progressive', 'Single vision, polycarbonate', 'Reading only'], sp.lensAdvice) + '</div><div><label class="small">Coating / tint</label>' + C.select('sp_coat', ['Anti-reflective', 'Blue-cut', 'Photochromic', 'None'], sp.coating) + '</div></div>' : '<div class="small muted">No final refraction recorded. <button class="btn ghost sm" data-act="toRefraction">Go to refraction</button></div>';
        return C.banner(p, v) +
          (counters && role === 'doctor' ? '<div class="banner-note">Spectacle Rx drafted by the optometrist; review and countersign (CT-05-13).</div>' : '') +
          (optom ? '<div class="banner-info small">Optometrists draft the spectacle Rx; a doctor countersigns before it goes to optical (clinic setting).</div>' : '') +
          '<div class="h2">Diagnosis</div><div class="card">' +
          (st.diagnoses.length ? st.diagnoses.map(function (d, i) { return '<div class="row" style="margin-bottom:6px">' + C.pill(d.code, 'brand') + '<span class="grow small">' + esc(d.name) + '</span><div style="width:84px">' + C.select('dx_eye_' + i, ['OD', 'OS', 'OU'], d.eye) + '</div><button class="icon-btn" style="color:var(--muted)" data-act="rmDx" data-i="' + i + '">&#10005;</button></div>'; }).join('') : '<div class="small muted" style="margin-bottom:6px">Add at least one diagnosis with the eye.</div>') +
          '<input class="input" data-input="dxq" id="dxq" placeholder="Search diagnosis or ICD code" value="' + esc(st.dxQ) + '"><div class="row wrap" style="margin-top:6px">' + dxList.map(function (d) { return '<button class="chip" data-act="addDx" data-c="' + esc(d.code) + '">' + esc(d.name) + ' <span class="muted small">' + esc(d.code) + '</span></button>'; }).join('') + '</div></div>' +
          (optom ? '' : '<div class="h2">Medicines</div><div class="row wrap" style="margin-bottom:8px">' + masters.tpl.map(function (t) { return '<button class="chip" data-act="tpl" data-id="' + t.id + '">' + K.icon('sparkle', 'sm') + '' + esc(t.name) + '</button>'; }).join('') + '</div>' +
            (st.drugs.length ? st.drugs.map(function (l, i) { return drugLine(l, i, p); }).join('') : '<div class="small muted">No medicines. Pick a template or add a drug.</div>') +
            '<button class="btn ghost sm" style="margin-top:8px" data-act="addDrug">' + K.icon('plus', 'sm') + 'Add drug</button>') +
          '<div class="h2 row between"><span>Spectacle Rx</span><label class="check" style="min-height:0;padding:0;font-size:14px;font-weight:500"><input type="checkbox" data-change="toggleSpec"' + (st.includeSpec ? ' checked' : '') + '> Include</label></div>' +
          (st.includeSpec ? '<div class="card">' + specHtml + '</div>' : '') +
          (optom ? '' : '<div class="h2">Advice, procedure and follow-up</div><div class="card"><div class="row wrap">' + ADVICE.map(function (a) { return '<button class="chip ' + (st.advice.indexOf(a) >= 0 ? 'on' : '') + '" data-act="advice" data-a="' + esc(a) + '">' + esc(a) + '</button>'; }).join('') + '</div>' +
            '<div class="grid2" style="margin-top:8px"><div><label class="small">Procedure advised</label>' + C.select('proc', PROCS, st.procedure.name) + '</div><div><label class="small">Eye</label>' + C.select('proc_eye', ['OD', 'OS', 'OU'], st.procedure.eye) + '</div></div>' +
            '<label class="small">Note for counsellor</label><input class="input" data-field="proc_note" value="' + esc(st.procedure.note) + '" placeholder="e.g. NS3 OD, discuss toric">' +
            (st.investigations.length ? '<div class="small" style="margin-top:6px">Tests ordered: ' + st.investigations.map(function (t) { return C.pill(t, 'info'); }).join(' ') + '</div>' : '') +
            '<label class="f">Follow-up</label>' + C.seg('fu', FU, String(st.followUpDays || 0)) + '</div>') +
          '<div class="btn-row sticky-actions"><button class="btn ghost" data-act="preview">Preview</button>' +
          (counters && role === 'doctor' ? '<button class="btn" data-act="countersign">Countersign</button>' : '<button class="btn" data-act="sign">' + (optom ? 'Send for countersign' : 'Sign and send') + '</button>') + '</div>';
      });
    },
    mount: function () { var q = document.getElementById('dxq'); if (q && st.dxQ) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } },
    actions: {
      dxq: function (el) { st.dxQ = el.value; readLines(); clearTimeout(st.t); st.t = setTimeout(function () { K.refresh(); }, 200); },
      addDx: function (el) {
        readLines(); var d = masters.dx.filter(function (x) { return x.code === el.getAttribute('data-c'); })[0];
        if (!st.diagnoses.some(function (x) { return x.code === d.code; })) st.diagnoses.push({ code: d.code, name: d.name, eye: 'OU' });
        st.dxQ = ''; var tpl = masters.tpl.filter(function (t) { return t.dx.indexOf(d.code) >= 0; })[0];
        K.refresh(); if (tpl && K.session.activeRole === 'doctor') K.ui.toast('Tip: template “' + tpl.name + '” matches this diagnosis');
      },
      rmDx: function (el) { readLines(); st.diagnoses.splice(Number(el.getAttribute('data-i')), 1); K.refresh(); },
      tpl: function (el) {
        readLines(); var t = masters.tpl.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0];
        t.lines.forEach(function (l) { addDrug(l.sku, { freq: l.freq, duration: l.duration, taper: l.taper ? U.clone(l.taper) : null }); });
        K.ui.toast('Template applied — every line stays editable'); K.refresh();
      },
      addDrug: function () {
        readLines();
        K.ui.sheet('Add drug', '<input class="input" id="dg-q" placeholder="Search drug">' + '<div class="list" id="dg-l" style="margin-top:8px">' + masters.drugs.map(function (d) { return '<div class="li" data-sact="pick" data-sku="' + d.sku + '"><div class="grow"><b>' + esc(d.name) + '</b><div class="small muted">' + esc(d.cls) + ' · stock ' + d.qty + '</div></div></div>'; }).join('') + '</div>', {
          pick: function (x) { addDrug(x.getAttribute('data-sku')); K.ui.closeSheet(); K.refresh(); } });
        document.getElementById('dg-q').addEventListener('input', function (e) { var q = e.target.value.toLowerCase(); Array.prototype.forEach.call(document.querySelectorAll('#dg-l .li'), function (li) { li.style.display = li.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none'; }); });
      },
      rmDrug: function (el) { readLines(); var l = st.drugs.splice(Number(el.getAttribute('data-i')), 1)[0]; st.overrides = st.overrides.filter(function (o) { return o.sku !== l.sku; }); K.refresh(); },
      override: function (el) {
        readLines(); var sku = el.getAttribute('data-sku');
        return K.ui.prompt('Allergy override', 'Reason (logged and visible to the owner)', { required: true, placeholder: 'e.g. Previous tolerance confirmed with patient' }).then(function (r) { if (r) { st.overrides.push({ sku: sku, reason: r }); K.refresh(); } });
      },
      taper: function (el) {
        readLines(); var l = st.drugs[Number(el.getAttribute('data-i'))];
        return K.ui.prompt('Taper steps', 'One step per line', { multiline: true, value: (l.taper || []).join('\n'), help: 'Prints as a table and drives the Patient app drop reminders (CT-05-04).' }).then(function (t) { if (t !== null) { l.taper = t.split('\n').map(function (x) { return x.trim(); }).filter(Boolean); K.refresh(); } });
      },
      toggleSpec: function (el) { readLines(); st.includeSpec = el.checked; K.refresh(); },
      advice: function (el) { readLines(); var a = el.getAttribute('data-a'), i = st.advice.indexOf(a); if (i >= 0) st.advice.splice(i, 1); else st.advice.push(a); K.refresh(); },
      toRefraction: function () { K.back(); },
      preview: function () { readLines(); return K.data.getVisit(st.visitId).then(function (v) { K.ui.sheet('Preview', K.rxPrintout(v, payload(), K.session.user), {}); }); },
      sign: function () {
        readLines(); var pl = payload();
        if (!pl.diagnoses.length) { K.ui.toast('Add at least one diagnosis'); return; }
        return K.data.signRx(st.visitId, pl).then(function (v) {
          K.native.vibrate(); var id = st.visitId; st = null;
          if (v.rx.awaitingCountersign) { K.ui.toast('Sent to the doctor for countersign'); K.go(K.homeRoute()); return; }
          K.ui.toast('Signed — sent to patient on WhatsApp; routed to ' + K.stageLabel(v.stage)); K.go('rxview/' + id, true);
        });
      },
      countersign: function () { var id = st.visitId; return K.data.countersignRx(id).then(function () { st = null; K.ui.toast('Countersigned — sent to optical'); K.go('rxview/' + id, true); }); }
    }
  };
  function payload() {
    return { diagnoses: st.diagnoses, drugs: K.session.activeRole === 'optometrist' ? [] : st.drugs, spectacle: st.includeSpec ? st.spectacle : null, cl: null, advice: st.advice,
      followUpDays: st.followUpDays || null, procedure: st.procedure.name !== 'None' ? st.procedure : null, investigations: st.investigations, overrides: st.overrides };
  }

  /* ---------- Printout (also used for preview) ---------- */
  K.rxPrintout = function (v, rx, doctor, bilingual) {
    var p = v.patient;
    var drugs = (rx.drugs || []).map(function (d) {
      if (d.freq === 'taper') return '<tr><td>' + esc(d.name) + '</td><td>' + d.eye + '</td><td>Tapering dose</td><td>' + esc(d.duration) + '</td></tr><tr><td colspan="4" style="font-size:11.5px;background:#F0F9FF">' + (d.taper || []).map(function (t, i) { return '<b>Step ' + (i + 1) + ':</b> ' + esc(t); }).join(' &nbsp;\u2192&nbsp; ') + '</td></tr>';
      return '<tr><td>' + esc(d.name) + '</td><td>' + d.eye + '</td><td>' + esc(d.freq) + (bilingual && HI[d.freq] ? '<br><span style="color:#555">' + HI[d.freq] + '</span>' : '') + '</td><td>' + esc(d.duration) + '</td></tr>';
    }).join('');
    var sp = rx.spectacle;
    return '<div class="rx-preview"><div style="display:flex;justify-content:space-between"><div style="display:flex;gap:8px;align-items:center">' + K.logoFull(38) + '<div><h4>Drishti Eye Care (Demo)</h4><div style="font-size:11px">Kothrud, Pune · Ph 020-0000-0000</div></div></div><div style="text-align:right;font-size:11px">' + U.dateTime(K.clock.now()) + '<br>Token ' + v.token + '</div></div><hr>' +
      '<div><b>' + esc(p.name) + '</b>, ' + C.ageSex(p) + ' · ' + esc(p.uhid) + (p.allergies.length ? ' · <b style="color:#c62828">Allergies: ' + esc(p.allergies.join(', ')) + '</b>' : '') + '</div>' +
      '<div style="margin-top:6px"><b>Diagnosis:</b> ' + (rx.diagnoses || v.diagnoses).map(function (d) { return esc(d.name) + ' (' + d.eye + ')'; }).join('; ') + '</div>' +
      (drugs ? '<table><tr><th>Medicine</th><th>Eye</th><th>How often</th><th>For</th></tr>' + drugs + '</table>' : '') +
      (sp ? '<div style="margin-top:6px"><b>Spectacle prescription</b> (valid ' + (sp.validMonths || 12) + ' months)</div><table><tr><th></th><th>Sph</th><th>Cyl</th><th>Axis</th><th>Add</th></tr>' + ['OD', 'OS'].map(function (e) { return '<tr><td><b>' + e + '</b></td><td>' + U.dio(sp[e].sph) + '</td><td>' + U.dio(sp[e].cyl) + '</td><td>' + (sp[e].axis || '—') + '</td><td>' + (sp[e].add ? U.dio(sp[e].add) : '—') + '</td></tr>'; }).join('') + '</table><div style="font-size:12px">PD ' + (sp.pd || '—') + ' mm · ' + esc(sp.lensAdvice || '') + ' · ' + esc(sp.coating || '') + '</div>' : '') +
      ((rx.advice || []).length ? '<div style="margin-top:6px"><b>Advice:</b> ' + rx.advice.map(esc).join('; ') + '</div>' : '') +
      (rx.procedure ? '<div><b>Advised:</b> ' + esc(rx.procedure.name) + ' (' + rx.procedure.eye + ')</div>' : '') +
      (rx.followUpDays ? '<div><b>Review after:</b> ' + rx.followUpDays + ' days</div>' : '') +
      '<div style="margin-top:10px;text-align:right"><div class="sig">' + esc(doctor.name) + '</div><div style="font-size:11px">' + esc(doctor.qual || '') + ' · Reg. ' + esc(doctor.regNo || '') + '</div></div>' +
      '<div style="font-size:10px;color:#666;margin-top:8px">Sudden loss of vision, severe pain or flashes: come to the clinic immediately. Demo printout — not a real prescription.<br>Powered by Eyespyes</div></div>';
  };

  var bi = false;
  K.screens.rxview = {
    title: 'Prescription', tab: 'home', noTabs: true,
    render: function (pr) {
      return Promise.all([K.data.getVisit(pr[0]), K.data.listUsers()]).then(function (r) {
        var v = r[0], doc = r[1].filter(function (u) { return u.id === (v.rx.signedBy || v.signedBy); })[0] || K.session.user;
        return C.banner(v.patient, v) + '<div class="row between" style="margin-bottom:8px">' + C.stagePill(v.stage) + '<label class="check" style="min-height:0;padding:0"><input type="checkbox" data-change="bi"' + (bi ? ' checked' : '') + '> English + Hindi</label></div>' +
          K.rxPrintout(v, Object.assign({ diagnoses: v.diagnoses }, v.rx), doc, bi) +
          '<div class="btn-row" style="margin-top:12px"><button class="btn ghost" data-act="print">Print</button><button class="btn" data-act="share">Share</button></div>' +
          '<div class="btn-row" style="margin-top:8px"><button class="btn secondary" data-act="queue">Back to my queue</button></div>';
      });
    },
    actions: {
      bi: function (el) { bi = el.checked; K.refresh(); },
      print: function () { K.ui.toast('Sent to clinic printer (Bluetooth/Wi-Fi printing in production)'); },
      share: function (el, ev, pr) { return K.data.getVisit(pr[0]).then(function (v) { K.native.share('Prescription — ' + v.patient.name, 'Prescription for ' + v.patient.name + ' (' + v.patient.uhid + '): ' + v.diagnoses.map(function (d) { return d.name + ' ' + d.eye; }).join('; ') + '. Drops: ' + v.rx.drugs.map(function (d) { return d.name + ' ' + d.eye + ' ' + d.freq; }).join('; ')); }); },
      queue: function () { K.go(K.homeRoute()); }
    }
  };
})();
