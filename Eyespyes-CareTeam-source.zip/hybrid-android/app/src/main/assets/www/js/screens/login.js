/* Login (PRD Epic 1): split hero + sign-in card. Demo quick sign-in by role, or mobile + PIN */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc;
  var mode = 'role';
  K.ROLE_STYLE = { owner: ['chart', '#0369A1'], doctor: ['steth', '#0277BD'], optometrist: ['eye', '#0EA5E9'], front_desk: ['users', '#F59E0B'], counsellor: ['heart', '#8B5CF6'],
    optician: ['glasses', '#06B6D4'], nurse: ['bed', '#10B981'], ot: ['ot', '#6366F1'], pharmacist: ['pill', '#14B8A6'], billing: ['wallet', '#F97316'] };
  K.roleIcon = function (r, size) { var st = K.ROLE_STYLE[r] || ['user', '#0277BD']; return '<span class="ri" style="background:' + st[1] + (size ? ';width:' + size + 'px;height:' + size + 'px' : '') + '">' + K.icon(st[0]) + '</span>'; };

  K.screens.login = {
    title: 'Sign in', root: true, noTabs: true,
    render: function () {
      return K.data.listDemoUsers().then(function (users) {
        var roleList = '<div class="role-grid">' + users.map(function (u) {
          return '<button class="role-card" data-act="as" data-id="' + esc(u.id) + '">' + K.roleIcon(u.roles[0]) + '<span style="min-width:0"><b>' + esc(u.name) + '</b><span>' + u.roles.map(function (r) { return esc(K.ROLES[r]); }).join(' + ') + '</span></span></button>';
        }).join('') + '</div>';
        var pinForm = '<label class="f" for="lg-phone">Registered mobile number</label><input class="input" id="lg-phone" inputmode="numeric" maxlength="10" placeholder="10-digit mobile" value="9000000002">' +
          '<label class="f" for="lg-pin">PIN</label><input class="input" id="lg-pin" type="password" inputmode="numeric" maxlength="6" placeholder="4–6 digit PIN">' +
          '<p class="small muted">Demo: every user’s PIN is 1234. In production the first login uses an OTP, then a PIN or fingerprint (CT-01-01/02).</p>' +
          '<button class="btn block" data-act="login">' + K.icon('lock', 'sm') + ' Sign in securely</button>';
        return '<div class="login-wrap"><section class="login-hero"><div class="brand-card">' + K.logoFull(84) + '<span class="care-team">Care Team</span></div>' +
          '<h1>Every eye, every visit,<br>one calm workflow.</h1><p>The Eyespyes Care Team app for doctors, optometrists and clinic staff.</p>' +
          '<ul><li>' + K.icon('kanban') + 'Live patient queue across every room</li><li>' + K.icon('eye') + 'OD / OS exam with device import</li><li>' + K.icon('file') + 'Smart prescriptions with allergy checks</li><li>' + K.icon('shield') + 'Consent, audit and role-based access built in</li></ul></section>' +
          '<section class="login-panel"><div class="login-card">' +
          '<div class="h2" style="margin-top:4px">Sign in</div>' +
          '<div class="seg" data-seg="lmode" style="margin-bottom:14px"><button type="button" data-val="role" class="' + (mode === 'role' ? 'on' : '') + '">Try a role (demo)</button><button type="button" data-val="pin" class="' + (mode === 'pin' ? 'on' : '') + '">Mobile + PIN</button></div>' +
          (mode === 'role' ? '<p class="small muted" style="margin:0 2px 10px">Pick who you want to be. All patients and data are fictional and stay on this device.</p>' + roleList : pinForm) +
          '<div class="tip" style="margin-top:16px"><span class="ti2">' + K.icon('sparkle') + '</span><div class="small"><b>New here?</b> After signing in, tap <b>Demo</b> (top right) to walk one patient through every role in eight taps.</div></div>' +
          '<p class="small muted" style="text-align:center;margin-top:12px">Eyespyes Care Team · v' + esc(K.native.appInfo().version || '1.0') + ' · ' + esc(K.config.dataMode) + ' data</p></div></section></div>';
      });
    },
    mount: function (root) { root.addEventListener('segchange', function (e) { if (e.detail.name === 'lmode') { mode = e.detail.value; K.refresh(); } }); },
    actions: {
      as: function (el) { return K.data.loginAs(el.getAttribute('data-id')).then(K.afterLogin); },
      login: function () {
        var ph = document.getElementById('lg-phone').value, pin = document.getElementById('lg-pin').value;
        if (!/^\d{10}$/.test(ph)) { K.ui.error('Enter a 10-digit mobile number'); return; }
        return K.data.login(ph, pin).then(K.afterLogin);
      }
    }
  };
})();
