/* Patients (PRD Epic 2): search, registration with duplicate check + consent, profile, trends, check-in */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var sState = { q: '' }, searchTimer;

  function row(p, act) {
    return '<div class="li" data-act="' + act + '" data-id="' + esc(p.id) + '">' + C.avatar(p.name) + '<div class="grow"><b class="ellipsis" style="display:block">' + esc(p.name) + '</b>' +
      '<div class="small muted">' + C.ageSex(p) + ' · ' + esc(p.uhid) + ' · ' + esc(p.phone) + '</div><div class="qmeta">' + C.flags(p) + '</div></div><span class="chev">' + K.icon('chev', 'sm') + '</span></div>';
  }

  K.screens.patients = {
    title: function (pr) { return pr[0] === 'checkin' ? 'Check in a patient' : 'Patients'; }, tab: 'patients', root: true,
    render: function (pr) {
      var checkin = pr[0] === 'checkin';
      return K.data.searchPatients(sState.q).then(function (list) {
        return '<input class="input" id="ps-q" data-input="q" placeholder="Search name, mobile, UHID or ABHA" value="' + esc(sState.q) + '" autocomplete="off">' +
          '<div class="row" style="margin:8px 0"><button class="btn secondary sm" data-act="scan">' + K.icon('scan', 'sm') + 'Scan patient QR</button><span class="small muted grow">' + (sState.q ? list.length + ' found' : 'Recent patients') + '</span></div>' +
          '<div class="list" id="ps-list">' + (list.length ? list.map(function (p) { return row(p, checkin ? 'pickCheckin' : 'open'); }).join('') : C.empty('No match', 'Register a new patient below')) + '</div>' +
          '<button class="btn fab" data-act="register">' + K.icon('plus', 'sm') + 'Register</button>';
      });
    },
    mount: function (root, pr) { var q = root.querySelector('#ps-q'); if (pr[0] === 'checkin' || sState.q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } },
    actions: {
      q: function (el) { sState.q = el.value; clearTimeout(searchTimer); searchTimer = setTimeout(function () { K.refresh(); setTimeout(function () { var q = document.getElementById('ps-q'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 30); }, 220); },
      open: function (el) { K.go('patient/' + el.getAttribute('data-id')); },
      pickCheckin: function (el) { K.checkInSheet(el.getAttribute('data-id')); },
      register: function () { K.go('register' + (K.currentScreen().params[0] === 'checkin' ? '/checkin' : '')); },
      scan: function () {
        return K.ui.prompt('Scan patient QR', 'Camera scanning runs in the production build. Demo: type a UHID', { placeholder: 'e.g. DEC-24100', value: 'DEC-24100', ok: 'Find' }).then(function (code) {
          if (!code) return;
          return K.data.searchPatients(code).then(function (r) { if (r.length) K.go('patient/' + r[0].id); else K.ui.toast('No patient with that code'); });
        });
      }
    }
  };
  K.screens.search = K.screens.patients;

  /* ---------- Check-in sheet (CT-03-03) ---------- */
  K.checkInSheet = function (patientId) {
    return Promise.all([K.data.getPatient(patientId), K.data.listUsers('doctor'), K.data.listAppointments(U.isoDay(K.clock.now()))]).then(function (r) {
      var p = r[0], docs = r[1], appt = r[2].filter(function (a) { return a.patientId === patientId && a.status === 'booked'; })[0];
      K.ui.sheet('Check in', C.banner(p) + (appt ? '<div class="banner-info">Appointment at ' + U.time(appt.ts) + ' with ' + esc(appt.doctor.name) + ' will be marked arrived.</div>' : '') +
        '<label class="f">Visit type</label>' + C.seg('type', [['new', 'New'], ['review', 'Review'], ['postop', 'Post-op']], appt ? appt.type : 'review') +
        '<label class="f">Doctor</label><select class="input" id="ci-doc">' + docs.map(function (d) { return '<option value="' + d.id + '"' + (appt && appt.doctorId === d.id ? ' selected' : '') + '>' + esc(d.name) + ' — ' + esc(d.special || '') + '</option>'; }).join('') + '</select>' +
        '<label class="f">Priority</label><div class="row wrap">' + Object.keys(K.PRIORITY).map(function (k) { return '<label class="check" style="min-height:36px;padding:4px 8px 4px 0"><input type="checkbox" value="' + k + '"> ' + esc(K.PRIORITY[k]) + '</label>'; }).join('') + '</div>' +
        '<p class="small muted">Elderly (70+) and child (under 12) flags are added automatically. A WhatsApp with the token number is sent.</p>' +
        '<button class="btn block" data-sact="go">Check in and issue token</button>', {
        go: function () {
          var s = K.ui.sheetEl();
          var pr = Array.prototype.map.call(s.querySelectorAll('input[type=checkbox]:checked'), function (x) { return x.value; });
          return K.data.checkIn(patientId, { type: C.segVal(s, 'type'), doctorId: s.querySelector('#ci-doc').value, priority: pr, appointmentId: appt && appt.id }).then(function (v) {
            K.ui.closeSheet(); K.native.vibrate();
            K.ui.sheet('Token ' + v.token, '<div style="text-align:center"><div class="token" style="width:96px;height:96px;font-size:40px;margin:8px auto;border-radius:20px">' + v.token + '</div><b>' + esc(v.patient.name) + '</b><p class="muted small">Added to the queue · WhatsApp sent to ' + esc(v.patient.phone) + '</p></div>' +
              '<div class="btn-row"><button class="btn ghost" data-sact="print">Print token</button><button class="btn" data-sact="done">Done</button></div>',
              { print: function () { K.ui.toast('Sent to Bluetooth token printer (demo)'); }, done: function () { K.ui.closeSheet(); K.go('queue'); } });
          });
        }
      });
    });
  };

  /* ---------- Registration (CT-02-01..03) ---------- */
  K.screens.register = {
    title: 'Register patient', tab: 'patients', noTabs: true,
    render: function () {
      return Promise.resolve('<div class="card"><div class="small muted">Required fields first; the rest can be completed later (CT-02-01).</div>' +
        '<label class="f">Full name *</label><input class="input" name="name" placeholder="As on ID" autocomplete="off">' +
        '<label class="f">Mobile number *</label><input class="input" name="phone" inputmode="numeric" maxlength="10" placeholder="10 digits" data-change="phone">' +
        '<div id="fam"></div>' +
        '<label class="f">Sex *</label>' + C.seg('sex', [['F', 'Female'], ['M', 'Male'], ['O', 'Other']], '') +
        '<div class="grid2"><div><label class="f">Age (years) *</label><input class="input" name="age" inputmode="numeric" maxlength="3" placeholder="or DOB →"></div><div><label class="f">Date of birth</label><input class="input" name="dob" type="date"></div></div>' +
        '<label class="f">City</label><input class="input" name="city" value="Pune">' +
        '<details style="margin-top:10px"><summary class="small" style="cursor:pointer;font-weight:600">More details (optional)</summary>' +
        '<label class="f">PIN code</label><input class="input" name="pincode" inputmode="numeric" maxlength="6">' +
        '<label class="f">ABHA number / address</label><div class="row"><input class="input grow" name="abha" placeholder="14-digit ABHA or name@abdm"><button class="btn secondary sm" data-act="abha">Verify</button></div>' +
        '<label class="f">Referral source</label><select class="input" name="referral"><option>Walk-in</option><option>Doctor referral</option><option>Camp</option><option>Online</option><option>Insurance</option><option>Other</option></select>' +
        '<label class="f">Payer</label><select class="input" name="payer"><option>Self</option><option>Insurance</option><option>TPA</option><option>Scheme</option><option>Corporate</option></select>' +
        '<label class="f">Known drug allergies (comma separated)</label><input class="input" name="allergies" placeholder="e.g. Sulfonamides, Penicillin">' +
        '<label class="check"><input type="checkbox" name="diabetic"> Diabetic</label><label class="check"><input type="checkbox" name="glaucoma"> Glaucoma / family history</label>' +
        '<label class="f">Guardian / caregiver (minors, dependent adults)</label><div class="grid2"><input class="input" name="gname" placeholder="Name"><input class="input" name="gphone" inputmode="numeric" maxlength="10" placeholder="Mobile"></div></details></div>' +
        '<div class="card"><b>Consent (DPDP)</b><p class="small muted">Read the notice to the patient in their language. Consents are recorded separately and can be withdrawn at any time.</p>' +
        '<label class="check"><input type="checkbox" name="ctreat" checked> Treatment communication: appointments, prescriptions, reports, invoices by WhatsApp/SMS *</label>' +
        '<label class="check"><input type="checkbox" name="cmkt"> Health tips and offers (marketing)</label></div>' +
        '<div id="dups"></div><div class="btn-row" style="margin-top:12px"><button class="btn ghost" data-act="cancel">Cancel</button><button class="btn" data-act="save">Save patient</button></div>');
    },
    actions: {
      cancel: function () { K.back('patients'); },
      phone: function (el) {
        var ph = el.value; if (!/^\d{10}$/.test(ph)) return;
        return K.data.searchPatients(ph).then(function (list) {
          document.getElementById('fam').innerHTML = list.length ? '<div class="banner-info small">Family on this number: ' + list.map(function (p) { return esc(p.name); }).join(', ') + '. Each person gets their own UHID (CT-02-03).</div>' : '';
        });
      },
      abha: function () { K.ui.toast('ABHA verification runs through the ABDM gateway (Phase 2, CT-02-06). Demo: marked as verified.'); },
      save: function (el, ev, pr) {
        var root = document.getElementById('content'), f = C.form(root);
        var d = { name: f.name, phone: f.phone, sex: C.segVal(root, 'sex'), age: f.age, dob: f.dob, city: f.city, pincode: f.pincode, abha: f.abha, referral: f.referral, payer: f.payer,
          allergies: f.allergies ? f.allergies.split(',').map(function (x) { return x.trim(); }).filter(Boolean) : [], flags: { diabetic: f.diabetic, glaucoma: f.glaucoma },
          guardian: f.gname ? { name: f.gname, phone: f.gphone } : null, consent: { treatment: f.ctreat, marketing: f.cmkt } };
        if (!d.name || !d.phone || !d.sex || !(d.age || d.dob)) { K.ui.toast('Fill name, mobile, sex and age'); return; }
        var create = function () {
          return K.data.createPatient(d).then(function (p) {
            K.ui.toast('Registered ' + p.name + ' (' + p.uhid + ')');
            if (pr[0] === 'checkin' || K.session.activeRole === 'front_desk') { K.go('patient/' + p.id, true); setTimeout(function () { K.checkInSheet(p.id); }, 300); } else K.go('patient/' + p.id, true);
          });
        };
        return K.data.findDuplicates({ name: d.name, phone: d.phone, age: d.age, dob: d.dob }).then(function (dups) {
          if (!dups.length) return create();
          K.ui.sheet('Possible duplicate', '<p>These patients look similar (CT-02-02). Pick one to avoid a duplicate record, or confirm this is a new person.</p><div class="list">' +
            dups.map(function (p) { return '<div class="li" data-sact="pick" data-id="' + p.id + '">' + C.avatar(p.name) + '<div class="grow"><b>' + esc(p.name) + '</b><div class="small muted">' + C.ageSex(p) + ' · ' + esc(p.uhid) + ' · ' + esc(p.phone) + '</div></div></div>'; }).join('') +
            '</div><button class="btn block ghost" style="margin-top:12px" data-sact="new">It’s a different person — create new</button>', {
            pick: function (x) { K.ui.closeSheet(); K.go('patient/' + x.getAttribute('data-id'), true); },
            new: function () { K.ui.closeSheet(); return create(); }
          });
        });
      }
    }
  };

  /* ---------- Profile ---------- */
  var pTab = 'overview';
  function trendSvg(points, keyA, keyB, opts) {
    var pts = points.filter(function (t) { return t[keyA] !== undefined && t[keyA] !== null && t[keyA] !== ''; });
    if (pts.length < 2) return '<div class="small muted">Not enough visits for a trend yet.</div>';
    var W = 320, H = 150, L = 34, R = 10, T = 12, B = 26;
    var vals = pts.map(function (t) { return Number(t[keyA]); }).concat(pts.map(function (t) { return Number(t[keyB]); })).filter(function (x) { return !isNaN(x); });
    var lo = Math.min.apply(null, vals.concat([opts.ref || Infinity])) - 2, hi = Math.max.apply(null, vals.concat([opts.ref || -Infinity])) + 2;
    var x = function (i) { return L + i * (W - L - R) / (pts.length - 1); }, y = function (v) { return T + (hi - v) / (hi - lo) * (H - T - B); };
    var line = function (key, col) { return '<polyline fill="none" stroke="' + col + '" stroke-width="2" points="' + pts.map(function (t, i) { return x(i) + ',' + y(Number(t[key])); }).join(' ') + '"/>' +
      pts.map(function (t, i) { return '<circle cx="' + x(i) + '" cy="' + y(Number(t[key])) + '" r="3.5" fill="' + col + '"><title>' + U.date(t.ts) + ': ' + t[key] + '</title></circle>'; }).join(''); };
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;max-width:520px" role="img" aria-label="' + esc(opts.label) + '">' +
      (opts.ref ? '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y(opts.ref) + '" y2="' + y(opts.ref) + '" stroke="var(--warn)" stroke-dasharray="4 3"/><text x="' + (W - R) + '" y="' + (y(opts.ref) - 4) + '" font-size="10" text-anchor="end" fill="var(--warn)">limit ' + opts.ref + '</text>' : '') +
      '<text x="4" y="' + (T + 8) + '" font-size="10" fill="var(--muted)">' + Math.round(hi) + '</text><text x="4" y="' + (H - B) + '" font-size="10" fill="var(--muted)">' + Math.round(lo) + '</text>' +
      line(keyA, 'var(--od)') + line(keyB, 'var(--os)') +
      pts.map(function (t, i) { return (i === 0 || i === pts.length - 1) ? '<text x="' + x(i) + '" y="' + (H - 8) + '" font-size="10" text-anchor="' + (i ? 'end' : 'start') + '" fill="var(--muted)">' + U.date(t.ts) + '</text>' : ''; }).join('') + '</svg>' +
      '<div class="small"><span style="color:var(--od)">● OD (right)</span> &nbsp; <span style="color:var(--os)">● OS (left)</span></div>';
  }
  K.trendSvg = trendSvg;
  var vaNum = function (va) { if (!va || va.indexOf('/') < 0) return null; var p = va.split('/'); return Math.round(Number(p[0]) / Number(p[1]) * 100) / 100; };

  K.screens.patient = {
    title: 'Patient', tab: 'patients',
    render: function (pr) {
      if (K.screens.patient._last !== pr[0]) { K.screens.patient._last = pr[0]; pTab = 'overview'; }
      return K.data.getPatientHistory(pr[0]).then(function (h) {
        var p = h.patient;
        var tabs = [['overview', 'Overview'], ['visits', 'Visits ' + h.visits.length], ['trends', 'Trends'], ['rx', 'Rx'], ['bills', 'Bills'], ['messages', 'Messages']];
        var body = '';
        if (pTab === 'overview') {
          body = '<div class="card"><table class="t"><tr><td class="muted">Date of birth</td><td>' + esc(U.date(p.dob)) + (p.dobEstimated ? ' (estimated)' : '') + '</td></tr>' +
            '<tr><td class="muted">City</td><td>' + esc(p.city) + ' ' + esc(p.pincode) + '</td></tr><tr><td class="muted">ABHA</td><td>' + (p.abha ? esc(p.abha) : '<span class="muted">Not linked</span>') + '</td></tr>' +
            '<tr><td class="muted">Referral</td><td>' + esc(p.referral) + '</td></tr><tr><td class="muted">Payer</td><td>' + esc(p.payer) + '</td></tr>' +
            '<tr><td class="muted">Allergies</td><td>' + (p.allergies.length ? esc(p.allergies.join(', ')) : 'None known') + '</td></tr>' +
            (p.guardian ? '<tr><td class="muted">Guardian</td><td>' + esc(p.guardian.name) + ' · ' + esc(p.guardian.phone) + '</td></tr>' : '') +
            '<tr><td class="muted">Consent</td><td>Treatment: ' + (p.consent.treatment ? 'yes' : 'no') + ' · Marketing: ' + (p.consent.marketing ? 'yes' : 'no') + '<div class="small muted">' + esc(p.consent.version) + ' · ' + U.date(p.consent.ts) + '</div></td></tr></table>' +
            '<button class="btn ghost sm" data-act="editAllergy">Edit allergies</button> <button class="btn ghost sm" data-act="consent">Change consent</button></div>' +
            (h.appointments.filter(function (a) { return a.ts > K.clock.now() && a.status === 'booked'; }).length ? '<div class="h3">Upcoming</div><div class="list">' + h.appointments.filter(function (a) { return a.ts > K.clock.now() && a.status === 'booked'; }).map(function (a) { return '<div class="li"><span class="grow">' + U.dateTime(a.ts) + ' · ' + esc(U.cap(a.type)) + '</span>' + C.pill(a.source, '') + '</div>'; }).join('') + '</div>' : '') +
            (h.jobs.length ? '<div class="h3">Optical orders</div><div class="list">' + h.jobs.map(function (j) { return '<div class="li" data-act="job" data-id="' + j.id + '"><span class="grow">' + esc(j.frame.name) + '<div class="small muted">' + esc(j.lens.name) + '</div></span>' + C.pill(K.JOB_STATUS[j.status], j.status === 'ready' ? 'ok' : 'info') + '</div>'; }).join('') + '</div>' : '') +
            (h.otCases.length ? '<div class="h3">Surgeries</div><div class="list">' + h.otCases.map(function (c) { return '<div class="li" data-act="otcase" data-id="' + c.id + '"><span class="grow">' + esc(c.procedure) + ' ' + esc(c.eye) + '<div class="small muted">' + U.dateTime(c.ts) + '</div></span>' + C.pill(K.OT_STATUS[c.status], c.status === 'completed' ? 'ok' : 'brand') + '</div>'; }).join('') + '</div>' : '');
        } else if (pTab === 'visits') {
          body = '<div class="list">' + h.visits.map(function (v) {
            return '<div class="li" data-act="visit" data-id="' + v.id + '"><div class="grow"><b>' + U.date(v.createdAt) + '</b> ' + C.stagePill(v.stage) + '<div class="small muted">' + esc(v.diagnoses.map(function (d) { return d.name + ' (' + d.eye + ')'; }).join('; ') || 'No diagnosis recorded') + '</div><div class="small muted">' + esc(v.doctor ? v.doctor.name : '') + (v.signedAt ? ' · signed' : '') + '</div></div><span class="chev">' + K.icon('chev', 'sm') + '</span></div>';
          }).join('') + '</div>';
        } else if (pTab === 'trends') {
          var tr = h.trend.map(function (t) { var o = U.clone(t); o.vaOD = vaNum(t.vaOD); o.vaOS = vaNum(t.vaOS); return o; });
          body = '<div class="card"><b>Intraocular pressure (mmHg)</b>' + trendSvg(tr, 'iopOD', 'iopOS', { ref: K.session.settings.iopThreshold, label: 'IOP trend' }) + '</div>' +
            '<div class="card"><b>Visual acuity (decimal; higher is better)</b>' + trendSvg(tr.map(function (t) { var o = U.clone(t); o.vaOD = t.vaOD === null ? null : t.vaOD * 10; o.vaOS = t.vaOS === null ? null : t.vaOS * 10; return o; }), 'vaOD', 'vaOS', { label: 'VA trend' }) +
            '<div class="small muted">Scale ×10 (10 = 6/6).</div></div>' +
            '<div class="card"><b>Cup-to-disc ratio</b>' + trendSvg(tr.map(function (t) { var o = U.clone(t); o.cdrOD = t.cdrOD ? t.cdrOD * 10 : null; o.cdrOS = t.cdrOS ? t.cdrOS * 10 : null; return o; }), 'cdrOD', 'cdrOS', { label: 'CDR trend' }) + '<div class="small muted">Scale ×10 (6 = 0.6).</div></div>';
        } else if (pTab === 'rx') {
          var withRx = h.visits.filter(function (v) { return (v.rx && (v.rx.spectacle || v.rx.drugs.length)) || (v.exam.refraction && v.exam.refraction.final && v.signedAt); });
          body = withRx.length ? withRx.map(function (v) {
            var sp = v.rx.spectacle || (v.exam.refraction && v.exam.refraction.final);
            return '<div class="card"><div class="row between"><b>' + U.date(v.createdAt) + '</b><span class="small muted">' + esc(v.doctor ? v.doctor.name : '') + '</span></div>' +
              (sp ? '<table class="t"><tr><th></th><th>Rx</th></tr><tr><td style="color:var(--od)"><b>OD</b></td><td>' + C.rxText(sp.OD) + '</td></tr><tr><td style="color:var(--os)"><b>OS</b></td><td>' + C.rxText(sp.OS) + '</td></tr></table>' : '') +
              (v.rx.drugs.length ? '<div class="small">' + v.rx.drugs.map(function (d) { return esc(d.name) + ' — ' + esc(d.eye) + ', ' + esc(d.freq); }).join('<br>') + '</div>' : '') + '</div>';
          }).join('') : C.empty('No prescriptions yet');
        } else if (pTab === 'bills') {
          body = h.bills.length ? '<div class="list">' + h.bills.map(function (b) { return '<div class="li" data-act="bill" data-id="' + b.id + '"><span class="grow">' + esc(b.invoiceNo) + '<div class="small muted">' + U.dateTime(b.createdAt) + '</div></span><b>' + U.inr(b.total) + '</b> ' + C.pill(b.status, b.status === 'paid' ? 'ok' : 'warn') + '</div>'; }).join('') + '</div>' : C.empty('No bills');
        } else {
          body = h.messages.length ? '<div class="list">' + h.messages.map(function (m) { return '<div class="li"><div class="grow"><div class="small"><b>' + esc(m.channel) + '</b> · ' + esc(m.template.replace(/_/g, ' ')) + ' · ' + U.dateTime(m.ts) + '</div><div>' + esc(m.text) + '</div></div>' + C.pill(m.status, m.status === 'read' ? 'ok' : 'info') + '</div>'; }).join('') + '</div>' : C.empty('No messages');
        }
        return C.banner(p) + '<div class="btn-row" style="margin-bottom:10px"><button class="btn" data-act="checkin">Check in</button><button class="btn secondary" data-act="book">Book</button><button class="btn ghost" data-act="wa">WhatsApp</button><button class="btn ghost" data-act="call">Call</button></div>' +
          '<div class="tabs">' + tabs.map(function (t) { return '<button data-act="tab" data-t="' + t[0] + '" class="' + (pTab === t[0] ? 'on' : '') + '">' + esc(t[1]) + '</button>'; }).join('') + '</div>' + body;
      });
    },
    actions: {
      tab: function (el) { pTab = el.getAttribute('data-t'); K.refresh(); },
      checkin: function (el, ev, pr) { return K.checkInSheet(pr[0]); },
      book: function (el, ev, pr) { return K.bookSheet(pr[0]); },
      wa: function (el, ev, pr) { return K.ui.prompt('WhatsApp message', 'Message', { multiline: true, value: 'Hello from Drishti Eye Care. ', ok: 'Send' }).then(function (t) { if (t) return K.data.sendMessage(pr[0], 'free_text', t).then(function () { K.ui.toast('Sent (demo WhatsApp)'); }); }); },
      call: function (el, ev, pr) { return K.data.getPatient(pr[0]).then(function (p) { K.native.dial(p.phone); }); },
      visit: function (el) { K.openVisit(el.getAttribute('data-id')); },
      job: function (el) { K.go('job/' + el.getAttribute('data-id')); },
      otcase: function (el) { K.go('otcase/' + el.getAttribute('data-id')); },
      bill: function (el) { K.go('bill/' + el.getAttribute('data-id')); },
      editAllergy: function (el, ev, pr) {
        return K.data.getPatient(pr[0]).then(function (p) {
          return K.ui.prompt('Allergies', 'Drug names or classes, comma separated', { value: p.allergies.join(', '), help: 'Used for allergy checks at prescription time (CT-05-05).' }).then(function (v) {
            if (v === null) return; return K.data.updatePatient(p.id, { allergies: v.split(',').map(function (x) { return x.trim(); }).filter(Boolean) }).then(function () { K.refresh(); K.ui.toast('Allergies updated'); });
          });
        });
      },
      consent: function (el, ev, pr) {
        return K.data.getPatient(pr[0]).then(function (p) {
          K.ui.sheet('Consent', '<label class="check"><input type="checkbox" id="c1"' + (p.consent.treatment ? ' checked' : '') + '> Treatment communication</label><label class="check"><input type="checkbox" id="c2"' + (p.consent.marketing ? ' checked' : '') + '> Marketing</label><p class="small muted">Withdrawal is as easy as giving consent; changes are logged (DPDP).</p><button class="btn block" data-sact="s">Save</button>', {
            s: function () { var c = { treatment: document.getElementById('c1').checked, marketing: document.getElementById('c2').checked, ts: K.clock.now(), version: 'v1.2', channel: 'Care Team app' }; return K.data.updatePatient(p.id, { consent: c }).then(function () { K.ui.closeSheet(); K.refresh(); }); } });
        });
      }
    }
  };
})();
