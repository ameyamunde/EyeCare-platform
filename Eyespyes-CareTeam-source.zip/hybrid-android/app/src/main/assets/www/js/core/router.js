/* Hash router + screen lifecycle + action dispatch.
   A screen: { title, tab, render(params) -> Promise<html>, mount(root, params), actions{}, live } */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util;
  K.screens = {};
  var current = { name: null, params: [], screen: null }, depth = 0, renderSeq = 0, liveTimer;

  /* Memory mode (hosted web build): routes live in an in-page stack instead of the URL hash */
  var MEM = !!window.EYESPYES_MEMORY_ROUTER, stack = ['home'];
  K.go = function (route, replace) {
    route = route.replace(/^#?\/?/, '');
    if (MEM) { if (replace) stack[stack.length - 1] = route; else if (stack[stack.length - 1] !== route) { stack.push(route); depth++; } onRoute(); return; }
    var h = '#/' + route;
    if (replace) { history.replaceState(null, '', h); onRoute(); } else if (location.hash === h) { onRoute(); } else { depth++; location.hash = h; }
  };
  K.back = function (fallback) {
    if (depth > 0) { depth--; if (MEM) { stack.pop(); onRoute(); } else history.back(); }
    else { K.go(fallback || 'home', true); }
  };
  K.refresh = function (keepScroll) { return render(keepScroll !== false); };
  K.currentScreen = function () { return current; };

  function parse() {
    var h = (MEM ? stack[stack.length - 1] : location.hash.replace(/^#\/?/, '')) || 'home';
    var parts = h.split('/').map(decodeURIComponent);
    return { name: parts[0], params: parts.slice(1) };
  }
  function onRoute() {
    var r = parse();
    if (!K.session && r.name !== 'login') { if (MEM) stack = ['login']; else history.replaceState(null, '', '#/login'); r = { name: 'login', params: [] }; }
    var sc = K.screens[r.name] || K.screens.notfound;
    current = { name: r.name, params: r.params, screen: sc };
    K.ui.closeSheet();
    render(false);
  }
  function render(keepScroll) {
    var sc = current.screen, el = document.getElementById('content'), seq = ++renderSeq, scroll = el.scrollTop;
    var tabbar = document.getElementById('tabbar');
    var title = typeof sc.title === 'function' ? sc.title(current.params) : sc.title;
    document.getElementById('top-title').textContent = title || 'Eyespyes Care Team';
    document.getElementById('top-sub').textContent = K.session ? (K.session.user.name + ' · ' + (K.ROLES[K.session.activeRole] || '') + ' · ' + (K.session.branch ? K.session.branch.name : '')) : 'Demo build · data stays on this device';
    var login = current.name === 'login';
    document.getElementById('btn-back').hidden = !!sc.root || login;
    document.getElementById('top-logo').hidden = !sc.root || login || !K.session;
    document.getElementById('btn-search').hidden = !K.session;
    document.getElementById('searchbox').hidden = !K.session;
    document.getElementById('topbar').hidden = login;
    document.getElementById('sidebar').hidden = !K.session || login;
    tabbar.classList.toggle('hidden', !K.session || !!sc.noTabs);
    el.classList.toggle('no-tabs', !K.session || !!sc.noTabs);
    el.style.padding = login ? '0' : '';
    Array.prototype.forEach.call(document.querySelectorAll('#tabbar [data-tab], #sidebar [data-tab]'), function (b) { b.classList.toggle('active', b.getAttribute('data-tab') === sc.tab); });
    if (!keepScroll) el.innerHTML = '<div class="page"><div class="skel" style="height:110px;margin-bottom:12px"></div><div class="skel" style="height:72px;margin-bottom:10px"></div><div class="skel" style="height:72px;margin-bottom:10px"></div><div class="skel" style="height:72px"></div></div>';
    return Promise.resolve().then(function () { return sc.render(current.params); }).then(function (html) {
      if (seq !== renderSeq) return;
      el.innerHTML = login ? html : '<div class="page">' + html + '</div>';
      if (sc.mount) sc.mount(el, current.params);
      el.scrollTop = keepScroll ? scroll : 0;
    }).catch(function (e) {
      console.error(e);
      if (seq !== renderSeq) return;
      el.innerHTML = '<div class="page">' + K.c.empty('Could not load this screen', e.message || String(e), 'alert') + '<div style="text-align:center"><button class="btn" onclick="EYESPYES.go(\'home\')">Go home</button></div></div>';
    });
  }

  /* Action dispatch inside #content */
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('#content [data-act]');
    if (!el || !current.screen) return;
    var fn = current.screen.actions && current.screen.actions[el.getAttribute('data-act')];
    if (fn) { ev.preventDefault(); K.ui.safe(function () { return fn(el, ev, current.params); }, el, ev); }
  });
  document.addEventListener('change', function (ev) {
    var el = ev.target.closest('#content [data-change]');
    if (!el || !current.screen) return;
    var fn = current.screen.actions && current.screen.actions[el.getAttribute('data-change')];
    if (fn) K.ui.safe(function () { return fn(el, ev, current.params); });
  });
  document.addEventListener('input', function (ev) {
    var el = ev.target.closest('#content [data-input]');
    if (!el || !current.screen) return;
    var fn = current.screen.actions && current.screen.actions[el.getAttribute('data-input')];
    if (fn) K.ui.safe(function () { return fn(el, ev, current.params); });
  });

  /* Live screens re-render when data changes (queue boards etc.) */
  function scheduleLive() {
    if (!current.screen || !current.screen.live) return;
    if (!document.getElementById('sheet').hidden) return;
    var a = document.activeElement; if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName) && document.getElementById('content').contains(a)) return;
    clearTimeout(liveTimer); liveTimer = setTimeout(function () { render(true); }, 250);
  }
  K.bus.on('data', scheduleLive);
  K.bus.on('tick', scheduleLive);
  K.bus.on('clock', scheduleLive);

  /* Android hardware back: return true if handled */
  K.onBack = function () {
    if (K.ui.closeSheet()) return true;
    if (current.screen && current.screen.root) return false;
    K.back(); return true;
  };

  if (!MEM) window.addEventListener('hashchange', onRoute);
  var wasWide = window.innerWidth >= 1100, rz;
  K.isWide = function () { return window.innerWidth >= 1100; };
  window.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(function () { if (K.isWide() !== wasWide) { wasWide = K.isWide(); if (current.screen) render(true); } }, 200); });
  K.startRouter = function () { onRoute(); };
})();
