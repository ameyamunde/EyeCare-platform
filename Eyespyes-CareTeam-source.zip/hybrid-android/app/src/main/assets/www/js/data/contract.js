/* ============================================================================
   DATA SERVICE CONTRACT  —  hand-off point for the DBMS / backend team
   ----------------------------------------------------------------------------
   The UI talks ONLY to K.data, an object implementing every method below.
   Every method is async (returns a Promise). Two implementations exist:
     - mock-service.js : in-memory + device storage, used by the demo build
     - api-service.js  : REST stub with endpoint mapping, to be completed by
                         the DBMS / backend team against the real database
   Swap them in app.js (K.config.dataMode = 'mock' | 'api').
   Full entity definitions: docs/DATA_CONTRACT.md
   ========================================================================== */
(function () {
  'use strict';
  var K = window.EYESPYES;

  // name: [HTTP method + path, short description, PRD requirement]
  var M = {
    // ---- Auth & session (Epic 1) ----
    listDemoUsers:      ['GET /auth/demo-users', 'Users shown on the demo login screen', 'CT-01'],
    login:              ['POST /auth/login {phone, pin}', 'Mobile + PIN login; returns user + token', 'CT-01-01'],
    loginAs:            ['POST /auth/login-as {userId}', 'Demo only: sign in as a seeded user', 'Demo'],
    logout:             ['POST /auth/logout', 'End session', 'CT-01'],
    getSession:         ['GET /auth/session', 'Current user, branch, clinic plan', 'CT-00-02'],
    switchBranch:       ['POST /auth/branch {branchId}', 'Change active branch', 'CT-00-02'],
    switchRole:         ['POST /auth/role {role}', 'Change active role (multi-role users)', 'CT-00-01'],
    getClinic:          ['GET /clinic', 'Clinic profile, plan, branches, settings', 'CT-00-05'],
    listUsers:          ['GET /users', 'Staff directory (doctors, optometrists...)', 'CT-00'],
    listDevices:        ['GET /users/:id/devices', 'Registered devices for remote logout', 'CT-01-05'],

    // ---- Patients (Epic 2) ----
    searchPatients:     ['GET /patients?q=', 'Search by name, mobile, UHID, ABHA', 'CT-02-04'],
    getPatient:         ['GET /patients/:id', 'Patient with flags, allergies, consents', 'CT-02-05'],
    findDuplicates:     ['POST /patients/duplicates {name, phone, age}', 'Possible duplicate patients', 'CT-02-02'],
    createPatient:      ['POST /patients', 'Register patient (+ consent record)', 'CT-02-01'],
    updatePatient:      ['PATCH /patients/:id', 'Edit demographics / flags', 'CT-02'],
    listFamily:         ['GET /patients/:id/family', 'Patients sharing a mobile number', 'CT-02-03'],
    getPatientHistory:  ['GET /patients/:id/history', 'Visits, Rx, bills, jobs, trends', 'CT-04-09'],

    // ---- Appointments & queue (Epic 3) ----
    listAppointments:   ['GET /appointments?date=&doctorId=', 'Calendar for a day', 'CT-03-01'],
    bookAppointment:    ['POST /appointments', 'Book / reschedule', 'CT-03-02'],
    cancelAppointment:  ['DELETE /appointments/:id', 'Cancel', 'CT-03-02'],
    getQueue:           ['GET /queue?branchId=', 'All visits today with stage + times', 'CT-03-04'],
    checkIn:            ['POST /visits {patientId, type, priority}', 'Check in, issue token', 'CT-03-03'],
    callNext:           ['POST /queue/call-next {stage}', 'Call next patient for a stage', 'CT-03-05'],
    moveVisit:          ['POST /visits/:id/stage {stage, reason}', 'Move a visit to another stage', 'CT-03'],
    setPriority:        ['POST /visits/:id/priority {flags}', 'Priority flags reorder the queue', 'CT-03-07'],
    transferVisit:      ['POST /visits/:id/transfer {doctorId, reason}', 'Transfer to another doctor', 'CT-03-08'],

    // ---- Exam workspace (Epic 4) ----
    getVisit:           ['GET /visits/:id', 'Visit with exam, Rx, stage log', 'CT-04'],
    saveExamSection:    ['PUT /visits/:id/exam/:section', 'Autosave one exam tab', 'CT-04-14'],
    startDilation:      ['POST /visits/:id/dilation {drops, minutes}', 'Drops instilled, timer starts', 'CT-03-06'],
    importDeviceData:   ['POST /visits/:id/device-import {device, payload}', 'Values from device bridge', 'CT-04-12'],
    signVisit:          ['POST /visits/:id/sign', 'Sign and lock the visit', 'CT-04-15'],
    addAddendum:        ['POST /visits/:id/addenda {text}', 'Post-sign correction', 'CT-04-15'],

    // ---- Diagnosis & Rx (Epic 5) ----
    listDiagnosisMaster:['GET /masters/diagnoses', 'ICD-coded favourites', 'CT-05-01'],
    listDrugMaster:     ['GET /masters/drugs', 'Drug master', 'CT-05-03'],
    listRxTemplates:    ['GET /masters/rx-templates', 'Smart Rx templates', 'CT-05-02'],
    saveRx:             ['PUT /visits/:id/rx', 'Save prescription draft', 'CT-05'],
    signRx:             ['POST /visits/:id/rx/sign', 'Sign Rx; creates optical lead + pharmacy order', 'CT-05-10/11'],
    countersignRx:      ['POST /visits/:id/rx/countersign', 'Doctor countersigns optometrist spectacle Rx', 'CT-05-13'],

    // ---- Counselling (Epic 6) ----
    listCounselling:    ['GET /counselling', 'Counselling queue', 'CT-06-01'],
    updateCounselling:  ['PATCH /counselling/:id', 'Package, estimate, consent, outcome', 'CT-06'],
    listPackages:       ['GET /masters/packages', 'Surgery packages / IOL categories', 'CT-06-02'],

    // ---- Optical (Epic 7) ----
    listOpticalJobs:    ['GET /optical/jobs?status=', 'Job cards', 'CT-07'],
    createOpticalJob:   ['POST /optical/jobs', 'Create job card', 'CT-07-05'],
    updateOpticalJob:   ['PATCH /optical/jobs/:id', 'Status change / QC / delivery', 'CT-07-06'],
    lookupBarcode:      ['GET /inventory/barcode/:code', 'Frame / lens / drug / IOL by barcode', 'CT-07-02'],

    // ---- Pharmacy & inventory (Epic 8) ----
    listInventory:      ['GET /inventory?type=', 'Stock by item / batch / expiry', 'CT-08-03'],
    listDispenseQueue:  ['GET /pharmacy/queue', 'Signed drug Rx awaiting dispense', 'CT-08-01'],
    dispense:           ['POST /pharmacy/dispense {visitId, lines}', 'Dispense against Rx (FEFO)', 'CT-08-02'],
    raisePurchase:      ['POST /purchase-requests', 'Raise PO request (goes to approvals)', 'CT-08-06'],

    // ---- Billing (Epic 12) ----
    listBillingQueue:   ['GET /billing/queue', 'Visits with unbilled services', 'CT-12-01'],
    getBill:            ['GET /bills/:id', 'Bill with lines and payments', 'CT-12'],
    buildBillForVisit:  ['POST /bills/from-visit/:visitId', 'Auto-add services to a bill', 'CT-12-01'],
    applyDiscount:      ['POST /bills/:id/discount {amount, reason}', 'Within limit or to approvals', 'CT-12-05'],
    addPayment:         ['POST /bills/:id/payments {mode, amount, ref}', 'Collect payment', 'CT-12-03'],
    listBills:          ['GET /bills?date=', 'Bills for reports', 'CT-14-07'],

    // ---- IPD (Epic 10) ----
    listBeds:           ['GET /ipd/beds', 'Bed board', 'CT-10-01'],
    admit:              ['POST /ipd/admissions', 'Admit to a bed', 'CT-10-02'],
    getAdmission:       ['GET /ipd/admissions/:id', 'Admission with orders, nursing, MAR', 'CT-10'],
    addNursingEntry:    ['POST /ipd/admissions/:id/nursing', 'Vitals / notes', 'CT-10-05'],
    recordDose:         ['POST /ipd/admissions/:id/mar', 'Medication administration', 'CT-10-06'],
    discharge:          ['POST /ipd/admissions/:id/discharge', 'Discharge summary + bed release', 'CT-10-08'],
    setBedStatus:       ['POST /ipd/beds/:id/status {status}', 'Free / cleaning / reserved / blocked', 'CT-10-01'],

    // ---- OT (Epic 11) ----
    listOTCases:        ['GET /ot/cases?date=', 'OT board', 'CT-11-01'],
    getOTCase:          ['GET /ot/cases/:id', 'Case with checklist and implant', 'CT-11'],
    updateOTChecklist:  ['PATCH /ot/cases/:id/checklist', 'Pre-op / sign-in / time-out / sign-out', 'CT-11-02/03'],
    scanIOL:            ['POST /ot/cases/:id/iol-scan {code}', 'Match implanted IOL to plan', 'CT-11-04'],
    setOTStatus:        ['POST /ot/cases/:id/status', 'Case status change', 'CT-11'],

    // ---- Inbox, approvals, messages (Epics 13–14) ----
    listNotifications:  ['GET /notifications', 'Alerts for the current user', 'CT-13'],
    markNotificationRead:['POST /notifications/:id/read', 'Mark read', 'CT-13'],
    listApprovals:      ['GET /approvals?status=', 'Approvals inbox', 'CT-14-04'],
    decideApproval:     ['POST /approvals/:id/decision {approve, reason}', 'Approve / reject', 'CT-14-04'],
    sendMessage:        ['POST /messages {patientId, template, channel}', 'WhatsApp / SMS via BSP', 'CT-13-01'],
    listMessages:       ['GET /messages?patientId=', 'Outbound message log', 'CT-13-01'],
    listRecalls:        ['GET /recalls', 'Recall worklist', 'CT-13-03'],
    updateRecall:       ['PATCH /recalls/:id', 'Call outcome', 'CT-13-03'],

    // ---- Dashboard & reports (Epic 14) ----
    getDashboard:       ['GET /dashboard?range=&branchId=', 'KPI tiles and funnels', 'CT-14-01'],
    getReport:          ['GET /reports/:name?range=', 'Standard report rows', 'CT-14-07'],
    listAudit:          ['GET /audit?entity=&id=', 'Audit trail', 'Section 24'],

    // ---- Sync (offline) ----
    getSyncState:       ['(client)', 'Pending offline writes', 'CT-04-14'],

    // ---- Demo controls (mock only; not part of production API) ----
    demo:               ['(mock only)', 'Simulators: reset, arrivals, device import, payments, clock', 'Demo']
  };

  K.DataContract = {
    methods: M,
    names: Object.keys(M),
    /* Throws if an implementation misses a method: run at boot in debug */
    verify: function (impl, label) {
      var missing = this.names.filter(function (n) { return n !== 'demo' && typeof impl[n] !== 'function'; });
      if (missing.length) console.warn('[DataContract] ' + label + ' is missing: ' + missing.join(', '));
      return missing;
    },
    /* Wrap an implementation so every call is logged (shown in Demo centre > API log) */
    instrument: function (impl) {
      var log = K.apiLog = K.apiLog || [];
      var wrapped = {};
      Object.keys(impl).forEach(function (name) {
        if (typeof impl[name] !== 'function') { wrapped[name] = impl[name]; return; }
        wrapped[name] = function () {
          var args = Array.prototype.slice.call(arguments), t0 = performance.now();
          var entry = { ts: K.clock.now(), method: name, route: (M[name] || ['?'])[0], args: args, ms: 0, ok: true };
          return Promise.resolve(impl[name].apply(impl, args)).then(function (res) {
            entry.ms = Math.round(performance.now() - t0); push(entry); return res;
          }, function (err) {
            entry.ms = Math.round(performance.now() - t0); entry.ok = false; entry.error = String(err && err.message || err); push(entry); throw err;
          });
        };
      });
      function push(e) { if (/^(getSyncState|listNotifications|getSession|listDemoUsers)$/.test(e.method)) return; log.unshift(e); if (log.length > 300) log.length = 300; }
      return wrapped;
    }
  };
})();
