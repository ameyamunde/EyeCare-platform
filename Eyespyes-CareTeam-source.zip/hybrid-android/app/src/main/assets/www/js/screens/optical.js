/* Optical (PRD Epic 7): leads from signed Rx, job card builder with barcode, measurements, QC, status, delivery */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var oTab = 'leads', nj = null;
  var FLOW = ['ordered', 'in_lab', 'received', 'ready', 'delivered'];

  function jobRow(j) {
    return '<div class="card tap" data-act="job" data-id="' + j.id + '"><div class="row between"><b>' + esc(j.patient.name) + '</b>' + C.pill(K.JOB_STATUS[j.status], j.status === 'ready' ? 'ok' : j.status === 'remake' ? 'crit' : 'info') + '</div>' +
      '<div class="small">' + esc(j.frame.name) + ' · ' + esc(j.lens.name) + '</div><div class="small muted">Due ' + U.dateTime(j.due) + ' · ' + esc(j.lab) + ' · advance ' + U.inr(j.advance) + ' of ' + U.inr(j.price) + '</div>' +
      (j.overdue ? '<div style="margin-top:4px">' + C.pill('Overdue', 'crit') + '</div>' : '') + '</div>';
  }

  K.screens.optical = {
    title: 'Optical', tab: 'home', root: true, live: true,
    render: function () {
      return K.data.listOpticalJobs().then(function (d) {
        var active = d.jobs.filter(function (j) { return ['ordered', 'in_lab', 'received', 'remake'].indexOf(j.status) >= 0; }),
          ready = d.jobs.filter(function (j) { return j.status === 'ready'; }), done = d.jobs.filter(function (j) { return j.status === 'delivered'; });
        var tabs = [['leads', 'New Rx', d.leads.length], ['active', 'In progress', active.length], ['ready', 'Ready', ready.length], ['done', 'Delivered', done.length]];
        var body = oTab === 'leads' ? (d.leads.length ? d.leads.map(function (v) { return C.qcard(v, { act: 'lead', extra: function (x) { return x.rx.spectacle ? 'OD ' + C.rxText(x.rx.spectacle.OD) + ' · OS ' + C.rxText(x.rx.spectacle.OS) : ''; } }); }).join('') : C.empty('No new spectacle prescriptions', 'Signed spectacle Rx from doctors appear here'))
          : (oTab === 'active' ? active : oTab === 'ready' ? ready : done).map(jobRow).join('') || C.empty('Nothing here');
        return '<div class="chips">' + tabs.map(function (t) { return '<button class="chip ' + (oTab === t[0] ? 'on' : '') + '" data-act="tab" data-t="' + t[0] + '">' + t[1] + '<span class="n">' + t[2] + '</span></button>'; }).join('') + '</div>' + body +
          '<button class="btn fab" data-act="walkin">' + K.icon('plus', 'sm') + 'Walk-in order</button>';
      });
    },
    actions: {
      tab: function (el) { oTab = el.getAttribute('data-t'); K.refresh(); },
      lead: function (el) { nj = null; K.go('newjob/' + el.getAttribute('data-id')); },
      job: function (el) { K.go('job/' + el.getAttribute('data-id')); },
      walkin: function () { nj = null; K.go('newjob/walkin'); }
    }
  };

  /* ---------- Job card builder (CT-07-01..05) ---------- */
  K.screens.newjob = {
    title: 'New job card', tab: 'home', noTabs: true,
    render: function (pr) {
      var vp = pr[0] === 'walkin' ? Promise.resolve(null) : K.data.getVisit(pr[0]);
      return Promise.all([vp, K.data.listInventory('frame'), K.data.listInventory('lens')]).then(function (r) {
        var v = r[0], frames = r[1], lenses = r[2];
        if (!nj) {
          var sp = v && v.rx.spectacle;
          nj = { visitId: v ? v.id : null, patientId: v ? v.patientId : null, external: !v, rx: sp ? { OD: U.clone(sp.OD), OS: U.clone(sp.OS), pd: sp.pd } : { OD: { sph: 0, cyl: 0, axis: null, add: 0 }, OS: { sph: 0, cyl: 0, axis: null, add: 0 }, pd: 62 },
            lensAdvice: sp ? sp.lensAdvice : '', frame: null, lens: null, measure: { pd: sp ? sp.pd : 62, fitHeight: 20, a: 52, b: 38, dbl: 18 }, advance: 0, dueHours: 48, lab: 'Outside lab', patientName: v ? v.patient.name : '' };
        }
        var want = /Progressive/i.test(nj.lensAdvice) ? 'progressive' : /Bifocal/i.test(nj.lensAdvice) ? 'bifocal' : 'single';
        var lensList = lenses.filter(function (l) { return !nj.lensAdvice || l.lensType === want; });
        var total = (nj.frame ? nj.frame.price : 0) + (nj.lens ? nj.lens.price : 0);
        return (v ? C.banner(v.patient, v) : '<div class="card"><b>Walk-in with outside prescription</b><label class="f">Patient</label><div class="row"><input class="input grow" id="wk-p" placeholder="Search name or mobile" value="' + esc(nj.patientName) + '"><button class="btn secondary sm" data-act="findP">Find</button></div><div class="small muted">Outside Rx is flagged “external” with source and date (CT-07-01).</div></div>') +
          '<div class="h2">Prescription</div><div class="card"><table class="t"><tr><th></th><th>Sph</th><th>Cyl</th><th>Axis</th><th>Add</th></tr>' + ['OD', 'OS'].map(function (e) { var x = nj.rx[e]; return '<tr><td style="color:var(--' + e.toLowerCase() + ')"><b>' + e + '</b></td><td>' + U.dio(x.sph) + '</td><td>' + U.dio(x.cyl) + '</td><td>' + (x.axis || '—') + '</td><td>' + (x.add ? U.dio(x.add) : '—') + '</td></tr>'; }).join('') + '</table>' +
          (v ? '<div class="small muted">From signed Rx · advice: ' + esc(nj.lensAdvice) + '</div>' : '<button class="btn ghost sm" data-act="editRx">Enter outside Rx</button>') + '</div>' +
          '<div class="h2">Frame</div><div class="card"><div class="row"><input class="input grow" id="fr-code" placeholder="Scan or type barcode, e.g. FR1004"><button class="btn secondary sm" data-act="scanFrame">' + K.icon('scan', 'sm') + 'Scan</button></div>' +
          (nj.frame ? '<div class="banner-info" style="margin-top:8px"><b>' + esc(nj.frame.name) + '</b> · ' + U.inr(nj.frame.price) + '</div>' : '') +
          '<div class="chips" style="margin-top:8px">' + frames.map(function (f) { return '<button class="chip ' + (nj.frame && nj.frame.sku === f.sku ? 'on' : '') + '" data-act="frame" data-sku="' + f.sku + '"' + (f.qty < 1 ? ' disabled' : '') + '>' + esc(f.name) + ' · ' + U.inr(f.price) + ' <span class="small">(' + f.qty + ')</span></button>'; }).join('') + '</div></div>' +
          '<div class="h2">Lens</div><div class="list">' + lensList.map(function (l) { return '<div class="li" data-act="lens" data-sku="' + l.sku + '"><span class="grow">' + esc(l.name) + '</span><b>' + U.inr(l.price) + '</b>' + (nj.lens && nj.lens.sku === l.sku ? ' ' + C.pill('Selected', 'ok') : '') + '</div>'; }).join('') + '</div>' +
          '<div class="h2">Measurements</div><div class="card"><div class="grid2">' + C.stepper('m_pd', 'PD (mm)', nj.measure.pd, { fmt: 'int', min: 40, max: 80, inc: 1 }) + C.stepper('m_fh', 'Fitting height', nj.measure.fitHeight, { fmt: 'int', min: 10, max: 35, inc: 1 }) +
          C.stepper('m_a', 'A (mm)', nj.measure.a, { fmt: 'int', min: 30, max: 70, inc: 1 }) + C.stepper('m_b', 'B (mm)', nj.measure.b, { fmt: 'int', min: 20, max: 60, inc: 1 }) + C.stepper('m_dbl', 'DBL (mm)', nj.measure.dbl, { fmt: 'int', min: 10, max: 26, inc: 1 }) + '</div></div>' +
          '<div class="h2">Order</div><div class="card"><div class="grid2"><div><label class="small">Lab</label>' + C.select('lab', ['Outside lab', 'In-house edging'], nj.lab) + '</div><div><label class="small">Due in</label>' + C.select('due', ['4', '24', '48', '72', '120'], String(nj.dueHours)) + ' <span class="small muted">hours</span></div></div>' +
          '<label class="f">Advance received (₹)</label><input class="input" id="adv" inputmode="numeric" value="' + (nj.advance || '') + '" placeholder="0">' +
          '<div class="row between" style="margin-top:10px"><span class="muted">Total (before GST)</span><b style="font-size:18px">' + U.inr(total) + '</b></div></div>' +
          '<div class="btn-row sticky-actions"><button class="btn" data-act="create">Create job card</button></div>';
      });
    },
    actions: {
      frame: function (el) { keep(); return K.data.lookupBarcode(el.getAttribute('data-sku')).then(function (f) { nj.frame = { sku: f.sku, name: f.name, price: f.price }; K.refresh(); }); },
      scanFrame: function () { keep(); var code = document.getElementById('fr-code').value || 'FR1004'; return K.data.lookupBarcode(code).then(function (f) { if (f.type !== 'frame') { K.ui.toast('That barcode is a ' + f.type + ', not a frame'); return; } K.native.vibrate(); nj.frame = { sku: f.sku, name: f.name, price: f.price }; K.refresh(); }); },
      lens: function (el) { keep(); return K.data.lookupBarcode(el.getAttribute('data-sku')).then(function (l) { nj.lens = { sku: l.sku, name: l.name, price: l.price }; K.refresh(); }); },
      findP: function () { keep(); var q = document.getElementById('wk-p').value; return K.data.searchPatients(q).then(function (l) { if (!l.length) { K.ui.toast('No match — register the patient first'); return; } nj.patientId = l[0].id; nj.patientName = l[0].name; K.ui.toast('Patient: ' + l[0].name); K.refresh(); }); },
      editRx: function () {
        keep();
        K.ui.sheet('Outside prescription', ['OD', 'OS'].map(function (e) { var x = nj.rx[e]; return '<div class="eye ' + e.toLowerCase() + '" style="margin-bottom:8px"><div class="eye-h">' + e + '</div><div class="grid2">' + C.stepper('x_sph_' + e, 'Sph', x.sph, { min: -30, max: 30, inc: 0.25 }) + C.stepper('x_cyl_' + e, 'Cyl', x.cyl, { min: -10, max: 10, inc: 0.25 }) + C.stepper('x_axis_' + e, 'Axis', x.axis, { fmt: 'axis', min: 1, max: 180, inc: 5 }) + C.stepper('x_add_' + e, 'Add', x.add, { min: 0, max: 4, inc: 0.25 }) + '</div></div>'; }).join('') +
          '<label class="f">Source and date</label><input class="input" id="x-src" placeholder="e.g. Dr. X, 12-08-2026"><button class="btn block" style="margin-top:12px" data-sact="ok">Use this Rx</button>', {
          ok: function () { var s = K.ui.sheetEl(); ['OD', 'OS'].forEach(function (e) { nj.rx[e] = { sph: C.stepVal(s, 'x_sph_' + e) || 0, cyl: C.stepVal(s, 'x_cyl_' + e) || 0, axis: C.stepVal(s, 'x_axis_' + e), add: C.stepVal(s, 'x_add_' + e) || 0 }; }); nj.rx.source = s.querySelector('#x-src').value; K.ui.closeSheet(); K.refresh(); } });
      },
      create: function () {
        keep();
        if (!nj.patientId) { K.ui.toast('Choose the patient'); return; }
        return K.data.createOpticalJob({ visitId: nj.visitId, patientId: nj.patientId, rx: nj.rx, frame: nj.frame, lens: nj.lens, measure: nj.measure, advance: nj.advance, dueHours: nj.dueHours, lab: nj.lab, external: nj.external }).then(function (j) {
          nj = null; K.ui.toast('Job card created; patient informed on WhatsApp'); K.go('job/' + j.id, true);
        });
      }
    }
  };
  function keep() {
    var root = document.getElementById('content'); if (!nj || !root.querySelector('[data-step=m_pd]')) return;
    nj.measure = { pd: C.stepVal(root, 'm_pd'), fitHeight: C.stepVal(root, 'm_fh'), a: C.stepVal(root, 'm_a'), b: C.stepVal(root, 'm_b'), dbl: C.stepVal(root, 'm_dbl') };
    nj.lab = C.fieldVal(root, 'lab'); nj.dueHours = Number(C.fieldVal(root, 'due')); nj.advance = Number((root.querySelector('#adv') || {}).value) || 0;
  }

  /* ---------- Job detail ---------- */
  K.screens.job = {
    title: 'Job card', tab: 'home', noTabs: true,
    render: function (pr) {
      return K.data.listOpticalJobs().then(function (d) {
        var j = d.jobs.filter(function (x) { return x.id === pr[0]; })[0]; if (!j) return C.empty('Job not found');
        var idx = FLOW.indexOf(j.status), next = FLOW[idx + 1];
        return C.banner(j.patient) + '<div class="card"><div class="row between"><b>' + esc(j.frame.name) + '</b>' + C.pill(K.JOB_STATUS[j.status], j.status === 'ready' ? 'ok' : 'info') + '</div><div class="small">' + esc(j.lens.name) + '</div>' +
          '<table class="t" style="margin-top:6px"><tr><th></th><th>Rx</th></tr><tr><td><b style="color:var(--od)">OD</b></td><td>' + C.rxText(j.rx.OD) + '</td></tr><tr><td><b style="color:var(--os)">OS</b></td><td>' + C.rxText(j.rx.OS) + '</td></tr></table>' +
          '<div class="small muted">PD ' + j.measure.pd + ' · FH ' + (j.measure.fitHeight || '—') + ' · ' + j.measure.a + ' □ ' + j.measure.dbl + ' · ' + esc(j.lab) + (j.external ? ' · external Rx' : '') + '</div>' +
          '<div class="row between" style="margin-top:8px"><span class="muted">Price ' + U.inr(j.price) + ' · advance ' + U.inr(j.advance) + '</span><b>Due ' + U.dateTime(j.due) + '</b></div></div>' +
          (j.qc ? '<div class="' + (j.qc.pass ? 'banner-info' : 'banner-note') + '">QC ' + (j.qc.pass ? 'passed' : 'failed: ' + esc(j.qc.issues.join(', '))) + '</div>' : '') +
          '<div class="h2">Status</div><div class="tl">' + FLOW.map(function (s) { var log = j.statusLog.filter(function (l) { return l.status === s; }).pop(); return '<div class="ev ' + (log ? '' : 'pending') + '"><b>' + K.JOB_STATUS[s] + '</b><div class="small muted">' + (log ? U.dateTime(log.ts) : 'Pending') + '</div></div>'; }).join('') + '</div>' +
          '<div class="btn-row" style="margin-top:8px">' +
          (j.status === 'received' ? '<button class="btn secondary" data-act="qc">Run QC (lensmeter)</button>' : '') +
          (next && j.status !== 'remake' ? '<button class="btn" data-act="advance" data-s="' + next + '">Mark ' + K.JOB_STATUS[next].toLowerCase() + '</button>' : '') +
          (j.status === 'remake' ? '<button class="btn" data-act="advance" data-s="in_lab">Re-send to lab</button>' : '') + '</div>' +
          '<div class="btn-row" style="margin-top:8px"><button class="btn ghost" data-act="share">Share job card with lab</button>' + (['received', 'ready'].indexOf(j.status) >= 0 ? '<button class="btn ghost" data-act="remake">Remake</button>' : '') + '</div>' +
          (j.warrantyTill ? '<p class="small muted">Warranty till ' + U.date(j.warrantyTill) + '</p>' : '');
      });
    },
    actions: {
      advance: function (el, ev, pr) {
        var s = el.getAttribute('data-s');
        if (s === 'delivered') return K.ui.prompt('Delivery', 'Collected by', { options: ['Patient', 'Family member', 'Courier'], ok: 'Confirm delivery' }).then(function (who) { if (who) return K.data.updateOpticalJob(pr[0], { status: 'delivered', deliveredTo: who }).then(function () { K.ui.toast('Delivered; warranty started'); K.refresh(); }); });
        return K.data.updateOpticalJob(pr[0], { status: s }).then(function () { K.ui.toast(s === 'ready' ? 'Ready — patient notified on WhatsApp' : 'Status updated'); K.refresh(); });
      },
      qc: function (el, ev, pr) {
        K.ui.sheet('QC — lensmeter reading', '<p class="small muted">Enter or import the finished lens power. Tolerance ±0.25 D vs Rx (CT-07-07).</p><button class="btn secondary sm" data-sact="imp">' + K.icon('refresh', 'sm') + 'Import from lensmeter (demo: exact match)</button>' +
          ['OD', 'OS'].map(function (e) { return '<div class="eye ' + e.toLowerCase() + '" style="margin-top:8px"><div class="eye-h">' + e + '</div><div class="grid2">' + C.stepper('q_sph_' + e, 'Sph', 0, { min: -30, max: 30, inc: 0.25 }) + C.stepper('q_cyl_' + e, 'Cyl', 0, { min: -10, max: 10, inc: 0.25 }) + '</div></div>'; }).join('') +
          '<button class="btn block" style="margin-top:12px" data-sact="ok">Check against Rx</button>', {
          imp: function () { return K.data.listOpticalJobs().then(function (d) { var j = d.jobs.filter(function (x) { return x.id === pr[0]; })[0]; var s = K.ui.sheetEl(); ['OD', 'OS'].forEach(function (e) { C.setStep(s, 'q_sph_' + e, j.rx[e].sph, 'dev'); C.setStep(s, 'q_cyl_' + e, j.rx[e].cyl, 'dev'); }); }); },
          ok: function () {
            var s = K.ui.sheetEl(), qc = {}; ['OD', 'OS'].forEach(function (e) { qc[e] = { sph: C.stepVal(s, 'q_sph_' + e) || 0, cyl: C.stepVal(s, 'q_cyl_' + e) || 0 }; });
            return K.data.updateOpticalJob(pr[0], { qc: qc }).then(function (j) { K.ui.closeSheet(); K.ui.toast(j.qc.pass ? 'QC passed' : 'QC failed: ' + j.qc.issues.join(', ')); K.refresh(); });
          } });
      },
      remake: function (el, ev, pr) { return K.ui.prompt('Remake', 'Reason', { options: ['Power mismatch', 'Scratched lens', 'Wrong fitting height', 'Frame damaged', 'Patient discomfort'] }).then(function (r) { if (r) return K.data.updateOpticalJob(pr[0], { status: 'remake', reason: r }).then(function () { K.refresh(); }); }); },
      share: function (el, ev, pr) { return K.data.listOpticalJobs().then(function (d) { var j = d.jobs.filter(function (x) { return x.id === pr[0]; })[0]; K.native.share('Job card ' + j.id, 'Job ' + j.id + ' for ' + j.patient.name + '\nOD ' + C.rxText(j.rx.OD) + '\nOS ' + C.rxText(j.rx.OS) + '\nPD ' + j.measure.pd + '\nLens: ' + j.lens.name + '\nFrame: ' + j.frame.name + '\nDue: ' + U.dateTime(j.due)); }); }
    }
  };
})();
