/* Core utilities shared by every layer. Global namespace: window.EYESPYES */
(function () {
  'use strict';
  var K = window.EYESPYES = window.EYESPYES || {};

  /* ---------- Demo clock (Demo centre can fast-forward time) ---------- */
  K.clock = {
    offsetMs: 0,
    now: function () { return Date.now() + this.offsetMs; },
    advance: function (minutes) { this.offsetMs += minutes * 60000; K.bus.emit('clock'); }
  };

  /* ---------- Tiny event bus ---------- */
  K.bus = {
    _h: {},
    on: function (ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); return function () { K.bus.off(ev, fn); }; },
    off: function (ev, fn) { this._h[ev] = (this._h[ev] || []).filter(function (f) { return f !== fn; }); },
    emit: function (ev, data) { (this._h[ev] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error(e); } }); }
  };

  /* ---------- Formatting ---------- */
  var U = K.util = {};
  U.esc = function (s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };
  U.uid = function (prefix) { return (prefix || 'id') + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3); };
  /* Indian digit grouping: 1,49,999 */
  U.inr = function (n) {
    n = Math.round(Number(n) || 0);
    var neg = n < 0; n = Math.abs(n);
    var s = String(n), last3 = s.slice(-3), rest = s.slice(0, -3);
    if (rest) last3 = ',' + last3;
    rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    return (neg ? '-' : '') + '₹' + rest + last3;
  };
  U.pad = function (n) { return (n < 10 ? '0' : '') + n; };
  U.date = function (ts) { var d = new Date(ts); return U.pad(d.getDate()) + '-' + U.pad(d.getMonth() + 1) + '-' + d.getFullYear(); };
  U.time = function (ts) { var d = new Date(ts); var h = d.getHours(), m = d.getMinutes(); return (h % 12 || 12) + ':' + U.pad(m) + (h < 12 ? ' am' : ' pm'); };
  U.dateTime = function (ts) { return U.date(ts) + ' ' + U.time(ts); };
  U.isoDay = function (ts) { var d = new Date(ts); return d.getFullYear() + '-' + U.pad(d.getMonth() + 1) + '-' + U.pad(d.getDate()); };
  U.mins = function (fromTs, toTs) { return Math.max(0, Math.round(((toTs || K.clock.now()) - fromTs) / 60000)); };
  U.dur = function (m) { return m < 60 ? m + ' min' : Math.floor(m / 60) + ' h ' + (m % 60) + ' min'; };
  U.ago = function (ts) { var m = U.mins(ts); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.floor(m / 60) + ' h ago' : Math.floor(m / 1440) + ' d ago'; };
  U.age = function (dob) { if (!dob) return ''; var d = new Date(dob), n = new Date(K.clock.now()); var a = n.getFullYear() - d.getFullYear(); if (n < new Date(n.getFullYear(), d.getMonth(), d.getDate())) a--; return a; };
  U.initials = function (name) { return String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w[0].toUpperCase(); }).join(''); };
  /* Dioptre formatting: +1.25 / -0.50 / 0.00 */
  U.dio = function (v) { if (v === null || v === undefined || v === '') return '—'; v = Number(v); return (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(2); };
  U.clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  U.sum = function (arr, fn) { return arr.reduce(function (s, x) { return s + (fn ? fn(x) : x); }, 0); };
  U.by = function (key, desc) { return function (a, b) { var x = a[key], y = b[key]; return (x > y ? 1 : x < y ? -1 : 0) * (desc ? -1 : 1); }; };
  U.cap = function (s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; };
  U.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  /* ---------- Native bridge (Android shell exposes window.AndroidBridge) ---------- */
  K.native = {
    available: function () { return !!window.AndroidBridge; },
    share: function (title, text) {
      if (window.AndroidBridge) { window.AndroidBridge.share(title, text); return; }
      /* Browser: copy to clipboard (Web Share is blocked in many embedded viewers) */
      try { navigator.clipboard.writeText(title + '\n' + text).then(function () { K.ui.ok('Copied to clipboard \u2014 paste it into WhatsApp or email'); }, function () { K.ui.toast('Share: ' + title); }); }
      catch (e) { K.ui.toast('Share: ' + title); }
    },
    toast: function (msg) { if (window.AndroidBridge) window.AndroidBridge.toast(msg); },
    vibrate: function (ms) { if (window.AndroidBridge) window.AndroidBridge.vibrate(ms || 30); else if (navigator.vibrate) navigator.vibrate(ms || 30); },
    dial: function (phone) { if (window.AndroidBridge) window.AndroidBridge.dial(phone); else K.ui.toast('Call ' + phone + ' from your phone (dialling opens automatically in the Android app)', 4200); },
    appInfo: function () {
      if (window.AndroidBridge) { try { return JSON.parse(window.AndroidBridge.appInfo()); } catch (e) { /* fall through */ } }
      return { platform: 'browser', version: '1.0.0-demo', device: navigator.userAgent.slice(0, 60) };
    }
  };
})();
