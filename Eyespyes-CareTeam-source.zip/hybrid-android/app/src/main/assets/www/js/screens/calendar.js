/* Calendar (PRD CT-03-01/02): appointments by day and doctor; book, reschedule, cancel, check in */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var cState = { day: 0, doc: '' };
  var dayTs = function (n) { return K.clock.now() + n * 86400000; };

  K.screens.calendar = {
    title: 'Calendar', tab: 'calendar', root: true, live: true,
    render: function () {
      return Promise.all([K.data.listAppointments(U.isoDay(dayTs(cState.day)), cState.doc || null), K.data.listUsers('doctor')]).then(function (r) {
        var list = r[0], docs = r[1];
        var days = []; for (var i = 0; i < 7; i++) days.push(i);
        var wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        return '<div class="chips">' + days.map(function (d) { var t = new Date(dayTs(d)); return '<button class="chip ' + (cState.day === d ? 'on' : '') + '" data-act="day" data-d="' + d + '">' + (d === 0 ? 'Today' : d === 1 ? 'Tomorrow' : wd[t.getDay()] + ' ' + t.getDate()) + '</button>'; }).join('') + '</div>' +
          '<div class="chips"><button class="chip ' + (!cState.doc ? 'on' : '') + '" data-act="doc" data-id="">All doctors</button>' + docs.map(function (d) { return '<button class="chip ' + (cState.doc === d.id ? 'on' : '') + '" data-act="doc" data-id="' + d.id + '">' + esc(d.name) + '</button>'; }).join('') + '</div>' +
          (list.length ? '<div class="list">' + list.map(function (a) {
            return '<div class="li" data-act="appt" data-id="' + a.id + '"><div style="width:64px;font-weight:700">' + U.time(a.ts) + '</div><div class="grow"><b>' + esc(a.patient.name) + '</b><div class="small muted">' + esc(U.cap(a.type)) + ' · ' + esc(a.doctor.name) + ' · via ' + esc(a.source) + '</div></div>' +
              C.pill(a.status, a.status === 'arrived' ? 'ok' : a.status === 'cancelled' ? 'crit' : 'brand') + (a.doubleBooked ? ' ' + C.pill('Double-booked', 'warn') : '') + '</div>';
          }).join('') + '</div>' : C.empty('No appointments', 'Tap Book to add one')) +
          '<button class="btn fab" data-act="book">' + K.icon('plus', 'sm') + 'Book</button>';
      });
    },
    actions: {
      day: function (el) { cState.day = Number(el.getAttribute('data-d')); K.refresh(); },
      doc: function (el) { cState.doc = el.getAttribute('data-id'); K.refresh(); },
      book: function () { return K.bookSheet(null); },
      appt: function (el) {
        return K.data.listAppointments(U.isoDay(dayTs(cState.day))).then(function (l) {
          var a = l.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0];
          var today = U.isoDay(a.ts) === U.isoDay(K.clock.now());
          K.ui.sheet(U.time(a.ts) + ' · ' + a.patient.name, C.banner(a.patient) + '<div class="list">' +
            (today && a.status === 'booked' ? '<div class="li" data-sact="ci">Check in now</div>' : '') +
            '<div class="li" data-sact="pt">Open patient</div>' + (a.status === 'booked' ? '<div class="li" data-sact="rs">Reschedule</div><div class="li" data-sact="cx" style="color:var(--crit)">Cancel appointment</div>' : '') + '</div>', {
            ci: function () { K.ui.closeSheet(); return K.checkInSheet(a.patientId); },
            pt: function () { K.ui.closeSheet(); K.go('patient/' + a.patientId); },
            rs: function () { K.ui.closeSheet(); return K.bookSheet(a.patientId, a); },
            cx: function () { return K.ui.prompt('Cancel', 'Reason', { options: ['Patient request', 'Doctor unavailable', 'Duplicate'] }).then(function (r) { if (r) return K.data.cancelAppointment(a.id, r).then(function () { K.ui.toast('Cancelled'); }); }); }
          });
        });
      }
    }
  };

  /* Booking sheet with slot grid (also used from patient profile) */
  K.bookSheet = function (patientId, existing) {
    return Promise.all([K.data.listUsers('doctor'), patientId ? K.data.getPatient(patientId) : Promise.resolve(null)]).then(function (r) {
      var docs = r[0], p = r[1], sel = { pid: patientId, doc: existing ? existing.doctorId : docs[0].id, day: cState.day || 1, slot: null };
      var draw = function () {
        return K.data.listAppointments(U.isoDay(dayTs(sel.day)), sel.doc).then(function (taken) {
          var t = taken.filter(function (a) { return a.status === 'booked'; }).map(function (a) { return U.time(a.ts); });
          var slots = []; for (var h = 10; h < 19; h++) for (var m = 0; m < 60; m += 20) { var d = new Date(dayTs(sel.day)); d.setHours(h, m, 0, 0); if (d.getTime() > K.clock.now()) slots.push(d.getTime()); }
          var s = K.ui.sheet(existing ? 'Reschedule' : 'Book appointment',
            (p ? C.banner(p) : '<label class="f">Patient</label><div class="row"><input class="input grow" id="bk-q" placeholder="Name or mobile" data-nofocus><button class="btn secondary sm" data-sact="find">Find</button></div><div id="bk-p" class="small muted">' + (sel.pname ? 'Selected: ' + esc(sel.pname) : '') + '</div>') +
            '<label class="f">Doctor</label><select class="input" id="bk-d">' + docs.map(function (d) { return '<option value="' + d.id + '"' + (d.id === sel.doc ? ' selected' : '') + '>' + esc(d.name) + '</option>'; }).join('') + '</select>' +
            '<label class="f">Day</label><div class="chips">' + [0, 1, 2, 3, 4, 5, 6].map(function (n) { var d = new Date(dayTs(n)); return '<button class="chip ' + (sel.day === n ? 'on' : '') + '" data-sact="day" data-d="' + n + '">' + (n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : U.pad(d.getDate()) + '/' + U.pad(d.getMonth() + 1)) + '</button>'; }).join('') + '</div>' +
            '<label class="f">Time</label><div class="row wrap">' + (slots.length ? slots.map(function (ts) { var lab = U.time(ts), busy = t.indexOf(lab) >= 0; return '<button class="chip ' + (sel.slot === ts ? 'on' : '') + '" data-sact="slot" data-ts="' + ts + '" style="' + (busy ? 'text-decoration:line-through;opacity:.5' : '') + '">' + lab + '</button>'; }).join('') : '<span class="small muted">No slots left today</span>') + '</div>' +
            '<label class="f">Visit type</label>' + C.seg('bt', [['new', 'New'], ['review', 'Review'], ['postop', 'Post-op'], ['tele', 'Teleconsult']], existing ? existing.type : 'review') +
            '<p class="small muted">Patient gets a WhatsApp confirmation. Booking a taken slot is allowed for emergencies and is flagged.</p><button class="btn block" data-sact="ok">' + (existing ? 'Reschedule' : 'Book') + '</button>', handlers);
          s.querySelector('#bk-d').addEventListener('change', function (e) { sel.doc = e.target.value; draw(); });
        });
      };
      var handlers = {
        find: function () { return K.data.searchPatients(document.getElementById('bk-q').value).then(function (l) { if (!l.length) { K.ui.toast('No match'); return; } sel.pid = l[0].id; sel.pname = l[0].name; document.getElementById('bk-p').textContent = 'Selected: ' + l[0].name + ' (' + l[0].uhid + ')'; }); },
        day: function (el) { sel.day = Number(el.getAttribute('data-d')); sel.slot = null; draw(); },
        slot: function (el) { sel.slot = Number(el.getAttribute('data-ts')); Array.prototype.forEach.call(K.ui.sheetEl().querySelectorAll('[data-sact=slot]'), function (b) { b.classList.toggle('on', b === el); }); },
        ok: function () {
          if (!sel.pid) { K.ui.toast('Choose a patient'); return; } if (!sel.slot) { K.ui.toast('Pick a time'); return; }
          return K.data.bookAppointment({ id: existing ? existing.id : null, patientId: sel.pid, doctorId: sel.doc, ts: sel.slot, type: C.segVal(K.ui.sheetEl(), 'bt'), source: 'Care Team app' }).then(function (a) {
            K.ui.closeSheet(); K.ui.toast((a.doubleBooked ? 'Booked (double-booked slot) ' : 'Booked ') + U.dateTime(a.ts) + ' — WhatsApp sent');
          });
        }
      };
      return draw();
    });
  };
})();
