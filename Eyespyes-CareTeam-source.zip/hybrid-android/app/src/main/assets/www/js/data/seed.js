/* Demo seed data. All names, numbers and prices are FICTIONAL demo values.
   Clinical templates are illustrative only and must be reviewed by the clinic's
   ophthalmologist before real use (PRD CT-18-02). */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util;

  K.seed = function () {
    var now = K.clock.now();
    var T = function (minAgo) { return now - minAgo * 60000; };
    var D = function (daysAgo, hour) { var d = new Date(now); d.setDate(d.getDate() - daysAgo); d.setHours(hour || 10, 0, 0, 0); return d.getTime(); };
    var at = function (h, m) { var d = new Date(now); d.setHours(h, m || 0, 0, 0); return d.getTime(); };

    var db = { meta: { version: 3, seededDay: U.isoDay(now), seededAt: now, clockOffset: 0 } };

    db.clinic = {
      id: 'clinic_1', name: 'Drishti Eye Care (Demo)', plan: 'Hospital',
      branches: [{ id: 'br_1', name: 'Kothrud', city: 'Pune' }, { id: 'br_2', name: 'Wakad', city: 'Pune' }],
      theatres: ['OT-1', 'OT-2'],
      settings: { vaNotation: 'snellen', iopThreshold: 21, iopDiff: 5, dilationMinutes: 20, waitAmber: 30, waitRed: 60,
        discountLimit: { front_desk: 200, billing: 500, optician: 300, counsellor: 1000, owner: 1e9 }, countersignOptomRx: true,
        messageQuota: 1500, messagesUsed: 642 }
    };

    var R = K.ROLES = {
      owner: 'Owner / admin', doctor: 'Ophthalmologist', optometrist: 'Optometrist', front_desk: 'Front desk',
      counsellor: 'Counsellor', optician: 'Optician', nurse: 'Nurse / ward', ot: 'OT coordinator', pharmacist: 'Pharmacist', billing: 'Billing'
    };
    db.users = [
      { id: 'u_owner', name: 'Rahul Deshpande', roles: ['owner'], branches: ['br_1', 'br_2'], phone: '9000000001', pin: '1234' },
      { id: 'u_doc1', name: 'Dr. Anjali Rao', roles: ['doctor'], branches: ['br_1', 'br_2'], phone: '9000000002', pin: '1234', regNo: 'MMC-2011-04567', qual: 'MS (Ophth)', special: 'Cataract & refractive' },
      { id: 'u_doc2', name: 'Dr. Vikram Shah', roles: ['doctor', 'owner'], branches: ['br_1'], phone: '9000000003', pin: '1234', regNo: 'MMC-2006-01188', qual: 'MS, FRCS', special: 'Glaucoma & retina' },
      { id: 'u_opt1', name: 'Sneha Patil', roles: ['optometrist'], branches: ['br_1'], phone: '9000000004', pin: '1234', regNo: 'OPT-MH-3321' },
      { id: 'u_desk', name: 'Pooja Jadhav', roles: ['front_desk'], branches: ['br_1'], phone: '9000000005', pin: '1234' },
      { id: 'u_couns', name: 'Kavita Joshi', roles: ['counsellor'], branches: ['br_1'], phone: '9000000006', pin: '1234' },
      { id: 'u_optician', name: 'Imran Shaikh', roles: ['optician'], branches: ['br_1'], phone: '9000000007', pin: '1234' },
      { id: 'u_nurse', name: 'Mary Thomas', roles: ['nurse'], branches: ['br_1'], phone: '9000000008', pin: '1234' },
      { id: 'u_ot', name: 'Ravi Pawar', roles: ['ot'], branches: ['br_1'], phone: '9000000009', pin: '1234' },
      { id: 'u_pharm', name: 'Nitin Gokhale', roles: ['pharmacist'], branches: ['br_1'], phone: '9000000010', pin: '1234' },
      { id: 'u_bill', name: 'Swati More', roles: ['billing'], branches: ['br_1'], phone: '9000000011', pin: '1234' }
    ];

    /* ---------- Masters ---------- */
    db.diagnoses = [
      ['H25.1', 'Age-related nuclear cataract'], ['H25.9', 'Age-related cataract, unspecified'], ['H40.1', 'Primary open-angle glaucoma'],
      ['H40.0', 'Glaucoma suspect'], ['H52.1', 'Myopia'], ['H52.0', 'Hypermetropia'], ['H52.2', 'Astigmatism'], ['H52.4', 'Presbyopia'],
      ['H36.0', 'Diabetic retinopathy'], ['H35.3', 'Degeneration of macula (AMD)'], ['H10.9', 'Conjunctivitis, unspecified'],
      ['H10.1', 'Acute atopic (allergic) conjunctivitis'], ['H04.1', 'Dry eye syndrome'], ['H26.4', 'After-cataract (PCO)'],
      ['Z96.1', 'Pseudophakia (IOL in situ)'], ['H53.0', 'Amblyopia'], ['H50.0', 'Convergent strabismus'], ['H11.0', 'Pterygium'], ['H00.0', 'Hordeolum (stye)']
    ].map(function (d) { return { code: d[0], name: d[1] }; });

    db.services = [
      { code: 'CON-N', desc: 'Consultation (new)', rate: 500, stream: 'OPD' }, { code: 'CON-R', desc: 'Consultation (review)', rate: 300, stream: 'OPD' },
      { code: 'CON-PO', desc: 'Post-op review', rate: 0, stream: 'OPD' }, { code: 'OCT', desc: 'OCT (per eye)', rate: 1500, stream: 'Investigations' },
      { code: 'VF', desc: 'Visual field (per eye)', rate: 1200, stream: 'Investigations' }, { code: 'BIO', desc: 'Optical biometry', rate: 1000, stream: 'Investigations' },
      { code: 'FUN', desc: 'Fundus photo', rate: 600, stream: 'Investigations' }, { code: 'TELE', desc: 'Teleconsultation', rate: 400, stream: 'OPD' }
    ];

    db.packages = [
      { id: 'pk1', name: 'SICS + rigid IOL', price: 12000, iol: 'Rigid PMMA', notes: 'Small-incision surgery, day care' },
      { id: 'pk2', name: 'Phaco + monofocal foldable IOL', price: 35000, iol: 'OptiFold Monofocal', notes: 'Most chosen; day care' },
      { id: 'pk3', name: 'Phaco + toric IOL', price: 65000, iol: 'OptiFold Toric', notes: 'Corrects astigmatism' },
      { id: 'pk4', name: 'Phaco + multifocal IOL', price: 85000, iol: 'VistaFlex Multifocal', notes: 'Less need for reading glasses' }
    ];

    var inv = [];
    var add = function (o) { o.id = o.id || 'it_' + (inv.length + 1); inv.push(o); };
    // drugs: class used for allergy checks
    [['Moxifloxacin 0.5% eye drops', 'Fluoroquinolone', 'DRG001', 140, 46, 20, 400],
     ['Prednisolone acetate 1% eye drops', 'Corticosteroid', 'DRG002', 95, 30, 15, 380],
     ['Nepafenac 0.1% eye drops', 'NSAID', 'DRG003', 210, 12, 10, 300],
     ['Carboxymethylcellulose 0.5% eye drops', 'Lubricant', 'DRG004', 160, 58, 20, 500],
     ['Timolol 0.5% eye drops', 'Beta-blocker', 'DRG005', 60, 9, 10, 250],
     ['Latanoprost 0.005% eye drops', 'Prostaglandin analogue', 'DRG006', 390, 4, 8, 60],
     ['Brimonidine 0.2% eye drops', 'Alpha-agonist', 'DRG007', 180, 14, 8, 200],
     ['Olopatadine 0.1% eye drops', 'Antihistamine', 'DRG008', 175, 21, 10, 22],
     ['Tropicamide + phenylephrine eye drops', 'Mydriatic', 'DRG009', 85, 18, 6, 300],
     ['Atropine 1% eye drops', 'Cycloplegic', 'DRG010', 70, 7, 5, 280]
    ].forEach(function (d, i) {
      add({ type: 'drug', name: d[0], cls: d[1], sku: d[2], barcode: '890' + d[2].slice(3) + '00' + i, price: d[3], qty: d[4], reorder: d[5],
        batch: 'B' + (2400 + i * 7), expiry: now + d[6] * 86400000, gst: 12 });
    });
    [['Titan-style full rim, black', 'FR1001', 2200], ['Rimless titanium, gunmetal', 'FR1002', 4500], ['Kids flexi, blue', 'FR1003', 1500],
     ['Acetate cat-eye, tortoise', 'FR1004', 3200], ['Half rim metal, silver', 'FR1005', 2800], ['TR90 sports, matte grey', 'FR1006', 2600],
     ['Classic round, gold', 'FR1007', 3900], ['Budget full rim, brown', 'FR1008', 900]
    ].forEach(function (f, i) { add({ type: 'frame', name: f[0], sku: f[1], barcode: f[1], price: f[2], qty: [6, 3, 8, 2, 5, 4, 1, 12][i], reorder: 2, gst: 12 }); });
    [['Single vision 1.50 HMC', 'LN01', 1200, 'single'], ['Single vision 1.56 blue-cut', 'LN02', 2400, 'single'], ['Single vision 1.67 thin', 'LN03', 4800, 'single'],
     ['Bifocal KT 1.50', 'LN04', 1800, 'bifocal'], ['Progressive 1.56 standard', 'LN05', 6500, 'progressive'], ['Progressive 1.60 premium', 'LN06', 12500, 'progressive']
    ].forEach(function (l) { add({ type: 'lens', name: l[0], sku: l[1], barcode: l[1], price: l[2], lensType: l[3], qty: 99, reorder: 0, gst: 12 }); });
    [['OptiFold Monofocal', 'IOL-M', [20.5, 21, 21.5, 22, 22.5, 23]], ['OptiFold Toric T3', 'IOL-T', [21, 21.5, 22]], ['VistaFlex Multifocal', 'IOL-MF', [21.5, 22]]
    ].forEach(function (m) {
      m[2].forEach(function (p, j) {
        add({ type: 'iol', name: m[0] + ' ' + p.toFixed(1) + ' D', model: m[0], power: p, sku: m[1] + '-' + p, barcode: m[1] + '-' + (p * 10) + '-SN' + (5100 + j),
          serial: 'SN' + (5100 + j), price: m[1] === 'IOL-M' ? 9000 : m[1] === 'IOL-T' ? 28000 : 42000, qty: 1, reorder: 0, consignment: m[1] !== 'IOL-M', expiry: now + 600 * 86400000, gst: 5 });
      });
    });
    db.inventory = inv;
    var drug = function (sku) { return inv.filter(function (i) { return i.sku === sku; })[0]; };

    db.rxTemplates = [
      { id: 'tpl_postcat', name: 'Post-cataract surgery', dx: ['Z96.1'], lines: [
        { sku: 'DRG001', freq: '4 times/day', duration: '1 week', taper: null },
        { sku: 'DRG002', freq: 'taper', duration: '4 weeks', taper: ['6 times/day x 1 week', '4 times/day x 1 week', '3 times/day x 1 week', '2 times/day x 1 week'] },
        { sku: 'DRG003', freq: '3 times/day', duration: '4 weeks', taper: null },
        { sku: 'DRG004', freq: '4 times/day', duration: '4 weeks', taper: null }] },
      { id: 'tpl_poag', name: 'Open-angle glaucoma (start)', dx: ['H40.1'], lines: [{ sku: 'DRG006', freq: 'Once daily at bedtime', duration: 'Long term', taper: null }] },
      { id: 'tpl_conj', name: 'Bacterial conjunctivitis', dx: ['H10.9'], lines: [{ sku: 'DRG001', freq: '4 times/day', duration: '7 days', taper: null }, { sku: 'DRG004', freq: '4 times/day', duration: '2 weeks', taper: null }] },
      { id: 'tpl_allergy', name: 'Allergic conjunctivitis', dx: ['H10.1'], lines: [{ sku: 'DRG008', freq: '2 times/day', duration: '2 weeks', taper: null }, { sku: 'DRG004', freq: '4 times/day', duration: '2 weeks', taper: null }] },
      { id: 'tpl_dry', name: 'Dry eye', dx: ['H04.1'], lines: [{ sku: 'DRG004', freq: '4 times/day', duration: '1 month', taper: null }] }
    ];

    /* ---------- Patients ---------- */
    var P = [
      ['p01', 'Asha Patil', 'F', '1958-03-12', '9822001101', 'Pune', { diabetic: true }, [], 'Doctor referral'],
      ['p02', 'Ramesh Kulkarni', 'M', '1961-07-04', '9822001102', 'Pune', { glaucoma: true }, ['Brimonidine'], 'Walk-in'],
      ['p03', 'Priya Nair', 'F', '1994-11-20', '9822001103', 'Pune', { cl: true }, [], 'Online'],
      ['p04', 'Mohammed Arif', 'M', '1972-01-15', '9822001104', 'Pimpri', { diabetic: true }, [], 'Camp'],
      ['p05', 'Lakshmi Iyer', 'F', '1949-09-30', '9822001105', 'Pune', { postop: true }, ['Fluoroquinolone'], 'Doctor referral'],
      ['p06', 'Kunal Mehta', 'M', '2016-05-10', '9822001117', 'Pune', {}, [], 'Walk-in'],
      ['p07', 'Fatima Sheikh', 'F', '1985-02-02', '9822001107', 'Pune', {}, [], 'Walk-in'],
      ['p08', 'Suresh Yadav', 'M', '1955-12-01', '9822001108', 'Hadapsar', { diabetic: true }, [], 'Camp'],
      ['p09', 'Anita Deshmukh', 'F', '1978-06-18', '9822001109', 'Pune', {}, [], 'Online'],
      ['p10', 'George Fernandes', 'M', '1966-08-22', '9822001110', 'Pune', {}, [], 'Insurance'],
      ['p11', 'Neha Gupta', 'F', '1990-04-04', '9822001111', 'Baner', {}, [], 'Online'],
      ['p12', 'Vijay Rane', 'M', '1952-10-10', '9822001112', 'Pune', { glaucoma: true }, [], 'Walk-in'],
      ['p13', 'Sunita Bhosale', 'F', '1960-01-25', '9822001113', 'Pune', { postop: true }, [], 'Doctor referral'],
      ['p14', 'Harish Chandra', 'M', '1958-05-05', '9822001114', 'Satara', { diabetic: true }, [], 'Camp'],
      ['p15', 'Kamala Devi', 'F', '1950-03-03', '9822001115', 'Pune', {}, ['Penicillin'], 'Walk-in'],
      ['p16', 'Arjun Singh', 'M', '1988-09-09', '9822001116', 'Pune', {}, [], 'Online'],
      ['p17', 'Rohit Mehta', 'M', '1983-02-14', '9822001117', 'Pune', {}, [], 'Walk-in']
    ];
    db.patients = P.map(function (p, i) {
      return { id: p[0], uhid: 'DEC-' + (24100 + i), name: p[1], sex: p[2], dob: p[3], phone: p[4], city: p[5], pincode: '4110' + (10 + i),
        flags: p[6], allergies: p[7], referral: p[8], payer: p[0] === 'p10' ? 'Insurance' : 'Self', abha: i % 3 === 0 ? '91-' + (4000 + i) + '-' + (6000 + i * 3) + '-' + (2000 + i) : '',
        guardian: p[0] === 'p06' ? { name: 'Rohit Mehta', phone: '9822001117' } : null,
        consent: { treatment: true, marketing: i % 2 === 0, ts: D(30 + i), version: 'v1.2' }, createdAt: D(400 - i * 10), photo: null };
    });
    // Background patients for completed visits earlier today (dashboard realism)
    var first = ['Sanjay', 'Rekha', 'Amit', 'Deepa', 'Prakash', 'Shalini', 'Manoj', 'Geeta', 'Rajesh', 'Uma', 'Kiran', 'Nisha', 'Mahesh', 'Savita', 'Ajay', 'Usha', 'Dinesh', 'Meena'];
    var last = ['Pawar', 'Joshi', 'Sawant', 'Kale', 'Shinde', 'Gaikwad', 'More', 'Chavan', 'Naik', 'Bhat'];
    for (var g = 0; g < 18; g++) {
      db.patients.push({ id: 'pg' + g, uhid: 'DEC-' + (23000 + g), name: first[g] + ' ' + last[g % last.length], sex: g % 2 ? 'F' : 'M', dob: (1950 + (g * 3) % 50) + '-0' + (1 + g % 9) + '-1' + (g % 9),
        phone: '98330' + (10000 + g * 37), city: 'Pune', pincode: '411038', flags: {}, allergies: [], referral: 'Walk-in', payer: 'Self', abha: '', guardian: null,
        consent: { treatment: true, marketing: false, ts: D(200), version: 'v1.2' }, createdAt: D(300) });
    }

    /* ---------- Exam helpers ---------- */
    var eyes = function (od, os) { return { OD: od, OS: os }; };
    var ref = function (s, c, a, add) { return { sph: s, cyl: c, axis: a, add: add || 0 }; };
    var normalAnt = { lids: 'Normal', conjunctiva: 'Normal', cornea: 'Clear', ac: 'Normal depth, quiet', iris: 'Normal', pupil: 'Round, reacting', lens: 'Clear' };
    var ant = function (lensOD, lensOS) { var a = U.clone(normalAnt), b = U.clone(normalAnt); a.lens = lensOD; b.lens = lensOS; return eyes(a, b); };
    var post = function (cdrOD, cdrOS, dr) { return eyes({ media: 'Clear', cdr: cdrOD, macula: 'Normal', vessels: 'Normal', periphery: 'Normal', dr: dr || 'No DR' }, { media: 'Clear', cdr: cdrOS, macula: 'Normal', vessels: 'Normal', periphery: 'Normal', dr: dr || 'No DR' }); };

    db.visits = []; db.bills = []; db.messages = []; db.audit = []; db.jobs = [];
    var token = 0;
    var mkVisit = function (o) {
      token++;
      var v = { id: o.id || 'v_' + token, patientId: o.p, branchId: 'br_1', token: o.token || token, type: o.type || 'review', stage: o.stage,
        doctorId: o.doc || 'u_doc1', assignee: o.assignee || null, priority: o.priority || [], arrivedAt: o.arrived, stageLog: o.log || [{ stage: 'arrived', ts: o.arrived, by: 'u_desk' }],
        dilation: o.dilation || null, exam: o.exam || {}, examBy: o.examBy || {}, examSource: o.examSource || {}, diagnoses: o.dx || [],
        rx: o.rx || { drugs: [], spectacle: null, cl: null, advice: [], followUpDays: null, signedAt: null, signedBy: null, draftBy: null },
        services: o.services || [], billId: null, signedAt: o.signedAt || null, signedBy: o.signedBy || null, addenda: [], investigations: o.inv || [], createdAt: o.arrived };
      db.visits.push(v); return v;
    };

    // Past visits for trends (p01 cataract progression, p02 glaucoma IOP, p03 myopia)
    [[400, 'p01', '6/9', '6/9', 18, 17, 'NS1', 'NS1'], [220, 'p01', '6/12', '6/9', 17, 16, 'NS2', 'NS1'], [60, 'p01', '6/18', '6/12', 17, 17, 'NS2', 'NS2'],
     [500, 'p02', '6/6', '6/6', 26, 24, 'Clear', 'Clear'], [380, 'p02', '6/6', '6/6', 22, 21, 'Clear', 'Clear'], [200, 'p02', '6/6', '6/9', 19, 18, 'Clear', 'Clear'], [90, 'p02', '6/9', '6/9', 18, 18, 'NS1', 'NS1'],
     [365, 'p03', '6/6', '6/6', 14, 15, 'Clear', 'Clear']
    ].forEach(function (h, i) {
      var ts = D(h[0]);
      var isG = h[1] === 'p02';
      mkVisit({ id: 'vh' + i, p: h[1], stage: 'completed', arrived: ts, token: 0, doc: isG ? 'u_doc2' : 'u_doc1',
        exam: { vision: { notation: 'snellen', ua: eyes(h[2], h[3]), ph: eyes('', ''), bcva: eyes(h[2], h[3]), near: eyes('N8', 'N8') },
          iop: { method: 'NCT', OD: h[4], OS: h[5], time: ts },
          refraction: { final: h[1] === 'p03' ? eyes(ref(-2.25, -0.5, 180), ref(-2.0, -0.75, 170)) : eyes(ref(0.5, -0.75, 90, 2.5), ref(0.75, -0.5, 85, 2.5)), pd: 62 },
          anterior: ant(h[6], h[7]), posterior: post(isG ? 0.6 : 0.3, isG ? 0.55 : 0.3) },
        dx: isG ? [{ code: 'H40.1', name: 'Primary open-angle glaucoma', eye: 'OU' }] : h[1] === 'p01' ? [{ code: 'H25.1', name: 'Age-related nuclear cataract', eye: 'OU' }] : [{ code: 'H52.1', name: 'Myopia', eye: 'OU' }],
        signedAt: ts + 1800000, signedBy: isG ? 'u_doc2' : 'u_doc1', log: [{ stage: 'arrived', ts: ts }, { stage: 'completed', ts: ts + 3600000 }] });
    });
    token = 0;

    /* ---------- Today's queue ---------- */
    var wu = function (vaOD, vaOS, iopOD, iopOS, rOD, rOS) {
      return { vision: { notation: 'snellen', ua: eyes(vaOD, vaOS), ph: eyes('', ''), bcva: eyes('', ''), near: eyes('', '') },
        iop: { method: 'NCT', OD: iopOD, OS: iopOS, time: T(30) }, refraction: { auto: eyes(rOD, rOS), final: eyes(U.clone(rOD), U.clone(rOS)), pd: 63 } };
    };
    // Completed earlier today (background, with bills)
    for (var c = 0; c < 18; c++) {
      var arr = T(420 - c * 18);
      var newPt = c % 3 === 0;
      var vc = mkVisit({ p: 'pg' + c, stage: 'completed', arrived: arr, type: newPt ? 'new' : 'review', doc: c % 2 ? 'u_doc2' : 'u_doc1',
        log: [{ stage: 'arrived', ts: arr }, { stage: 'workup', ts: arr + 9 * 60000 }, { stage: 'doctor', ts: arr + 27 * 60000 }, { stage: 'billing', ts: arr + 41 * 60000 }, { stage: 'completed', ts: arr + 48 * 60000 }],
        signedAt: arr + 40 * 60000, signedBy: c % 2 ? 'u_doc2' : 'u_doc1', dx: [{ code: 'H52.4', name: 'Presbyopia', eye: 'OU' }],
        services: [newPt ? { code: 'CON-N', desc: 'Consultation (new)', rate: 500, qty: 1, stream: 'OPD', gst: 0 } : { code: 'CON-R', desc: 'Consultation (review)', rate: 300, qty: 1, stream: 'OPD', gst: 0 }] });
      var lines = U.clone(vc.services);
      if (c % 4 === 1) lines.push({ code: 'OCT', desc: 'OCT (per eye)', rate: 1500, qty: 2, stream: 'Investigations', gst: 0 });
      if (c % 3 === 2) lines.push({ code: 'FR1008', desc: 'Frame + SV lenses', rate: 3300, qty: 1, stream: 'Optical', gst: 12 });
      if (c % 5 === 0) lines.push({ code: 'DRG004', desc: 'Carboxymethylcellulose 0.5% eye drops', rate: 160, qty: 1, stream: 'Pharmacy', gst: 12 });
      var total = U.sum(lines, function (l) { return l.rate * l.qty * (1 + (l.gst || 0) / 100); });
      var bill = { id: 'b_' + c, invoiceNo: 'KOT/26-27/' + (1801 + c), visitId: vc.id, patientId: vc.patientId, branchId: 'br_1', lines: lines, discount: c === 7 ? 100 : 0,
        total: Math.round(total) - (c === 7 ? 100 : 0), payments: [{ mode: ['UPI', 'Cash', 'Card'][c % 3], amount: Math.round(total) - (c === 7 ? 100 : 0), ts: arr + 47 * 60000, ref: 'TXN' + (88100 + c) }], status: 'paid', createdAt: arr + 45 * 60000, by: 'u_desk' };
      db.bills.push(bill); vc.billId = bill.id;
    }
    token = 18;

    mkVisit({ id: 'v_p02', p: 'p02', stage: 'arrived', arrived: T(12), type: 'review', doc: 'u_doc2' });
    mkVisit({ id: 'v_p11w', p: 'p16', stage: 'arrived', arrived: T(4), type: 'new', doc: 'u_doc1' });
    mkVisit({ id: 'v_p03', p: 'p03', stage: 'workup', arrived: T(26), type: 'review', assignee: 'u_opt1',
      log: [{ stage: 'arrived', ts: T(26) }, { stage: 'workup', ts: T(8), by: 'u_opt1' }], exam: { vision: { notation: 'snellen', ua: eyes('6/36', '6/24'), ph: eyes('6/9', '6/9'), bcva: eyes('', ''), near: eyes('N6', 'N6') } }, examBy: { vision: 'u_opt1' } });
    mkVisit({ id: 'v_p04', p: 'p04', stage: 'dilating', arrived: T(44), type: 'review', dilation: { start: T(14), minutes: 20, drops: 'Tropicamide + phenylephrine', by: 'u_opt1' },
      log: [{ stage: 'arrived', ts: T(44) }, { stage: 'workup', ts: T(30) }, { stage: 'dilating', ts: T(14) }],
      exam: wu('6/12', '6/18', 16, 17, ref(-0.5, -0.5, 90), ref(-0.75, -0.25, 80)), examBy: { vision: 'u_opt1', iop: 'u_opt1', refraction: 'u_opt1' } });
    mkVisit({ id: 'v_p01', p: 'p01', stage: 'doctor', arrived: T(58), type: 'review', priority: ['elderly'],
      log: [{ stage: 'arrived', ts: T(58) }, { stage: 'workup', ts: T(45) }, { stage: 'dilating', ts: T(36) }, { stage: 'doctor', ts: T(16) }],
      dilation: { start: T(36), minutes: 20, drops: 'Tropicamide + phenylephrine', by: 'u_opt1', done: true },
      exam: wu('6/24', '6/12', 17, 18, ref(0.75, -1.0, 95, 2.5), ref(0.5, -0.75, 80, 2.5)), examBy: { vision: 'u_opt1', iop: 'u_opt1', refraction: 'u_opt1' } });
    mkVisit({ id: 'v_p05', p: 'p05', stage: 'doctor', arrived: T(22), type: 'postop', priority: ['postop'], assignee: 'u_doc1',
      log: [{ stage: 'arrived', ts: T(22) }, { stage: 'workup', ts: T(18) }, { stage: 'doctor', ts: T(6), by: 'u_doc1' }],
      exam: { vision: { notation: 'snellen', ua: eyes('6/12', '6/18'), ph: eyes('6/9', ''), bcva: eyes('', ''), near: eyes('', '') }, iop: { method: 'NCT', OD: 19, OS: 15, time: T(17) } }, examBy: { vision: 'u_opt1', iop: 'u_opt1' } });
    mkVisit({ id: 'v_p08', p: 'p08', stage: 'counselling', arrived: T(95), type: 'review', log: [{ stage: 'arrived', ts: T(95) }, { stage: 'doctor', ts: T(50) }, { stage: 'counselling', ts: T(15) }],
      exam: wu('6/60', '6/18', 15, 16, ref(1.0, -0.5, 90), ref(0.75, -0.5, 90)), dx: [{ code: 'H25.1', name: 'Age-related nuclear cataract', eye: 'OD' }], signedAt: T(20), signedBy: 'u_doc1',
      services: [{ code: 'CON-R', desc: 'Consultation (review)', rate: 300, qty: 1, stream: 'OPD', gst: 0 }, { code: 'BIO', desc: 'Optical biometry', rate: 1000, qty: 1, stream: 'Investigations', gst: 0 }] });
    var v6 = mkVisit({ id: 'v_p06', p: 'p06', stage: 'optical', arrived: T(80), type: 'new', log: [{ stage: 'arrived', ts: T(80) }, { stage: 'doctor', ts: T(45) }, { stage: 'optical', ts: T(10) }],
      exam: wu('6/24', '6/18', 14, 14, ref(-1.75, -0.75, 180), ref(-1.5, -0.5, 175)), dx: [{ code: 'H52.1', name: 'Myopia', eye: 'OU' }, { code: 'H52.2', name: 'Astigmatism', eye: 'OU' }],
      signedAt: T(12), signedBy: 'u_doc1', services: [{ code: 'CON-N', desc: 'Consultation (new)', rate: 500, qty: 1, stream: 'OPD', gst: 0 }] });
    v6.rx = { drugs: [], spectacle: { OD: ref(-1.75, -0.75, 180), OS: ref(-1.5, -0.5, 175), pd: 56, lensAdvice: 'Single vision, polycarbonate', coating: 'Anti-reflective', validMonths: 6 },
      cl: null, advice: ['Wear glasses full time', 'Review in 6 months'], followUpDays: 180, signedAt: T(12), signedBy: 'u_doc1', draftBy: 'u_opt1' };
    var v7 = mkVisit({ id: 'v_p07', p: 'p07', stage: 'pharmacy', arrived: T(70), type: 'new', log: [{ stage: 'arrived', ts: T(70) }, { stage: 'doctor', ts: T(35) }, { stage: 'pharmacy', ts: T(5) }],
      exam: wu('6/6', '6/6', 13, 14, ref(0, 0, 0), ref(0, 0, 0)), dx: [{ code: 'H10.1', name: 'Acute atopic (allergic) conjunctivitis', eye: 'OU' }], signedAt: T(7), signedBy: 'u_doc2',
      services: [{ code: 'CON-N', desc: 'Consultation (new)', rate: 500, qty: 1, stream: 'OPD', gst: 0 }] });
    v7.rx = { drugs: [{ sku: 'DRG008', name: drug('DRG008').name, eye: 'OU', freq: '2 times/day', duration: '2 weeks', taper: null, qty: 1 },
      { sku: 'DRG004', name: drug('DRG004').name, eye: 'OU', freq: '4 times/day', duration: '2 weeks', taper: null, qty: 1 }], spectacle: null, cl: null,
      advice: ['Cold compresses', 'Avoid rubbing eyes'], followUpDays: 14, signedAt: T(7), signedBy: 'u_doc2' };
    mkVisit({ id: 'v_p09', p: 'p09', stage: 'billing', arrived: T(65), type: 'review', log: [{ stage: 'arrived', ts: T(65) }, { stage: 'doctor', ts: T(30) }, { stage: 'billing', ts: T(3) }],
      exam: wu('6/6', '6/6', 15, 15, ref(0.25, 0, 0, 1.75), ref(0.25, -0.25, 90, 1.75)), dx: [{ code: 'H52.4', name: 'Presbyopia', eye: 'OU' }], signedAt: T(5), signedBy: 'u_doc1',
      services: [{ code: 'CON-R', desc: 'Consultation (review)', rate: 300, qty: 1, stream: 'OPD', gst: 0 }, { code: 'FUN', desc: 'Fundus photo', rate: 600, qty: 1, stream: 'Investigations', gst: 0 }] });

    /* ---------- Appointments (later today + tomorrow) ---------- */
    db.appointments = [
      { id: 'ap1', patientId: 'p11', doctorId: 'u_doc1', ts: at(17, 30), type: 'new', status: 'booked', source: 'Patient app' },
      { id: 'ap2', patientId: 'p12', doctorId: 'u_doc2', ts: at(18, 0), type: 'review', status: 'booked', source: 'WhatsApp' },
      { id: 'ap3', patientId: 'p16', doctorId: 'u_doc1', ts: at(18, 30), type: 'review', status: 'booked', source: 'Phone' },
      { id: 'ap4', patientId: 'p10', doctorId: 'u_doc2', ts: at(11, 0) + 86400000, type: 'review', status: 'booked', source: 'Phone' },
      { id: 'ap5', patientId: 'p13', doctorId: 'u_doc1', ts: at(10, 0) + 86400000, type: 'postop', status: 'booked', source: 'Auto (post-op day 1)' }
    ];

    /* ---------- Optical jobs ---------- */
    var job = function (id, p, status, frame, lens, ago, due, adv) {
      var j = { id: id, patientId: p, visitId: null, rx: { OD: ref(-2.25, -0.5, 180), OS: ref(-2.0, -0.75, 170), pd: 62 }, frame: frame, lens: lens,
        measure: { pd: 62, fitHeight: 20, a: 52, b: 38, dbl: 18 }, status: status, lab: 'Outside lab', due: now + due * 3600000, advance: adv,
        price: frame.price + lens.price, statusLog: [{ status: 'ordered', ts: T(ago) }], createdAt: T(ago), external: false };
      if (status !== 'ordered') j.statusLog.push({ status: 'in_lab', ts: T(ago - 30) });
      if (status === 'ready') j.statusLog.push({ status: 'received', ts: T(60) }, { status: 'ready', ts: T(40) });
      db.jobs.push(j);
    };
    var fr = function (sku) { var i = inv.filter(function (x) { return x.sku === sku; })[0]; return { sku: i.sku, name: i.name, price: i.price }; };
    job('job_1', 'p03', 'in_lab', fr('FR1004'), fr('LN02'), 1500, 4, 3000);
    job('job_2', 'p10', 'ready', fr('FR1002'), fr('LN05'), 2900, -2, 6000);
    job('job_3', 'p16', 'ordered', fr('FR1006'), fr('LN01'), 200, 30, 1000);
    job('job_4', 'p12', 'in_lab', fr('FR1007'), fr('LN04'), 3100, -6, 2500);

    /* ---------- IPD ---------- */
    db.beds = [];
    ['A1', 'A2', 'A3', 'A4', 'A5', 'A6'].forEach(function (b) { db.beds.push({ id: 'bed_' + b, ward: 'Day care ward', label: b, status: 'free', admissionId: null }); });
    ['P1', 'P2', 'P3', 'P4'].forEach(function (b) { db.beds.push({ id: 'bed_' + b, ward: 'Private rooms', label: b, status: 'free', admissionId: null }); });
    db.admissions = [];
    var admit = function (id, p, bed, ago, pkg, status) {
      var a = { id: id, patientId: p, bedId: 'bed_' + bed, admittedAt: T(ago), surgeonId: 'u_doc1', packageId: pkg, payer: 'Self', deposit: 10000, status: status || 'admitted',
        orders: [{ id: id + '_o1', type: 'drug', text: 'Moxifloxacin 0.5% eye drops OD 4 times/day', times: ['08:00', '12:00', '16:00', '20:00'] },
          { id: id + '_o2', type: 'drug', text: 'Prednisolone acetate 1% eye drops OD 6 times/day', times: ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00'] },
          { id: id + '_o3', type: 'care', text: 'Eye shield at night; head end elevated', times: [] }],
        nursing: [{ ts: T(ago - 20), by: 'u_nurse', bp: '138/84', pulse: 82, sugar: 164, pain: 2, note: 'Admitted, consent verified, eye marked' }],
        mar: [], discharge: null };
      db.admissions.push(a);
      var b = db.beds.filter(function (x) { return x.id === 'bed_' + bed; })[0]; b.status = 'occupied'; b.admissionId = id;
    };
    admit('adm_1', 'p13', 'A1', 300, 'pk2');
    admit('adm_2', 'p15', 'A2', 120, 'pk2');
    admit('adm_3', 'p14', 'A3', 90, 'pk3');
    db.beds.filter(function (b) { return b.label === 'A5'; })[0].status = 'cleaning';
    db.beds.filter(function (b) { return b.label === 'P2'; })[0].status = 'reserved';
    db.admissions[0].mar.push({ orderId: 'adm_1_o1', time: '08:00', ts: T(240), by: 'u_nurse', status: 'given' });

    /* ---------- OT ---------- */
    var ck = function (done) {
      var keys = ['consent', 'biometry', 'iolSelected', 'iolInStock', 'fitness', 'eyeMarked', 'fasting'];
      var pre = {}; keys.forEach(function (k) { pre[k] = done; });
      return { preop: pre, signIn: { done: done === true && false, by: null, ts: null }, timeOut: { done: false }, signOut: { done: false } };
    };
    db.otCases = [
      { id: 'ot_1', patientId: 'p13', admissionId: 'adm_1', theatre: 'OT-1', ts: at(9, 0), surgeonId: 'u_doc1', anaesthesia: 'Topical', procedure: 'Phacoemulsification + IOL', eye: 'OD',
        iolPlan: { model: 'OptiFold Monofocal', power: 21.5 }, iolImplanted: { model: 'OptiFold Monofocal', power: 21.5, serial: 'SN5102', code: 'IOL-M-215-SN5102' }, status: 'completed', checklist: ck(true), notes: 'Uneventful phaco; IOL in the bag.', complications: 'None' },
      { id: 'ot_2', patientId: 'p15', admissionId: 'adm_2', theatre: 'OT-1', ts: at(14, 0), surgeonId: 'u_doc1', anaesthesia: 'Peribulbar', procedure: 'Phacoemulsification + IOL', eye: 'OS',
        iolPlan: { model: 'OptiFold Monofocal', power: 22.0 }, iolImplanted: null, status: 'preop_ready', checklist: ck(true), notes: '', complications: '' },
      { id: 'ot_3', patientId: 'p14', admissionId: 'adm_3', theatre: 'OT-1', ts: at(15, 0), surgeonId: 'u_doc1', anaesthesia: 'Peribulbar', procedure: 'Phacoemulsification + toric IOL', eye: 'OS',
        iolPlan: { model: 'OptiFold Toric T3', power: 21.5 }, iolImplanted: null, status: 'scheduled', checklist: ck(false), notes: '', complications: '' },
      { id: 'ot_4', patientId: 'p08', admissionId: null, theatre: 'OT-2', ts: at(10, 0) + 2 * 86400000, surgeonId: 'u_doc1', anaesthesia: 'Topical', procedure: 'Phacoemulsification + IOL', eye: 'OD',
        iolPlan: { model: 'OptiFold Monofocal', power: 22.5 }, iolImplanted: null, status: 'scheduled', checklist: ck(false), notes: '', complications: '' }
    ];
    db.otCases[0].checklist.signIn = { done: true, by: 'u_ot', ts: at(8, 50) }; db.otCases[0].checklist.timeOut = { done: true, by: 'u_doc1', ts: at(9, 5) }; db.otCases[0].checklist.signOut = { done: true, by: 'u_ot', ts: at(9, 40) };
    db.otCases[2].checklist.preop.consent = true; db.otCases[2].checklist.preop.biometry = true;

    /* ---------- Counselling ---------- */
    db.counselling = [
      { id: 'cs_1', visitId: 'v_p08', patientId: 'p08', procedure: 'Cataract surgery', eye: 'OD', advisedBy: 'u_doc1', note: 'Dense NS3 OD; advised phaco', packageId: null, estimate: null, status: 'new', consent: null, surgeryTs: null, ts: T(15) },
      { id: 'cs_2', visitId: null, patientId: 'p12', procedure: 'Cataract surgery', eye: 'OS', advisedBy: 'u_doc2', note: 'Glaucoma patient; discuss toric vs monofocal', packageId: 'pk2', estimate: 35000, status: 'thinking', consent: null, surgeryTs: null, ts: D(6) }
    ];

    /* ---------- Inbox: approvals & notifications ---------- */
    db.approvals = [
      { id: 'apr_1', type: 'discount', refType: 'bill', refId: null, title: 'Optical discount ₹1,500', detail: 'Job job_3 (Arjun Singh): loyal patient, second pair', amount: 1500, requestedBy: 'u_optician', ts: T(35), status: 'pending' },
      { id: 'apr_2', type: 'purchase', refType: 'item', refId: 'it_6', title: 'Purchase: Latanoprost 0.005% × 30', detail: 'Stock 4, reorder level 8; supplier MedSupply Pune', amount: 11700, requestedBy: 'u_pharm', ts: T(120), status: 'pending' },
      { id: 'apr_3', type: 'refund', refType: 'bill', refId: 'b_3', title: 'Refund ₹600 — fundus photo not done', detail: 'Patient left before test; bill KOT/26-27/1804', amount: 600, requestedBy: 'u_desk', ts: T(200), status: 'approved', decidedBy: 'u_owner', decidedAt: T(190) }
    ];
    db.notifications = [
      { id: 'n1', to: ['doctor'], type: 'ready', title: 'Asha Patil ready for you', body: 'Dilated, work-up complete — token 23', ts: T(16), read: false, ref: { screen: 'visit', id: 'v_p01' } },
      { id: 'n2', to: ['pharmacist', 'owner'], type: 'stock', title: 'Low stock: Latanoprost 0.005%', body: '4 left, reorder level 8', ts: T(130), read: false, ref: { screen: 'stock' } },
      { id: 'n3', to: ['optician'], type: 'overdue', title: 'Job overdue: Vijay Rane', body: 'Bifocal KT — due 6 h ago at outside lab', ts: T(360), read: false, ref: { screen: 'job', id: 'job_4' } },
      { id: 'n4', to: ['owner'], type: 'approval', title: '2 approvals waiting', body: 'Optical discount, purchase request', ts: T(35), read: false, ref: { screen: 'approvals' } },
      { id: 'n5', to: ['nurse'], type: 'mar', title: 'Dose due: Kamala Devi (A2)', body: 'Prednisolone acetate 1% OS 12:00', ts: T(20), read: false, ref: { screen: 'admission', id: 'adm_2' } },
      { id: 'n6', to: ['ot'], type: 'ot', title: 'OT-1: Kamala Devi pre-op ready', body: 'Phaco OS at 2:00 pm, OptiFold Monofocal 22.0 D', ts: T(25), read: false, ref: { screen: 'otcase', id: 'ot_2' } }
    ];

    db.recalls = [
      { id: 'rc1', patientId: 'p12', rule: 'Glaucoma review every 3 months', due: D(-2), status: 'due', lastContact: null },
      { id: 'rc2', patientId: 'p04', rule: 'Diabetic: annual dilated fundus', due: D(5), status: 'sent', lastContact: D(3) },
      { id: 'rc3', patientId: 'p16', rule: 'Spectacle check yearly', due: D(10), status: 'due', lastContact: null },
      { id: 'rc4', patientId: 'p10', rule: 'Spectacle check yearly', due: D(20), status: 'booked', lastContact: D(18) },
      { id: 'rc5', patientId: 'pg3', rule: 'Diabetic: annual dilated fundus', due: D(1), status: 'not_reachable', lastContact: D(1) },
      { id: 'rc6', patientId: 'p03', rule: 'Contact lens follow-up 6 months', due: D(-5), status: 'due', lastContact: null }
    ];

    db.messages.push({ id: 'm1', patientId: 'p11', channel: 'WhatsApp', template: 'booking_confirmation', text: 'Your appointment with Dr. Anjali Rao is confirmed for today 5:30 pm.', ts: T(300), status: 'read' });
    db.messages.push({ id: 'm2', patientId: 'p10', channel: 'WhatsApp', template: 'order_ready', text: 'Your spectacles are ready for pickup at Drishti Eye Care, Kothrud.', ts: T(40), status: 'delivered' });

    db.devices = [
      { userId: 'u_doc1', name: 'Samsung Galaxy Tab S9 (exam room 1)', lastSeen: T(2), shared: true },
      { userId: 'u_doc1', name: 'Pixel 8 (personal)', lastSeen: T(240), shared: false },
      { userId: 'u_desk', name: 'Lenovo Tab M10 (reception)', lastSeen: T(1), shared: true }
    ];
    db.sync = { online: true, pending: [] };
    db.audit.push({ id: 'a0', ts: now, userId: 'system', action: 'seed', entity: 'demo', entityId: '-', detail: 'Demo data generated' });
    return db;
  };
})();
