/* Visit workspace (PRD Epic 4): tabs in exam order, OD/OS side by side, steppers,
   device import, copy OD->OS, same as last visit, autosave, sign/lock + addendum */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var TABS = [['history', 'History'], ['vision', 'Vision'], ['refraction', 'Refraction'], ['iop', 'IOP'], ['anterior', 'Anterior'], ['posterior', 'Posterior'], ['investigations', 'Tests'], ['plan', 'Diagnosis + Rx']];
  var vs = { id: null, tab: 'vision', visit: null, prev: null, saveTimer: null, dirty: false };
  var ANT = { lids: ['Normal', 'Blepharitis', 'Chalazion', 'Ptosis', 'Stye'], conjunctiva: ['Normal', 'Congested', 'Papillae', 'Pterygium', 'Subconjunctival haemorrhage'],
    cornea: ['Clear', 'Oedema', 'Opacity', 'Abrasion', 'Ulcer', 'Arcus'], ac: ['Normal depth, quiet', 'Shallow', 'Cells +', 'Cells ++', 'Flare', 'Hyphaema'],
    iris: ['Normal', 'Rubeosis', 'Atrophy', 'Synechiae'], pupil: ['Round, reacting', 'RAPD', 'Sluggish', 'Fixed dilated', 'Irregular'],
    lens: ['Clear', 'NS1', 'NS2', 'NS3', 'NS4', 'Cortical', 'PSC', 'Mature', 'PCIOL', 'PCO', 'Aphakia'] };
  var POST = { media: ['Clear', 'Hazy', 'Vitreous haemorrhage'], cdr: ['0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', '0.9'], macula: ['Normal', 'Drusen', 'CSME', 'Oedema', 'Scar', 'ERM'],
    vessels: ['Normal', 'AV nicking', 'Neovascularisation'], periphery: ['Normal', 'Lattice', 'Holes', 'Detachment'], dr: ['No DR', 'Mild NPDR', 'Moderate NPDR', 'Severe NPDR', 'PDR'] };
  var COMPLAINTS = ['Blurred distance vision', 'Blurred near vision', 'Redness', 'Watering', 'Itching', 'Pain', 'Glare', 'Floaters', 'Flashes', 'Headache', 'Routine check', 'Post-op review'];
  var LABEL = { lids: 'Lids', conjunctiva: 'Conjunctiva', cornea: 'Cornea', ac: 'Anterior chamber', iris: 'Iris', pupil: 'Pupil', lens: 'Lens', media: 'Media', cdr: 'Cup : disc', macula: 'Macula', vessels: 'Vessels', periphery: 'Periphery', dr: 'DR grade' };

  function locked() { return !!vs.visit.signedAt && vs.visit.rx && vs.visit.rx.signedAt; }
  function eyeBox(eye, inner) { return '<div class="eye ' + eye.toLowerCase() + '"><div class="eye-h"><span>' + (eye === 'OD' ? 'OD · Right' : 'OS · Left') + '</span></div>' + inner + '</div>'; }
  function copyBar(extra) { return (extra ? '<div class="small muted" style="margin:0 2px 6px">' + extra + '</div>' : '') + '<div class="row wrap" style="margin-bottom:8px"><button class="btn ghost sm" data-act="copyEye">Copy OD \u2192 OS</button>' + (vs.prev ? '<button class="btn ghost sm" data-act="sameLast">Same as last visit</button>' : '') + '</div>'; }
  function prevNote(text) { return vs.prev ? '<div class="banner-info small"><b>Last visit ' + U.date(vs.prev.createdAt) + ':</b> ' + text + '</div>' : ''; }
  function src(section) { var s = vs.visit.examSource && vs.visit.examSource[section]; return s === 'device' ? 'dev' : ''; }

  /* ---------------- Tab renderers ---------------- */
  var R = {};
  R.history = function (ex) {
    var h = ex.history || {}, sel = h.complaints || [];
    return '<div class="card"><b>Chief complaints</b><div class="row wrap" style="margin-top:6px">' + COMPLAINTS.map(function (c) {
      return '<button type="button" class="chip ' + (sel.indexOf(c) >= 0 ? 'on' : '') + '" data-act="complaint" data-c="' + esc(c) + '">' + esc(c) + '</button>';
    }).join('') + '</div>' +
      '<div class="grid2"><div><label class="f">Eye</label>' + C.select('h_eye', ['OD', 'OS', 'OU'], h.eye || 'OU') + '</div><div><label class="f">Duration</label>' + C.select('h_dur', ['Days', '1–4 weeks', '1–6 months', 'Over 6 months', 'Years'], h.duration || '', '—') + '</div></div>' +
      '<label class="f">Notes</label><textarea class="input" data-field="h_notes" placeholder="History in your words (voice dictation in P1)">' + esc(h.notes || '') + '</textarea></div>' +
      '<div class="card"><b>Systemic and ocular history</b>' +
      '<label class="check"><input type="checkbox" data-field="h_dm"' + (h.diabetes || (vs.visit.patient.flags && vs.visit.patient.flags.diabetic) ? ' checked' : '') + '> Diabetes</label>' +
      '<label class="check"><input type="checkbox" data-field="h_htn"' + (h.htn ? ' checked' : '') + '> Hypertension</label>' +
      '<label class="f">Previous eye surgery / trauma</label><input class="input" data-field="h_ocular" value="' + esc(h.ocular || '') + '">' +
      '<label class="f">Current medicines</label><input class="input" data-field="h_meds" value="' + esc(h.meds || '') + '">' +
      '<label class="f">Current glasses / contact lenses</label>' + C.select('h_glasses', ['None', 'Distance glasses', 'Reading glasses', 'Bifocals', 'Progressives', 'Contact lenses'], h.glasses || 'None') + '</div>' +
      (vs.prev ? '<button class="btn ghost block" data-act="sameHistory">No change since last visit</button>' : '');
  };
  R.vision = function (ex) {
    var v = ex.vision || { ua: {}, ph: {}, bcva: {}, near: {} };
    var f = function (eye) {
      return '<label class="small">Unaided distance</label>' + C.select('va_ua_' + eye, K.VA, (v.ua || {})[eye] || '', '—') +
        '<label class="small">Pinhole</label>' + C.select('va_ph_' + eye, K.VA, (v.ph || {})[eye] || '', '—') +
        '<label class="small">Best corrected</label>' + C.select('va_bcva_' + eye, K.VA, (v.bcva || {})[eye] || '', '—') +
        '<label class="small">Near</label>' + C.select('va_near_' + eye, K.NEAR, (v.near || {})[eye] || '', '—');
    };
    var pv = vs.prev && vs.prev.exam.vision;
    return prevNote(pv ? 'BCVA OD ' + esc(pv.bcva.OD || pv.ua.OD) + ', OS ' + esc(pv.bcva.OS || pv.ua.OS) : '') + copyBar('Snellen notation (clinic setting)') + '<div class="eyes">' + eyeBox('OD', f('OD')) + eyeBox('OS', f('OS')) + '</div>';
  };
  R.refraction = function (ex) {
    var r = ex.refraction || {}, fin = r.final || { OD: {}, OS: {} }, auto = r.auto;
    var st = function (eye) {
      var e = fin[eye] || {}, cls = src('refraction');
      return C.stepper('rf_sph_' + eye, 'Sphere', e.sph, { min: -30, max: 30, inc: 0.25, cls: cls }) + C.stepper('rf_cyl_' + eye, 'Cylinder', e.cyl, { min: -10, max: 10, inc: 0.25, cls: cls }) +
        C.stepper('rf_axis_' + eye, 'Axis', e.axis, { fmt: 'axis', min: 1, max: 180, inc: 5, cls: cls }) + C.stepper('rf_add_' + eye, 'Add', e.add, { min: 0, max: 4, inc: 0.25 }) +
        (auto && auto[eye] ? '<div class="small muted" style="margin-top:4px">Auto-ref: ' + C.rxText(auto[eye]) + '</div>' : '') +
        (r.k && r.k[eye] ? '<div class="small muted">K: ' + r.k[eye].k1 + ' / ' + r.k[eye].k2 + ' @ ' + r.k[eye].axis + '°</div>' : '') +
        (r.glasses && r.glasses[eye] ? '<div class="small muted">Current glasses: ' + C.rxText(r.glasses[eye]) + '</div>' : '');
    };
    var pf = vs.prev && vs.prev.exam.refraction && vs.prev.exam.refraction.final;
    return prevNote(pf ? 'OD ' + C.rxText(pf.OD) + ' · OS ' + C.rxText(pf.OS) : '') +
      (src('refraction') ? '<div class="banner-note">Values imported from the auto-refractor are outlined until you confirm them (CT-04-12). <button class="btn sm" data-act="confirmDevice" data-s="refraction">Confirm values</button></div>' : '') +
      '<div class="row wrap" style="margin-bottom:8px"><button class="btn secondary sm" data-act="device" data-d="autorefractor">' + K.icon('refresh', 'sm') + 'Auto-refractor</button><button class="btn secondary sm" data-act="device" data-d="lensmeter">' + K.icon('refresh', 'sm') + 'Lensmeter</button><button class="btn ghost sm" data-act="transpose">± Transpose cyl</button></div>' +
      copyBar('Final accepted refraction — feeds the spectacle Rx') + '<div class="eyes">' + eyeBox('OD', st('OD')) + eyeBox('OS', st('OS')) + '</div>' +
      '<div class="card" style="margin-top:10px"><div class="grid2"><div>' + C.stepper('rf_pd', 'PD (mm)', r.pd || null, { fmt: 'int', min: 40, max: 80, inc: 1 }) + '</div><div class="small muted">Sphere/cylinder in 0.25 D steps; axis 1–180°. Out-of-range values ask for confirmation.</div></div></div>';
  };
  R.iop = function (ex) {
    var i = ex.iop || {}, s = K.session.settings, warn = '';
    if (i.OD > s.iopThreshold || i.OS > s.iopThreshold) warn += '<div class="banner-note">IOP above ' + s.iopThreshold + ' mmHg (CT-04-07)</div>';
    if (i.OD && i.OS && Math.abs(i.OD - i.OS) > s.iopDiff) warn += '<div class="banner-note">OD–OS difference over ' + s.iopDiff + ' mmHg</div>';
    var pi = vs.prev && vs.prev.exam.iop;
    return prevNote(pi ? 'OD ' + pi.OD + ', OS ' + pi.OS + ' mmHg (' + esc(pi.method) + ')' : '') + warn +
      (src('iop') ? '<div class="banner-note">Imported from the tonometer — confirm before saving. <button class="btn sm" data-act="confirmDevice" data-s="iop">Confirm</button></div>' : '') +
      '<div class="row wrap" style="margin-bottom:8px"><button class="btn secondary sm" data-act="device" data-d="nct">' + K.icon('refresh', 'sm') + 'Import from NCT</button></div>' +
      '<label class="f">Method</label>' + C.seg('iop_method', [['NCT', 'Non-contact'], ['GAT', 'Applanation'], ['Rebound', 'Rebound']], i.method || 'NCT') +
      '<div class="eyes" style="margin-top:10px">' + eyeBox('OD', C.stepper('iop_OD', 'mmHg', i.OD, { fmt: 'int', min: 2, max: 70, inc: 1, cls: src('iop') })) + eyeBox('OS', C.stepper('iop_OS', 'mmHg', i.OS, { fmt: 'int', min: 2, max: 70, inc: 1, cls: src('iop') })) + '</div>' +
      '<p class="small muted">Recorded at ' + (i.time ? U.time(i.time) : 'save time') + '.</p>';
  };
  function structTab(key, opts, data, defaults) {
    var d = data || {};
    var f = function (eye) { return Object.keys(opts).map(function (k) { return '<label class="small">' + esc(LABEL[k]) + '</label>' + C.select(key + '_' + k + '_' + eye, opts[k], (d[eye] || {})[k] || '', '—'); }).join(''); };
    return '<div class="row between" style="margin-bottom:8px"><button class="btn secondary sm" data-act="allNormal" data-k="' + key + '">Tap: all normal</button><button class="btn ghost sm" data-act="copyEye">Copy OD → OS</button></div>' +
      '<div class="eyes">' + eyeBox('OD', f('OD')) + eyeBox('OS', f('OS')) + '</div>' +
      '<div class="card" style="margin-top:10px"><b>Eye drawing</b><p class="small muted">Stylus drawing on anterior / fundus templates and camera capture ship in Phase 2 (CT-04-10/11).</p><button class="btn ghost sm" data-act="photo">Attach photo (demo)</button></div>';
  }
  R.anterior = function (ex) { return structTab('ant', ANT, ex.anterior); };
  R.posterior = function (ex) {
    var dil = vs.visit.dilation;
    return (dil ? '<div class="banner-info small">Dilated with ' + esc(dil.drops) + ' at ' + U.time(dil.start) + '</div>' : '<div class="banner-note small">Not dilated in this visit.</div>') + structTab('post', POST, ex.posterior);
  };
  R.investigations = function (ex) {
    var inv = ex.investigations || { ordered: [], results: {} };
    var tests = [['OCT', 'OCT macula / RNFL'], ['VF', 'Visual field'], ['BIO', 'Optical biometry'], ['FUN', 'Fundus photo']];
    return '<div class="card"><b>Order tests</b>' + tests.map(function (t) { return '<label class="check"><input type="checkbox" data-field="inv_' + t[0] + '"' + (inv.ordered.indexOf(t[0]) >= 0 ? ' checked' : '') + '> ' + esc(t[1]) + '</label>'; }).join('') +
      '<p class="small muted">Ordered tests are added to the bill when the visit is signed.</p></div>' +
      '<div class="card"><b>Key results</b><div class="grid2">' +
      [['cmt', 'Central macular thickness (µm)'], ['rnfl', 'RNFL average (µm)'], ['md', 'VF mean deviation (dB)'], ['al', 'Axial length (mm)']].map(function (r) {
        return '<div><label class="small">' + esc(r[1]) + ' OD</label><input class="input" inputmode="decimal" data-field="res_' + r[0] + '_OD" value="' + esc((inv.results[r[0]] || {}).OD || '') + '"></div><div><label class="small">' + esc(r[1]) + ' OS</label><input class="input" inputmode="decimal" data-field="res_' + r[0] + '_OS" value="' + esc((inv.results[r[0]] || {}).OS || '') + '"></div>';
      }).join('') + '</div><button class="btn ghost sm" style="margin-top:8px" data-act="photo">Attach report PDF / DICOM (demo)</button></div>';
  };
  R.plan = function () {
    var v = vs.visit, rx = v.rx || {};
    var r = v.role;
    var summary = '<div class="card"><b>Diagnoses</b><div>' + (v.diagnoses.length ? v.diagnoses.map(function (d) { return C.pill(d.code, 'brand') + ' ' + esc(d.name) + ' (' + d.eye + ')'; }).join('<br>') : '<span class="muted">None yet</span>') + '</div>' +
      (rx.drugs && rx.drugs.length ? '<div class="hr"></div><b>Medicines</b><div class="small">' + rx.drugs.map(function (d) { return esc(d.name) + ' — ' + d.eye + ', ' + esc(d.freq) + (d.taper ? ' (taper)' : '') + ', ' + esc(d.duration); }).join('<br>') + '</div>' : '') +
      (rx.spectacle ? '<div class="hr"></div><b>Spectacle Rx</b><div class="small">OD ' + C.rxText(rx.spectacle.OD) + '<br>OS ' + C.rxText(rx.spectacle.OS) + '</div>' : '') +
      (rx.signedAt ? '<div class="hr"></div><div class="small">Signed by ' + esc(v.signer || '') + ' at ' + U.dateTime(rx.signedAt) + '</div>' : rx.awaitingCountersign ? '<div class="hr"></div>' + C.pill('Awaiting doctor countersign', 'warn') : '') + '</div>';
    var btn = '';
    if (!rx.signedAt && !rx.awaitingCountersign) btn = r === 'doctor' ? '<button class="btn block" data-act="openRx">Open Smart Rx</button>' : r === 'optometrist' ? '<button class="btn block secondary" data-act="openRx">Draft spectacle Rx</button>' : '';
    if (rx.awaitingCountersign && r === 'doctor') btn = '<button class="btn block" data-act="countersign">Review and countersign</button>';
    if (rx.signedAt) btn = '<button class="btn block ghost" data-act="printRx">View / share prescription</button>';
    return summary + btn;
  };

  /* ---------------- Collectors (form -> data) ---------------- */
  var G = {};
  G.history = function (root) {
    return { complaints: Array.prototype.map.call(root.querySelectorAll('[data-act=complaint].on'), function (b) { return b.getAttribute('data-c'); }),
      eye: C.fieldVal(root, 'h_eye'), duration: C.fieldVal(root, 'h_dur'), notes: C.fieldVal(root, 'h_notes'), diabetes: root.querySelector('[data-field=h_dm]').checked,
      htn: root.querySelector('[data-field=h_htn]').checked, ocular: C.fieldVal(root, 'h_ocular'), meds: C.fieldVal(root, 'h_meds'), glasses: C.fieldVal(root, 'h_glasses') };
  };
  G.vision = function (root) {
    var o = { notation: 'snellen', ua: {}, ph: {}, bcva: {}, near: {} };
    ['OD', 'OS'].forEach(function (e) { ['ua', 'ph', 'bcva', 'near'].forEach(function (k) { o[k][e] = C.fieldVal(root, 'va_' + k + '_' + e) || ''; }); });
    return o;
  };
  G.refraction = function (root) {
    var o = U.clone(vs.visit.exam.refraction || {}); o.final = {};
    ['OD', 'OS'].forEach(function (e) { o.final[e] = { sph: C.stepVal(root, 'rf_sph_' + e), cyl: C.stepVal(root, 'rf_cyl_' + e), axis: C.stepVal(root, 'rf_axis_' + e), add: C.stepVal(root, 'rf_add_' + e) || 0 }; });
    o.pd = C.stepVal(root, 'rf_pd'); return o;
  };
  G.iop = function (root) { return { method: C.segVal(root, 'iop_method') || 'NCT', OD: C.stepVal(root, 'iop_OD'), OS: C.stepVal(root, 'iop_OS'), time: K.clock.now() }; };
  var gStruct = function (key, opts) { return function (root) { var o = { OD: {}, OS: {} }; ['OD', 'OS'].forEach(function (e) { Object.keys(opts).forEach(function (k) { o[e][k] = C.fieldVal(root, key + '_' + k + '_' + e) || ''; }); }); return o; }; };
  G.anterior = gStruct('ant', ANT);
  G.posterior = function (root) { var o = gStruct('post', POST)(root); o.OD.cdr = o.OD.cdr ? Number(o.OD.cdr) : ''; o.OS.cdr = o.OS.cdr ? Number(o.OS.cdr) : ''; return o; };
  G.investigations = function (root) {
    var o = { ordered: [], results: {} };
    ['OCT', 'VF', 'BIO', 'FUN'].forEach(function (t) { var c = root.querySelector('[data-field=inv_' + t + ']'); if (c && c.checked) o.ordered.push(t); });
    ['cmt', 'rnfl', 'md', 'al'].forEach(function (r) { o.results[r] = { OD: C.fieldVal(root, 'res_' + r + '_OD') || '', OS: C.fieldVal(root, 'res_' + r + '_OS') || '' }; });
    return o;
  };

  function validate(section, data) {
    if (section === 'refraction') {
      var issues = [];
      ['OD', 'OS'].forEach(function (e) { var f = data.final[e]; if (Math.abs(f.sph || 0) > 20) issues.push(e + ' sphere ' + U.dio(f.sph)); if (Math.abs(f.cyl || 0) > 6) issues.push(e + ' cylinder ' + U.dio(f.cyl)); if (f.cyl && !f.axis) issues.push(e + ' axis missing'); });
      return issues;
    }
    return [];
  }
  function saveNow(silent) {
    var root = document.getElementById('exam-form'); if (!root || !G[vs.tab] || locked()) return Promise.resolve();
    clearTimeout(vs.saveTimer);
    var data = G[vs.tab](root), sec = vs.tab;
    var issues = validate(sec, data);
    var go = function () {
      var ind = document.getElementById('save-ind'); if (ind) ind.textContent = 'Saving…';
      return K.data.saveExamSection(vs.id, sec, data).then(function (v) { vs.visit = Object.assign(v, { role: vs.visit.role, signer: vs.visit.signer }); vs.dirty = false; var i2 = document.getElementById('save-ind'); if (i2) i2.textContent = 'Saved ' + U.time(K.clock.now()); });
    };
    if (issues.length && !silent) return K.ui.confirm('Check these values', 'Out of range or incomplete: ' + issues.join(', ') + '. Save anyway?', 'Save').then(function (ok) { if (ok) return go(); });
    return go();
  }
  function scheduleSave() { vs.dirty = true; var ind = document.getElementById('save-ind'); if (ind) ind.textContent = 'Unsaved changes'; clearTimeout(vs.saveTimer); vs.saveTimer = setTimeout(function () { saveNow(true).catch(K.ui.error); }, 900); }

  /* ---------------- Screen ---------------- */
  K.screens.visit = {
    title: function () { return 'Visit'; }, tab: 'home', noTabs: true,
    render: function (pr) {
      if (vs.id !== pr[0]) { vs.id = pr[0]; vs.tab = ['doctor'].indexOf(K.session.activeRole) >= 0 ? 'vision' : 'history'; }
      return Promise.all([K.data.getVisit(pr[0]), K.data.listUsers()]).then(function (r) {
        var v = r[0]; v.role = K.session.activeRole;
        var signer = r[1].filter(function (u) { return u.id === (v.rx && v.rx.signedBy); })[0]; v.signer = signer ? signer.name : '';
        vs.visit = v;
        return K.data.getPatientHistory(v.patientId).then(function (h) {
          vs.prev = h.visits.filter(function (x) { return x.id !== v.id && x.createdAt < v.createdAt && x.exam && (x.exam.vision || x.exam.refraction); })[0] || null;
          var ex = v.exam || {};
          var done = function (k) { return ex[k] && Object.keys(ex[k]).length ? ' <span class="done">✓</span>' : ''; };
          var tabs = '<div class="tabs">' + TABS.map(function (t) { return '<button data-act="tab" data-t="' + t[0] + '" class="' + (vs.tab === t[0] ? 'on' : '') + '">' + t[1] + (t[0] === 'plan' ? (v.rx && v.rx.signedAt ? ' <span class="done">✓</span>' : '') : done(t[0])) + '</button>'; }).join('') + '</div>';
          var lockNote = locked() ? '<div class="banner-info">Signed and locked ' + U.dateTime(v.signedAt) + '. Corrections are added as an addendum (CT-04-15). <button class="btn sm" data-act="addendum">Add addendum</button></div>' + (v.addenda.length ? '<div class="card small">' + v.addenda.map(function (a) { return '<b>Addendum ' + U.dateTime(a.ts) + '</b> (' + esc(a.reason) + '): ' + esc(a.text); }).join('<br>') + '</div>' : '') : '';
          var bar = actionBar(v);
          return C.banner(v.patient, v) + '<div class="row between small" style="margin:-4px 2px 8px"><span>' + C.stagePill(v.stage) + ' ' + esc(U.cap(v.type)) + ' · ' + esc(v.doctor ? v.doctor.name : '') + '</span><span id="save-ind" class="muted">' + (locked() ? '' : 'Autosave on') + '</span></div>' +
            lockNote + tabs + '<div id="exam-form" class="' + (locked() && vs.tab !== 'plan' ? 'locked' : '') + '">' + R[vs.tab](ex) + '</div>' + bar;
        });
      });
    },
    mount: function (root) {
      var form = root.querySelector('#exam-form'); if (!form || locked()) return;
      ['stepchange', 'segchange', 'change'].forEach(function (evn) { form.addEventListener(evn, function () { if (vs.tab !== 'plan') scheduleSave(); }); });
      form.addEventListener('input', function (e) { if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') scheduleSave(); });
    },
    actions: {
      tab: function (el) { var t = el.getAttribute('data-t'); var go = function () { vs.tab = t; K.refresh(false); }; if (vs.dirty) return saveNow().then(go); go(); },
      complaint: function (el) { el.classList.toggle('on'); scheduleSave(); },
      copyEye: function () {
        var root = document.getElementById('exam-form');
        Array.prototype.forEach.call(root.querySelectorAll('[data-step$="_OD"]'), function (s) { var id = s.getAttribute('data-step').replace(/_OD$/, '_OS'); C.setStep(root, id, s.getAttribute('data-v'), 'copied'); });
        Array.prototype.forEach.call(root.querySelectorAll('[data-field$="_OD"]'), function (s) { var t = root.querySelector('[data-field="' + s.getAttribute('data-field').replace(/_OD$/, '_OS') + '"]'); if (t) { t.value = s.value; t.style.outline = '2px dashed var(--info)'; } });
        K.ui.toast('Copied OD values to OS — highlighted until you change them'); scheduleSave();
      },
      sameLast: function () {
        if (!vs.prev) return; var root = document.getElementById('exam-form'), pe = vs.prev.exam;
        if (vs.tab === 'refraction' && pe.refraction && pe.refraction.final) ['OD', 'OS'].forEach(function (e) { var f = pe.refraction.final[e]; C.setStep(root, 'rf_sph_' + e, f.sph, 'copied'); C.setStep(root, 'rf_cyl_' + e, f.cyl, 'copied'); C.setStep(root, 'rf_axis_' + e, f.axis, 'copied'); C.setStep(root, 'rf_add_' + e, f.add, 'copied'); });
        if (vs.tab === 'vision' && pe.vision) ['OD', 'OS'].forEach(function (e) { ['ua', 'ph', 'bcva', 'near'].forEach(function (k) { var s = root.querySelector('[data-field=va_' + k + '_' + e + ']'); if (s && pe.vision[k]) s.value = pe.vision[k][e] || ''; }); });
        K.ui.toast('Filled from ' + U.date(vs.prev.createdAt) + ' — check each value'); scheduleSave();
      },
      sameHistory: function () { var h = (vs.prev && vs.prev.exam.history) || {}; h = U.clone(h); h.confirmed = K.clock.now(); h.notes = (h.notes ? h.notes + ' ' : '') + '[No change since ' + U.date(vs.prev.createdAt) + ']'; return K.data.saveExamSection(vs.id, 'history', h).then(function () { K.ui.toast('History confirmed as unchanged'); K.refresh(); }); },
      transpose: function () {
        var root = document.getElementById('exam-form');
        ['OD', 'OS'].forEach(function (e) { var s = C.stepVal(root, 'rf_sph_' + e) || 0, c = C.stepVal(root, 'rf_cyl_' + e) || 0, a = C.stepVal(root, 'rf_axis_' + e) || 90; if (!c) return; C.setStep(root, 'rf_sph_' + e, s + c); C.setStep(root, 'rf_cyl_' + e, -c); C.setStep(root, 'rf_axis_' + e, a > 90 ? a - 90 : a + 90); });
        K.ui.toast('Transposed between plus and minus cylinder'); scheduleSave();
      },
      device: function (el) {
        var d = el.getAttribute('data-d'); var name = { autorefractor: 'auto-refractor', nct: 'non-contact tonometer', lensmeter: 'lensmeter' }[d];
        var go = vs.dirty ? saveNow(true) : Promise.resolve();
        K.ui.toast('Waiting for ' + name + ' via device bridge…', 1500);
        return go.then(function () { return K.data.importDeviceData(vs.id, d); }).then(function () { K.native.vibrate(); K.ui.toast('Imported from ' + name); K.refresh(); });
      },
      confirmDevice: function (el) { var root = document.getElementById('exam-form'); var data = G[vs.tab](root); data._confirmed = true; return K.data.saveExamSection(vs.id, el.getAttribute('data-s'), data).then(function () { K.ui.toast('Device values confirmed'); K.refresh(); }); },
      allNormal: function (el) {
        var root = document.getElementById('exam-form'), key = el.getAttribute('data-k'), opts = key === 'ant' ? ANT : POST;
        ['OD', 'OS'].forEach(function (e) { Object.keys(opts).forEach(function (k) { var s = root.querySelector('[data-field="' + key + '_' + k + '_' + e + '"]'); if (s && !s.value) s.value = k === 'cdr' ? '0.3' : opts[k][0]; }); });
        K.ui.toast('Empty fields set to normal'); scheduleSave();
      },
      photo: function () { K.ui.toast('Camera / file picker opens in the production build. Demo: image attached.'); },
      dilate: function () {
        var s = K.session.settings;
        K.ui.sheet('Start dilation', '<label class="f">Drops</label><select class="input" id="dl-d"><option>Tropicamide + phenylephrine</option><option>Tropicamide 1%</option><option>Cyclopentolate 1% (cycloplegic)</option></select>' +
          '<label class="f">Timer (minutes)</label><input class="input" id="dl-m" type="number" value="' + s.dilationMinutes + '">' +
          '<p class="small muted">The doctor and optometrist get an alert when the patient is ready (CT-03-06). Use DEMO → fast-forward to skip the wait.</p><button class="btn block" data-sact="go">Instil drops and start timer</button>', {
          go: function () { return saveNow(true).then(function () { return K.data.startDilation(vs.id, document.getElementById('dl-d').value, Number(document.getElementById('dl-m').value)); }).then(function () { K.ui.closeSheet(); K.ui.toast('Dilation timer started'); K.go(K.homeRoute()); }); } });
      },
      toDoctor: function () { return saveNow().then(function () { return K.data.moveVisit(vs.id, 'doctor', 'Work-up complete'); }).then(function () { K.ui.toast('Sent to doctor’s queue'); K.go(K.homeRoute()); }); },
      openRx: function () { return saveNow(true).then(function () { K.go('rx/' + vs.id); }); },
      countersign: function () { K.go('rx/' + vs.id); },
      printRx: function () { K.go('rxview/' + vs.id); },
      callIn: function () { return K.data.moveVisit(vs.id, K.session.activeRole === 'doctor' ? 'doctor' : 'workup', 'Called in').then(function () { K.refresh(); }); },
      addendum: function () {
        K.ui.sheet('Addendum', '<label class="f">Reason (required)</label><select class="input" id="ad-r"><option>Correction of a value</option><option>Additional finding</option><option>Late entry</option></select><label class="f">Text</label><textarea class="input" id="ad-t"></textarea><button class="btn block" style="margin-top:12px" data-sact="go">Add addendum</button>', {
          go: function () { return K.data.addAddendum(vs.id, document.getElementById('ad-t').value, document.getElementById('ad-r').value).then(function () { K.ui.closeSheet(); K.ui.toast('Addendum added; original kept'); K.refresh(); }); } });
      }
    }
  };

  function actionBar(v) {
    var r = K.session.activeRole, b = [];
    if (locked()) return '';
    if (r === 'optometrist' || (r === 'doctor' && ['arrived', 'workup'].indexOf(v.stage) >= 0)) {
      if (['arrived', 'workup', 'doctor'].indexOf(v.stage) >= 0) b.push('<button class="btn secondary" data-act="dilate">Start dilation</button>');
      if (['arrived', 'workup', 'dilating'].indexOf(v.stage) >= 0) b.push('<button class="btn" data-act="toDoctor">Send to doctor</button>');
    }
    if (r === 'doctor' && ['doctor', 'dilating', 'investigations'].indexOf(v.stage) >= 0) {
      if (v.stage === 'doctor' && !(v.dilation && !v.dilation.done) && !v.exam.posterior) b.push('<button class="btn secondary" data-act="dilate">Dilate</button>');
      b.push('<button class="btn" data-act="openRx">Diagnosis + Rx</button>');
    }
    return b.length ? '<div class="btn-row sticky-actions">' + b.join('') + '</div>' : '';
  }
})();
