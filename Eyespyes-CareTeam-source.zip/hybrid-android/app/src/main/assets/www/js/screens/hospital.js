/* Hospital modules: IPD (Epic 10), OT & surgery (Epic 11), counselling & consent (Epic 6) */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var gate = function (f, name) { return K.has(f) ? null : '<div class="empty"><b>' + esc(name) + ' is part of the ' + (f === 'counselling' ? 'Clinic' : 'Hospital') + ' plan</b><div class="small">Current plan: ' + esc(K.session.plan) + '. Switch plans in the Demo centre to try it.</div></div>'; };

  /* ================= IPD: ward board ================= */
  K.screens.ward = {
    title: 'Ward board', tab: 'home', root: true, live: true,
    render: function () {
      var g = gate('ipd', 'IPD'); if (g) return Promise.resolve(g);
      return K.data.listBeds().then(function (beds) {
        var wards = {}; beds.forEach(function (b) { (wards[b.ward] = wards[b.ward] || []).push(b); });
        var occ = beds.filter(function (b) { return b.status === 'occupied'; }).length;
        var free = beds.filter(function (b) { return b.status === 'free'; }).length, cln = beds.filter(function (b) { return b.status === 'cleaning'; }).length;
        return C.onboard() + C.hero(occ + ' of ' + beds.length + ' beds occupied', [[occ, 'Occupied'], [free, 'Free'], [cln, 'Cleaning']]) +
          Object.keys(wards).map(function (w) {
            return '<div class="h2">' + esc(w) + '</div><div class="beds">' + wards[w].map(function (b) {
              var p = b.patient;
              return '<div class="bed ' + b.status + '" data-act="bed" data-id="' + b.id + '"><b>' + esc(b.label) + '</b>' + (p ? esc(p.name) + '<div class="muted">' + (b.admission.status === 'admitted' ? 'Since ' + U.time(b.admission.admittedAt) : '') + '</div>' : '<span class="muted">' + esc(U.cap(b.status)) + '</span>') + '</div>';
            }).join('') + '</div>';
          }).join('') + '<p class="small muted">Tap an occupied bed for orders, nursing chart and medication record; a free bed to admit.</p>';
      });
    },
    actions: {
      bed: function (el) {
        return K.data.listBeds().then(function (beds) {
          var b = beds.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0];
          if (b.status === 'occupied') { K.go('admission/' + b.admissionId); return; }
          if (b.status !== 'free') return K.ui.confirm('Bed ' + b.label, 'Bed is ' + b.status + '. Mark it free?', 'Mark free').then(function (ok) { if (ok) return K.data.setBedStatus(b.id, 'free'); });
          return Promise.all([K.data.listPackages(), K.data.listUsers('doctor')]).then(function (r) {
            K.ui.sheet('Admit to ' + b.label, '<label class="f">Patient</label><div class="row"><input class="input grow" id="ad-q" placeholder="Name or mobile"><button class="btn secondary sm" data-sact="find">Find</button></div><div id="ad-p" class="small muted"></div>' +
              '<label class="f">Package</label><select class="input" id="ad-pk">' + r[0].map(function (p) { return '<option value="' + p.id + '">' + esc(p.name) + ' — ' + U.inr(p.price) + '</option>'; }).join('') + '</select>' +
              '<label class="f">Surgeon</label><select class="input" id="ad-s">' + r[1].map(function (d) { return '<option value="' + d.id + '">' + esc(d.name) + '</option>'; }).join('') + '</select>' +
              '<label class="f">Deposit (₹)</label><input class="input" id="ad-d" inputmode="numeric" value="10000"><button class="btn block" style="margin-top:12px" data-sact="go">Admit</button>', {
              find: function () { return K.data.searchPatients(document.getElementById('ad-q').value).then(function (l) { var t = document.getElementById('ad-p'); if (!l.length) { t.textContent = 'No match'; return; } t.setAttribute('data-id', l[0].id); t.textContent = 'Selected: ' + l[0].name + ' (' + l[0].uhid + ')'; }); },
              go: function () { var pid = document.getElementById('ad-p').getAttribute('data-id'); if (!pid) { K.ui.toast('Find the patient first'); return; } return K.data.admit({ patientId: pid, bedId: b.id, packageId: document.getElementById('ad-pk').value, surgeonId: document.getElementById('ad-s').value, deposit: document.getElementById('ad-d').value }).then(function (a) { K.ui.closeSheet(); K.ui.toast('Admitted to ' + b.label); K.go('admission/' + a.id); }); }
            });
          });
        });
      }
    }
  };

  K.screens.admission = {
    title: 'Admission', tab: 'home', noTabs: true,
    render: function (pr) {
      return K.data.getAdmission(pr[0]).then(function (a) {
        var hhmm = function () { var d = new Date(K.clock.now()); return U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()); }, now = hhmm();
        var drugOrders = a.orders.filter(function (o) { return o.type === 'drug'; });
        return C.banner(a.patient) + '<div class="card"><div class="row between"><b>Bed ' + esc(a.bed.label) + ' · ' + esc(a.bed.ward) + '</b>' + C.pill(a.status, a.status === 'admitted' ? 'brand' : 'ok') + '</div>' +
          '<div class="small">Surgeon ' + esc(a.surgeon.name) + ' · ' + esc(a.pkg ? a.pkg.name + ' (' + U.inr(a.pkg.price) + ')' : 'No package') + '</div><div class="small muted">Admitted ' + U.dateTime(a.admittedAt) + ' · deposit ' + U.inr(a.deposit) + '</div>' +
          (a.otCases.length ? '<div class="small" style="margin-top:4px">' + a.otCases.map(function (c) { return esc(c.procedure) + ' ' + c.eye + ' — ' + C.pill(K.OT_STATUS[c.status], c.status === 'completed' ? 'ok' : 'info'); }).join('<br>') + '</div>' : '') + '</div>' +
          '<div class="h2">Medication administration</div>' + (drugOrders.length ? drugOrders.map(function (o) {
            return '<div class="card"><b class="small">' + esc(o.text) + '</b><div class="row wrap" style="margin-top:6px">' + o.times.map(function (t) {
              var rec = a.mar.filter(function (m) { return m.orderId === o.id && m.time === t; })[0];
              var cls = rec ? (rec.status === 'given' ? 'pill-ok' : 'pill-crit') : t < now ? 'pill-warn' : '';
              return '<button class="chip ' + cls + '" data-act="dose" data-o="' + o.id + '" data-t="' + t + '"' + (rec || a.status !== 'admitted' ? ' disabled' : '') + '>' + t + (rec ? (rec.status === 'given' ? ' ✓' : ' ✕') : t < now ? ' due' : '') + '</button>';
            }).join('') + '</div></div>';
          }).join('') : C.empty('No drug orders')) +
          '<div class="h2">Other orders</div><div class="list">' + a.orders.filter(function (o) { return o.type !== 'drug'; }).map(function (o) { return '<div class="li">' + esc(o.text) + '</div>'; }).join('') + '</div>' +
          '<div class="h2 row between"><span>Nursing chart</span>' + (a.status === 'admitted' ? '<button class="btn secondary sm" data-act="nursing">' + K.icon('plus', 'sm') + 'Entry</button>' : '') + '</div>' +
          (a.nursing.length ? '<div class="list">' + a.nursing.map(function (n) { return '<div class="li"><div class="grow"><div class="small muted">' + U.dateTime(n.ts) + '</div>BP ' + esc(n.bp || '—') + ' · Pulse ' + esc(n.pulse || '—') + ' · Sugar ' + esc(n.sugar || '—') + ' · Pain ' + esc(n.pain === undefined ? '—' : n.pain) + '/10<div>' + esc(n.note || '') + '</div></div></div>'; }).join('') + '</div>' : C.empty('No entries')) +
          (a.status === 'admitted' ? '<div class="btn-row" style="margin-top:12px"><button class="btn" data-act="discharge">Discharge</button></div>' : '<div class="banner-info" style="margin-top:12px">Discharged ' + U.dateTime(a.discharge.ts) + '<div class="small">' + esc(a.discharge.summary) + '</div></div>');
      });
    },
    actions: {
      dose: function (el, ev, pr) {
        var o = el.getAttribute('data-o'), t = el.getAttribute('data-t');
        K.ui.sheet('Dose at ' + t, '<p>Record for this scheduled dose (CT-10-06). The eye is part of the order.</p><div class="btn-row"><button class="btn ok" data-sact="g">Given</button><button class="btn danger" data-sact="m">Not given</button></div>', {
          g: function () { return K.data.recordDose(pr[0], o, t, 'given').then(function () { K.ui.closeSheet(); K.refresh(); }); },
          m: function () { return K.ui.prompt('Not given', 'Reason', { options: ['Patient asleep', 'Patient refused', 'Drug unavailable', 'Held by doctor'] }).then(function (r) { if (r) return K.data.recordDose(pr[0], o, t, 'missed', r).then(function () { K.refresh(); }); }); }
        });
      },
      nursing: function (el, ev, pr) {
        K.ui.sheet('Nursing entry', '<div class="grid2"><div><label class="f">BP</label><input class="input" id="n-bp" placeholder="120/80"></div><div><label class="f">Pulse</label><input class="input" id="n-p" inputmode="numeric"></div><div><label class="f">Blood sugar</label><input class="input" id="n-s" inputmode="numeric" placeholder="mg/dL"></div><div><label class="f">Pain (0–10)</label><input class="input" id="n-pain" inputmode="numeric"></div></div>' +
          '<label class="f">Eye pad / shield</label><select class="input" id="n-eye"><option>Pad on</option><option>Shield on</option><option>Open</option></select><label class="f">Note</label><textarea class="input" id="n-note"></textarea><button class="btn block" style="margin-top:12px" data-sact="ok">Save</button>', {
          ok: function () { return K.data.addNursingEntry(pr[0], { bp: v('n-bp'), pulse: v('n-p'), sugar: v('n-s'), pain: v('n-pain'), eye: v('n-eye'), note: v('n-note') }).then(function () { K.ui.closeSheet(); K.refresh(); }); } });
        function v(id) { return document.getElementById(id).value; }
      },
      discharge: function (el, ev, pr) {
        return K.data.getAdmission(pr[0]).then(function (a) {
          var c = a.otCases[0];
          var draft = 'Admitted ' + U.dateTime(a.admittedAt) + ' for ' + (c ? c.procedure + ' ' + c.eye : 'observation') + '. ' + (c && c.status === 'completed' ? 'Surgery uneventful' + (c.iolImplanted ? '; IOL ' + c.iolImplanted.model + ' ' + c.iolImplanted.power.toFixed(1) + ' D (' + c.iolImplanted.serial + ')' : '') + '. ' : '') +
            'Discharge medicines: ' + a.orders.filter(function (o) { return o.type === 'drug'; }).map(function (o) { return o.text; }).join('; ') + '. Review tomorrow.';
          K.ui.sheet('Discharge summary', '<p class="small muted">Auto-drafted from admission, OT notes and orders; edit and sign (CT-10-08). Discharge medicines become the patient’s drop schedule.</p><textarea class="input" id="ds-t" style="min-height:160px">' + esc(draft) + '</textarea><button class="btn block" style="margin-top:12px" data-sact="ok">Sign and discharge</button>', {
            ok: function () { return K.data.discharge(pr[0], document.getElementById('ds-t').value).then(function () { K.ui.closeSheet(); K.ui.toast('Discharged; bed set to cleaning; review booked'); K.refresh(); }); } });
        });
      }
    }
  };

  /* ================= OT ================= */
  var otDay = 0;
  K.screens.ot = {
    title: 'OT board', tab: 'home', root: true, live: true,
    render: function () {
      var g = gate('ot', 'OT & surgery'); if (g) return Promise.resolve(g);
      var day = U.isoDay(K.clock.now() + otDay * 86400000);
      return K.data.listOTCases(day).then(function (list) {
        var th = {}; list.forEach(function (c) { (th[c.theatre] = th[c.theatre] || []).push(c); });
        return '<div class="chips">' + [['0', 'Today'], ['1', 'Tomorrow'], ['2', U.date(K.clock.now() + 2 * 86400000)]].map(function (d) { return '<button class="chip ' + (String(otDay) === d[0] ? 'on' : '') + '" data-act="day" data-d="' + d[0] + '">' + d[1] + '</button>'; }).join('') + '</div>' +
          (list.length ? Object.keys(th).sort().map(function (t) {
            return '<div class="h2">' + esc(t) + '</div>' + th[t].map(function (c) {
              return '<div class="card tap" data-act="case" data-id="' + c.id + '"><div class="row between"><b>' + U.time(c.ts) + ' · ' + esc(c.patient.name) + '</b>' + C.pill(K.OT_STATUS[c.status], c.status === 'completed' ? 'ok' : c.status === 'in_ot' ? 'crit' : c.status === 'preop_ready' ? 'info' : '') + '</div>' +
                '<div class="small">' + esc(c.procedure) + ' · <b>' + c.eye + '</b> · ' + esc(c.anaesthesia) + '</div><div class="small muted">' + esc(c.surgeon.name) + ' · IOL ' + esc(c.iolPlan.model) + ' ' + c.iolPlan.power.toFixed(1) + ' D</div></div>';
            }).join('');
          }).join('') : C.empty('No cases'));
      });
    },
    actions: { day: function (el) { otDay = Number(el.getAttribute('data-d')); K.refresh(); }, 'case': function (el) { K.go('otcase/' + el.getAttribute('data-id')); } }
  };

  var PRE = { consent: 'Consent signed', biometry: 'Biometry done', iolSelected: 'IOL selected', iolInStock: 'IOL in stock', fitness: 'Pre-op tests and fitness', eyeMarked: 'Operative eye marked', fasting: 'Fasting confirmed' };
  K.screens.otcase = {
    title: 'OT case', tab: 'home', noTabs: true,
    render: function (pr) {
      return Promise.all([K.data.getOTCase(pr[0]), K.data.listInventory('iol')]).then(function (r) {
        var c = r[0], iols = r[1].filter(function (i) { return i.qty > 0; }), ck = c.checklist;
        var right = iols.filter(function (i) { return i.model === c.iolPlan.model && Math.abs(i.power - c.iolPlan.power) < 0.01; })[0], wrong = iols.filter(function (i) { return i !== right && i.model === c.iolPlan.model; })[0];
        var step = function (done, title, body) { return '<div class="card' + (done ? '' : ' accent') + '"><div class="row between"><b>' + title + '</b>' + (done ? C.pill('Done', 'ok') : '') + '</div>' + body + '</div>'; };
        return C.banner(c.patient) + '<div class="card"><div class="row between"><b>' + esc(c.procedure) + '</b><span class="pill pill-crit" style="font-size:15px">' + c.eye + '</span></div>' +
          '<div class="small">' + esc(c.theatre) + ' · ' + U.dateTime(c.ts) + ' · ' + esc(c.surgeon.name) + ' · ' + esc(c.anaesthesia) + '</div><div class="small"><b>Planned IOL:</b> ' + esc(c.iolPlan.model) + ' ' + c.iolPlan.power.toFixed(1) + ' D</div>' +
          '<div style="margin-top:6px">' + C.pill(K.OT_STATUS[c.status], c.status === 'completed' ? 'ok' : 'brand') + '</div></div>' +
          step(Object.keys(ck.preop).every(function (k) { return ck.preop[k]; }), '1. Pre-op checklist', Object.keys(PRE).map(function (k) { return '<label class="check"><input type="checkbox" data-change="pre" data-k="' + k + '"' + (ck.preop[k] ? ' checked' : '') + (c.status === 'completed' ? ' disabled' : '') + '> ' + PRE[k] + '</label>'; }).join('')) +
          step(ck.signIn.done, '2. Sign-in (before anaesthesia)', ck.signIn.done ? '<div class="small muted">' + U.time(ck.signIn.ts) + (ck.signIn.override ? ' · override: ' + esc(ck.signIn.override) : '') + '</div>' : '<div class="btn-row"><button class="btn" data-act="signIn">Complete sign-in</button><button class="btn ghost" data-act="override">Surgeon override</button></div>') +
          step(ck.timeOut.done, '3. Time-out (before incision)', ck.timeOut.done ? '<div class="small muted">' + U.time(ck.timeOut.ts) + ' — patient, procedure, eye and IOL confirmed</div>' :
            '<p class="small">Read aloud and tick each (CT-11-03):</p><label class="check"><input type="checkbox" id="to-p"> Patient: ' + esc(c.patient.name) + ', ' + esc(c.patient.uhid) + '</label><label class="check"><input type="checkbox" id="to-pr"> Procedure: ' + esc(c.procedure) + '</label><label class="check"><input type="checkbox" id="to-e"> Eye: <b>' + c.eye + '</b></label><label class="check"><input type="checkbox" id="to-i"> IOL: ' + esc(c.iolPlan.model) + ' ' + c.iolPlan.power.toFixed(1) + ' D</label><button class="btn block" data-act="timeOut">Confirm time-out</button>') +
          step(!!c.iolImplanted, '4. IOL implant scan', c.iolImplanted ? '<div class="banner-info"><b>Matched:</b> ' + esc(c.iolImplanted.model) + ' ' + c.iolImplanted.power.toFixed(1) + ' D · ' + esc(c.iolImplanted.serial) + '</div>' :
            '<div class="row"><input class="input grow" id="iol-code" placeholder="Scan IOL box barcode"><button class="btn" data-act="scan">Scan</button></div><div class="small muted" style="margin-top:6px">Demo barcodes — tap to fill:</div><div class="row wrap">' +
            (right ? '<button class="chip" data-act="fill" data-c="' + esc(right.barcode) + '">' + esc(right.barcode) + ' (correct)</button>' : '<span class="small muted">No matching IOL in stock</span>') + (wrong ? '<button class="chip" data-act="fill" data-c="' + esc(wrong.barcode) + '">' + esc(wrong.barcode) + ' (wrong power)</button>' : '') + '</div><div id="iol-res"></div>') +
          step(ck.signOut.done, '5. Sign-out and notes', ck.signOut.done ? '<div class="small">' + esc(c.notes || '') + '<br>Complications: ' + esc(c.complications || 'None') + '</div>' :
            '<label class="f">Operative note</label><textarea class="input" id="so-n">' + esc(c.notes || 'Uneventful ' + c.procedure.toLowerCase() + '; IOL in the bag.') + '</textarea><label class="f">Complications</label><select class="input" id="so-c"><option>None</option><option>Posterior capsule rupture</option><option>Zonular dialysis</option><option>Iris prolapse</option><option>Other</option></select><button class="btn block" style="margin-top:10px" data-act="signOut">Complete sign-out</button>') +
          (c.status === 'recovery' ? '<button class="btn ok block" style="margin-top:10px" data-act="complete">Close case — shift to ward</button>' : '');
      });
    },
    actions: {
      pre: function (el, ev, pr) { var d = {}; d[el.getAttribute('data-k')] = el.checked; return K.data.updateOTChecklist(pr[0], 'preop', d).then(function () { K.refresh(); }); },
      signIn: function (el, ev, pr) { return K.data.updateOTChecklist(pr[0], 'signIn', {}).then(function () { K.ui.toast('Sign-in complete'); K.refresh(); }); },
      override: function (el, ev, pr) { return K.ui.prompt('Surgeon override', 'Reason (logged)', { required: true }).then(function (r) { if (r) return K.data.updateOTChecklist(pr[0], 'signIn', { override: r }).then(function () { K.refresh(); }); }); },
      timeOut: function (el, ev, pr) { var g = function (id) { return document.getElementById(id).checked; }; return K.data.updateOTChecklist(pr[0], 'timeOut', { patient: g('to-p'), procedure: g('to-pr'), eye: g('to-e'), iol: g('to-i') }).then(function () { K.ui.toast('Time-out confirmed'); K.refresh(); }); },
      fill: function (el) { document.getElementById('iol-code').value = el.getAttribute('data-c'); },
      scan: function (el, ev, pr) {
        return K.data.scanIOL(pr[0], document.getElementById('iol-code').value).then(function (r) {
          if (r.ok) { K.native.vibrate(); K.ui.toast('IOL matches the plan — added to implant log'); K.refresh(); return; }
          K.native.vibrate(300); document.getElementById('iol-res').innerHTML = '<div class="banner-note" style="background:var(--crit-soft);color:var(--crit);margin-top:8px"><b>STOP.</b> ' + esc(r.reason) + ' Saving is blocked until the surgeon confirms a change (CT-11-04).</div>';
        });
      },
      signOut: function (el, ev, pr) { return K.data.updateOTChecklist(pr[0], 'signOut', { complications: document.getElementById('so-c').value }).then(function () { return K.data.setOTStatus(pr[0], 'recovery', { notes: document.getElementById('so-n').value, complications: document.getElementById('so-c').value }); }).then(function () { K.refresh(); }); },
      complete: function (el, ev, pr) { return K.data.setOTStatus(pr[0], 'completed').then(function () { K.ui.toast('Case closed; post-op review booked'); K.refresh(); }); }
    }
  };

  /* ================= Counselling ================= */
  K.screens.counselling = {
    title: 'Counselling', tab: 'home', root: true, live: true,
    render: function () {
      var g = gate('counselling', 'Counselling'); if (g) return Promise.resolve(g);
      return K.data.listCounselling().then(function (list) {
        var open = list.filter(function (c) { return ['new', 'thinking'].indexOf(c.status) >= 0; }), closed = list.filter(function (c) { return ['new', 'thinking'].indexOf(c.status) < 0; });
        var row = function (c) { return '<div class="card tap" data-act="open" data-id="' + c.id + '"><div class="row between"><b>' + esc(c.patient.name) + '</b>' + C.pill(U.cap(c.status), c.status === 'booked' ? 'ok' : c.status === 'new' ? 'brand' : c.status === 'declined' ? 'crit' : 'warn') + '</div><div class="small">' + esc(c.procedure) + ' · <b>' + c.eye + '</b> · advised by ' + esc(c.doctor.name) + '</div><div class="small muted">' + esc(c.note) + ' · ' + U.ago(c.ts) + '</div></div>'; };
        return '<div class="h2">To counsel</div>' + (open.length ? open.map(row).join('') : C.empty('No one waiting')) + (closed.length ? '<div class="h2">Done</div>' + closed.map(row).join('') : '');
      });
    },
    actions: { open: function (el) { K.go('counsel/' + el.getAttribute('data-id')); } }
  };

  var cs = { pkg: null, sig: false };
  K.screens.counsel = {
    title: 'Counselling', tab: 'home', noTabs: true,
    render: function (pr) {
      return Promise.all([K.data.listCounselling(), K.data.listPackages()]).then(function (r) {
        var c = r[0].filter(function (x) { return x.id === pr[0]; })[0], pk = r[1];
        if (!cs.pkg || cs.id !== c.id) { cs = { id: c.id, pkg: c.packageId || 'pk2', sig: !!c.consent }; }
        var sel = pk.filter(function (p) { return p.id === cs.pkg; })[0];
        var d = new Date(K.clock.now() + 2 * 86400000); d.setHours(10, 0, 0, 0);
        return C.banner(c.patient) + '<div class="card"><b>' + esc(c.procedure) + ' — ' + c.eye + '</b><div class="small">' + esc(c.note) + ' · ' + esc(c.doctor.name) + '</div></div>' +
          '<div class="h2">Package comparison</div><p class="small muted">Turn the tablet towards the patient (CT-06-02). Prices are demo values.</p>' +
          pk.map(function (p) { return '<div class="card tap ' + (cs.pkg === p.id ? 'accent' : '') + '" data-act="pkg" data-id="' + p.id + '"><div class="row between"><b>' + esc(p.name) + '</b><b>' + U.inr(p.price) + '</b></div><div class="small">IOL: ' + esc(p.iol) + ' · ' + esc(p.notes) + '</div></div>'; }).join('') +
          '<div class="btn-row" style="margin-top:10px"><button class="btn secondary" data-act="estimate">Send estimate on WhatsApp</button></div>' +
          '<div class="h2">Informed consent</div><div class="card"><p class="small">I understand the nature, benefits and risks of ' + esc(c.procedure.toLowerCase()) + ' of my <b>' + (c.eye === 'OD' ? 'right' : c.eye === 'OS' ? 'left' : 'both') + ' eye</b>, including the IOL chosen (' + esc(sel ? sel.iol : '') + '), and I agree to the surgery. (Procedure-specific consent text in the patient’s language in production.)</p>' +
          (c.consent ? '<div class="banner-info">Signed ' + U.dateTime(c.consent.ts) + ' · witness ' + esc(c.consent.witness) + '</div>' : '<canvas id="sigpad" width="600" height="160" style="width:100%;height:120px;border:1px dashed var(--line);border-radius:8px;background:#fff;touch-action:none"></canvas><div class="row between"><span class="small muted">Patient / guardian signs above</span><button class="btn ghost sm" data-act="clearSig">Clear</button></div><label class="f">Witness</label><input class="input" id="wit" value="' + esc(K.session.user.name) + '"><button class="btn block" style="margin-top:8px" data-act="consent">Save consent</button>') + '</div>' +
          '<div class="h2">Outcome</div><div class="card"><label class="f">Surgery date and time</label><input class="input" type="datetime-local" id="sx-dt" value="' + U.isoDay(d.getTime()) + 'T10:00"><label class="f">Advance (₹)</label><input class="input" id="sx-adv" inputmode="numeric" value="5000">' +
          '<div class="btn-row" style="margin-top:10px"><button class="btn" data-act="book">Book surgery</button></div><div class="btn-row" style="margin-top:8px"><button class="btn ghost" data-act="thinking">Patient will think</button><button class="btn ghost" data-act="declined">Declined</button></div></div>';
      });
    },
    mount: function () {
      var cv = document.getElementById('sigpad'); if (!cv) return;
      var ctx = cv.getContext('2d'), drawing = false; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.strokeStyle = '#0C3B5E';
      var pos = function (e) { var r = cv.getBoundingClientRect(), t = e.touches ? e.touches[0] : e; return [(t.clientX - r.left) * cv.width / r.width, (t.clientY - r.top) * cv.height / r.height]; };
      var start = function (e) { drawing = true; var p = pos(e); ctx.beginPath(); ctx.moveTo(p[0], p[1]); e.preventDefault(); };
      var move = function (e) { if (!drawing) return; var p = pos(e); ctx.lineTo(p[0], p[1]); ctx.stroke(); cs.sig = true; e.preventDefault(); };
      var end = function () { drawing = false; };
      cv.addEventListener('mousedown', start); cv.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
      cv.addEventListener('touchstart', start, { passive: false }); cv.addEventListener('touchmove', move, { passive: false }); cv.addEventListener('touchend', end);
    },
    actions: {
      pkg: function (el) { cs.pkg = el.getAttribute('data-id'); K.refresh(); },
      estimate: function (el, ev, pr) { return K.data.listPackages().then(function (pk) { var p = pk.filter(function (x) { return x.id === cs.pkg; })[0]; return K.data.updateCounselling(pr[0], { packageId: p.id, estimate: p.price }); }).then(function () { K.ui.toast('Estimate sent on WhatsApp'); }); },
      clearSig: function () { var cv = document.getElementById('sigpad'); cv.getContext('2d').clearRect(0, 0, cv.width, cv.height); cs.sig = false; },
      consent: function (el, ev, pr) {
        if (!cs.sig) { K.ui.toast('Ask the patient to sign first'); return; }
        var img = document.getElementById('sigpad').toDataURL('image/png');
        return K.data.updateCounselling(pr[0], { packageId: cs.pkg, consent: { ts: K.clock.now(), witness: document.getElementById('wit').value, signature: img.length > 40000 ? img.slice(0, 64) + '…' : img } }).then(function () { K.ui.toast('Consent saved as PDF (demo)'); K.refresh(); });
      },
      book: function (el, ev, pr) {
        var ts = new Date(document.getElementById('sx-dt').value).getTime();
        return K.data.updateCounselling(pr[0], { packageId: cs.pkg, status: 'booked', surgeryTs: ts, advance: Number(document.getElementById('sx-adv').value) || 0 }).then(function () { K.ui.toast('Surgery booked; OT and patient notified'); K.go('counselling'); });
      },
      thinking: function (el, ev, pr) { return K.data.updateCounselling(pr[0], { status: 'thinking' }).then(function () { K.ui.toast('Saved; follow-up call added'); K.go('counselling'); }); },
      declined: function (el, ev, pr) { return K.ui.prompt('Declined', 'Reason', { options: ['Cost', 'Wants second opinion', 'Fear of surgery', 'Going elsewhere', 'Other'] }).then(function (r) { if (r) return K.data.updateCounselling(pr[0], { status: 'declined', reason: r }).then(function () { K.go('counselling'); }); }); }
    }
  };
})();
