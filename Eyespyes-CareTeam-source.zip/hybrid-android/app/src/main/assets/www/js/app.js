/* App bootstrap: choose the data service, restore session, build the shell (sidebar / bottom nav),
   global search palette and keyboard shortcuts, then start the router. */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc;

  /* ====== Configuration ======
     dataMode 'mock' : demo build, everything on device (MockDataService)
     dataMode 'api'  : real backend (ApiDataService) — set apiBase first   */
  K.config = { dataMode: 'mock', apiBase: 'https://api.example-eyespyes.invalid/v1', tickMs: 15000 };

  var impl = K.config.dataMode === 'api' ? K.ApiDataService : K.MockDataService;
  K.DataContract.verify(impl, K.config.dataMode);
  K.data = K.DataContract.instrument(impl);

  /* ---------- Shell ---------- */
  var NAV = [['home', 'Home', 'home'], ['patients', 'Patients', 'users'], ['calendar', 'Calendar', 'calendar'], ['inbox', 'Inbox', 'bell'], ['more', 'More', 'menu']];
  function buildShell() {
    document.getElementById('tabbar').innerHTML = NAV.map(function (n) {
      return '<button data-tab="' + n[0] + '" aria-label="' + n[1] + '"><span class="tic">' + K.icon(n[2]) + '</span><span>' + n[1] + '</span>' + (n[0] === 'inbox' ? '<b class="badge inbox-badge" hidden>0</b>' : '') + '</button>';
    }).join('');
    var s = K.session;
    document.getElementById('sidebar').innerHTML = '<div class="logo-wrap"><img class="logo-mark" src="' + K.BRAND.MARK + '" alt="Eyespyes"><span class="logo-word"><img class="logo-full" src="' + K.BRAND.LOGO + '" alt="Eyespyes"><span class="care-team">Care Team</span></span></div>' +
      '<nav>' + NAV.map(function (n) { return '<button class="nav-btn" data-tab="' + n[0] + '" aria-label="' + n[1] + '">' + K.icon(n[2]) + '<span>' + n[1] + '</span>' + (n[0] === 'inbox' ? '<b class="badge inbox-badge" hidden>0</b>' : '') + '</button>'; }).join('') + '</nav>' +
      '<div class="side-foot"><button class="nav-btn" data-go="demo">' + K.icon('sparkle') + '<span>Demo centre</span></button>' +
      (s ? '<div class="side-user">' + K.c.avatar(s.user.name) + '<div class="who"><b>' + esc(s.user.name) + '</b><span>' + esc(K.ROLES[s.activeRole]) + ' · ' + esc(s.branch ? s.branch.name : '') + '</span></div></div>' : '') + '</div>';
    document.getElementById('btn-back').innerHTML = K.icon('back');
    document.getElementById('top-logo').src = K.BRAND.MARK;
    document.getElementById('favicon').href = K.BRAND.ICON;
    document.getElementById('btn-search').innerHTML = K.icon('search');
    document.getElementById('btn-demo').innerHTML = K.icon('sparkle', 'sm') + '<span>Demo</span>';
    document.getElementById('searchbox').innerHTML = K.icon('search', 'sm') + '<span>Search patients, UHID, actions</span><kbd>/</kbd>';
    K.updateChrome();
  }

  K.reloadSession = function () {
    return K.data.getSession().then(function (s) { K.session = s; buildShell(); return s; });
  };
  K.afterLogin = function () { return K.reloadSession().then(function () { K.ui.ok('Welcome, ' + K.firstName(K.session.user.name)); K.go('home', true); }); };

  K.updateChrome = function () {
    if (!K.session) return;
    Promise.all([K.data.listNotifications(), K.data.getSyncState()]).then(function (r) {
      var unread = r[0].filter(function (n) { return !n.read; }).length;
      Array.prototype.forEach.call(document.querySelectorAll('.inbox-badge'), function (b) { b.hidden = !unread; b.textContent = unread > 9 ? '9+' : unread; });
      var pill = document.getElementById('net-pill'); pill.hidden = r[1].online;
      pill.innerHTML = K.icon('wifioff', 'sm') + ' Offline · ' + r[1].pending.length + ' to sync';
    }).catch(function () { /* ignore */ });
  };

  /* ---------- Global search palette ("/" on web, search icon on phone) ---------- */
  var pal = document.getElementById('palette'), palSel = 0, palItems = [], palT;
  var ACTIONS = [['Register a new patient', 'plus', 'register'], ['Check in a patient', 'checkc', 'patients/checkin'], ['Queue board', 'kanban', 'queue'], ['Calendar', 'calendar', 'calendar'],
    ['Book appointment', 'calendar', '__book'], ['Inbox and alerts', 'bell', 'inbox'], ['Reports', 'file', 'reports'], ['Stock', 'box', 'stock'], ['Demo centre', 'sparkle', 'demo'], ['Settings', 'sliders', 'settings']];
  K.openPalette = function () {
    if (!K.session) return;
    pal.innerHTML = '<div class="pbox"><div class="pin">' + K.icon('search') + '<input id="pal-q" placeholder="Search name, mobile, UHID, ABHA or an action" autocomplete="off"><button class="icon-btn" data-pal="close" aria-label="Close">' + K.icon('x') + '</button></div><div class="pres" id="pal-res"></div></div>';
    pal.hidden = false; palDraw('');
    var q = document.getElementById('pal-q'); q.focus();
    q.addEventListener('input', function () { clearTimeout(palT); palT = setTimeout(function () { palDraw(q.value); }, 120); });
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { palSel = Math.min(palItems.length - 1, palSel + 1); mark(); e.preventDefault(); }
      if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); mark(); e.preventDefault(); }
      if (e.key === 'Enter' && palItems[palSel]) { pick(palItems[palSel]); }
    });
  };
  function closePalette() { pal.hidden = true; pal.innerHTML = ''; }
  function mark() { Array.prototype.forEach.call(pal.querySelectorAll('.pit'), function (x, i) { x.classList.toggle('sel', i === palSel); if (i === palSel) x.scrollIntoView({ block: 'nearest' }); }); }
  function pick(it) { closePalette(); if (it.go === '__book') return K.bookSheet(null); if (it.pid) return K.go('patient/' + it.pid); K.go(it.go); }
  function palDraw(q) {
    q = q.trim().toLowerCase();
    K.data.searchPatients(q).then(function (pts) {
      var acts = ACTIONS.filter(function (a) { return !q || a[0].toLowerCase().indexOf(q) >= 0; });
      palItems = pts.slice(0, 8).map(function (p) { return { pid: p.id, p: p }; }).concat(acts.map(function (a) { return { go: a[2], a: a }; }));
      palSel = 0;
      var html = '';
      if (pts.length) html += '<div class="pgrp">' + (q ? 'Patients' : 'Recent patients') + '</div>' + pts.slice(0, 8).map(function (p, i) {
        return '<div class="pit" data-i="' + i + '">' + K.c.avatar(p.name) + '<div class="grow"><b>' + esc(p.name) + '</b><div class="small muted">' + K.c.ageSex(p) + ' · ' + esc(p.uhid) + ' · ' + esc(p.phone) + '</div></div>' + K.icon('chev', 'sm') + '</div>';
      }).join('');
      if (acts.length) html += '<div class="pgrp">Actions</div>' + acts.map(function (a, j) { return '<div class="pit" data-i="' + (Math.min(pts.length, 8) + j) + '"><span class="li" style="padding:0;border:0;min-height:0"><span class="lic">' + K.icon(a[1]) + '</span></span><b class="grow">' + esc(a[0]) + '</b></div>'; }).join('');
      document.getElementById('pal-res').innerHTML = html || K.c.empty('Nothing found', 'Try a mobile number or UHID', 'search');
      mark();
    });
  }
  pal.addEventListener('click', function (e) {
    if (e.target === pal || e.target.closest('[data-pal=close]')) { closePalette(); return; }
    var it = e.target.closest('.pit'); if (it) pick(palItems[Number(it.getAttribute('data-i'))]);
  });

  /* ---------- Chrome wiring ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('#tabbar [data-tab], #sidebar [data-tab]');
    if (b) { var t = b.getAttribute('data-tab'); K.go(t === 'home' ? K.homeRoute() : t); return; }
    var g = e.target.closest('#sidebar [data-go]'); if (g) K.go(g.getAttribute('data-go'));
  });
  document.getElementById('btn-back').addEventListener('click', function () { K.back(); });
  document.getElementById('btn-search').addEventListener('click', K.openPalette);
  document.getElementById('searchbox').addEventListener('click', K.openPalette);
  document.getElementById('btn-demo').addEventListener('click', function () { if (K.session) K.go('demo'); else K.ui.toast('Sign in with any role first, then open the Demo centre'); });
  document.addEventListener('keydown', function (e) {
    var typing = /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '');
    if (e.key === 'Escape') { if (!pal.hidden) closePalette(); else K.ui.closeSheet(); }
    if (e.key === '/' && !typing && pal.hidden) { e.preventDefault(); K.openPalette(); }
    if ((e.key === 'Enter' || e.key === ' ') && !typing && document.activeElement && document.activeElement.matches('.kpi[data-act]')) { e.preventDefault(); document.activeElement.click(); }
  });

  /* Android hardware back also closes the search palette */
  var routerBack = K.onBack;
  K.onBack = function () { if (!pal.hidden) { closePalette(); return true; } return routerBack(); };

  /* Live updates */
  K.bus.on('data', function (what) {
    if (what === 'session' || what === 'plan' || what === 'reset') K.data.getSession().then(function (s) { K.session = s; buildShell(); });
    K.updateChrome();
  });
  K.bus.on('notify', function (n) {
    if (K.session && n.roles && n.roles.indexOf(K.session.activeRole) >= 0) { K.ui.toast(n.title, 3200); K.native.vibrate(40); }
  });
  setInterval(function () { if (K.data.demo) K.data.demo.tick(); K.bus.emit('tick'); }, K.config.tickMs);

  /* Preferences */
  try {
    if (localStorage.getItem('eyespyes.dark') === '1') document.body.classList.add('dark');
    var fs = localStorage.getItem('eyespyes.fs'); if (fs) { document.documentElement.style.fontSize = fs + 'px'; document.body.style.fontSize = fs + 'px'; }
  } catch (e) { /* ignore */ }

  window.addEventListener('error', function (e) { console.error('[app error]', e.message); });

  K.reloadSession().then(function () { K.startRouter(); });
})();
