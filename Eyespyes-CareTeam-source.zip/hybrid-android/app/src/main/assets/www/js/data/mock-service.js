/* ============================================================================
   MOCK DATA SERVICE — demo implementation of K.DataContract.
   Keeps everything on the device (localStorage), simulates latency, offline
   queueing, WhatsApp delivery, device imports and payment callbacks.
   The DBMS team replaces this with api-service.js; business rules marked
   [SERVER RULE] must be enforced by the real backend too.
   ========================================================================== */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util;
  var KEY = 'eyespyes.demo.db.v3', SKEY = 'eyespyes.demo.session.v3';
  var db, session, saveTimer;

  /* ---------------- storage ---------------- */
  function load() {
    try { db = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { db = null; }
    if (db && db.meta && db.meta.clockOffset) K.clock.offsetMs = db.meta.clockOffset;
    if (!db || !db.meta || db.meta.version !== 3 || db.meta.seededDay !== U.isoDay(Date.now())) { K.clock.offsetMs = 0; db = K.seed(); save(true); }
    try { session = JSON.parse(localStorage.getItem(SKEY) || 'null'); } catch (e) { session = null; }
  }
  function save(now) {
    db.meta.clockOffset = K.clock.offsetMs;
    clearTimeout(saveTimer);
    var doIt = function () { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { console.warn('save failed', e); } };
    if (now) doIt(); else saveTimer = setTimeout(doIt, 250);
  }
  function saveSession() { try { localStorage.setItem(SKEY, JSON.stringify(session)); } catch (e) { /* ignore */ } }
  function changed(what) { save(); K.bus.emit('data', what || '*'); }
  var lat = function (v) { return U.sleep(40 + Math.random() * 60).then(function () { return v === undefined ? v : U.clone(v); }); };
  var fail = function (msg, code) { var e = new Error(msg); e.code = code || 'rule'; return Promise.reject(e); };

  /* ---------------- helpers ---------------- */
  var byId = function (list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; };
  var me = function () { return session ? byId(db.users, session.userId) : null; };
  var role = function () { return session ? session.activeRole : null; };
  var startOfDay = function () { var d = new Date(K.clock.now()); d.setHours(0, 0, 0, 0); return d.getTime(); };
  var isToday = function (ts) { return ts >= startOfDay() && ts < startOfDay() + 86400000; };
  var patient = function (id) { return byId(db.patients, id); };
  var item = function (sku) { for (var i = 0; i < db.inventory.length; i++) if (db.inventory[i].sku === sku) return db.inventory[i]; return null; };

  function audit(action, entity, id, detail) {
    db.audit.unshift({ id: U.uid('a'), ts: K.clock.now(), userId: session ? session.userId : 'system', role: role(), action: action, entity: entity, entityId: id, detail: detail || '', offline: !db.sync.online });
    if (db.audit.length > 500) db.audit.length = 500;
  }
  function notify(roles, title, body, ref, type) {
    db.notifications.unshift({ id: U.uid('n'), to: roles, type: type || 'info', title: title, body: body || '', ts: K.clock.now(), read: false, ref: ref || null });
    K.bus.emit('notify', { title: title, roles: roles });
  }
  function message(patientId, template, text) {
    var p = patient(patientId);
    if (!p) return;
    if (!p.consent || !p.consent.treatment) { audit('message_blocked', 'patient', patientId, 'No treatment-communication consent: ' + template); return; }
    var m = { id: U.uid('m'), patientId: patientId, channel: 'WhatsApp', template: template, text: text, ts: K.clock.now(), status: 'sent' };
    db.messages.unshift(m); db.clinic.settings.messagesUsed++;
    setTimeout(function () { m.status = 'delivered'; changed('messages'); }, 1500);
    setTimeout(function () { m.status = 'read'; changed('messages'); }, 5000);
    K.bus.emit('message', m);
  }
  /* Offline simulation: writes apply locally and are queued for sync */
  function write(method, desc, fn) {
    var res = fn();
    if (!db.sync.online) db.sync.pending.push({ id: U.uid('q'), method: method, desc: desc, ts: K.clock.now() });
    changed(method);
    return res;
  }
  function stageLog(v, stage, by) { v.stage = stage; v.stageLog.push({ stage: stage, ts: K.clock.now(), by: by || (session && session.userId) }); }
  function nextToken() { var t = db.visits.filter(function (v) { return isToday(v.createdAt); }).reduce(function (m, v) { return Math.max(m, v.token || 0); }, 0); return t + 1; }
  function enrichVisit(v) {
    var o = U.clone(v), p = patient(v.patientId);
    o.patient = p ? U.clone(p) : null;
    var last = v.stageLog[v.stageLog.length - 1];
    o.stageSince = last ? last.ts : v.arrivedAt;
    o.waitMin = U.mins(o.stageSince);
    o.totalMin = U.mins(v.arrivedAt);
    o.doctor = byId(db.users, v.doctorId); o.assigneeUser = v.assignee ? byId(db.users, v.assignee) : null;
    if (v.dilation && !v.dilation.done) { o.dilationLeft = Math.max(0, v.dilation.minutes - U.mins(v.dilation.start)); o.dilationReady = o.dilationLeft === 0; }
    var job = db.jobs.filter(function (j) { return j.visitId === v.id; })[0]; o.jobId = job ? job.id : null;
    return o;
  }
  var PRI = { emergency: 0, postop: 1, child: 2, elderly: 3, vip: 4 };
  function priScore(v) { return v.priority.length ? Math.min.apply(null, v.priority.map(function (p) { return PRI[p] === undefined ? 9 : PRI[p]; })) : 9; }
  function routeAfterDoctor(v) {
    var r = v.route || {};
    if (r.counselling) return 'counselling';
    if (r.optical) return 'optical';
    if (r.pharmacy) return 'pharmacy';
    return 'billing';
  }
  function finishStage(v, stage) { if (v.route) v.route[stage] = false; var nx = routeAfterDoctor(v); stageLog(v, nx); v.assignee = null; if (nx === 'billing') buildBill(v); }
  function lineFromService(s) { return { code: s.code, desc: s.desc, rate: s.rate, qty: s.qty || 1, stream: s.stream, gst: s.gst || 0 }; }
  function billTotal(b) { return Math.round(U.sum(b.lines, function (l) { return l.rate * l.qty * (1 + (l.gst || 0) / 100); })) - (b.discount || 0); }
  function paid(b) { return U.sum(b.payments.filter(function (p) { return p.status !== 'pending'; }), function (p) { return p.amount; }); }
  function buildBill(v) {
    var b = v.billId ? byId(db.bills, v.billId) : null;
    if (!b) {
      var n = db.bills.length + 1801;
      b = { id: U.uid('b'), invoiceNo: 'KOT/26-27/' + n, visitId: v.id, patientId: v.patientId, branchId: v.branchId, lines: [], discount: 0, total: 0, payments: [], status: 'open', createdAt: K.clock.now(), by: session && session.userId };
      db.bills.push(b); v.billId = b.id;
    }
    b.lines = v.services.map(lineFromService);
    b.total = billTotal(b);
    b.status = paid(b) >= b.total && b.total > 0 ? 'paid' : b.total === 0 ? 'zero' : 'open';
    return b;
  }
  function allergyHit(p, drugItem) {
    if (!p || !drugItem) return null;
    var hit = null;
    (p.allergies || []).forEach(function (a) {
      var al = a.toLowerCase();
      if (drugItem.name.toLowerCase().indexOf(al) >= 0 || (drugItem.cls && drugItem.cls.toLowerCase() === al)) hit = a;
    });
    return hit;
  }
  K.domain = K.domain || {};
  K.domain.allergyHit = function (p, sku) { return allergyHit(p, item(sku)); };

  /* ---------------- the service ---------------- */
  var S = {};

  /* ===== Auth & session ===== */
  S.listDemoUsers = function () { return lat(db.users.map(function (u) { return { id: u.id, name: u.name, roles: u.roles, special: u.special || '' }; })); };
  S.login = function (phone, pin) {
    var u = db.users.filter(function (x) { return x.phone === String(phone).trim(); })[0];
    if (!u) return U.sleep(300).then(function () { return fail('This mobile number is not registered for this clinic.'); });
    if (String(pin) !== u.pin) { audit('login_failed', 'user', u.id, 'Wrong PIN'); save(); return U.sleep(300).then(function () { return fail('Wrong PIN. 5 wrong attempts lock login for 15 minutes.'); }); }
    return S.loginAs(u.id);
  };
  S.loginAs = function (userId) {
    var u = byId(db.users, userId); if (!u) return fail('Unknown user');
    session = { userId: u.id, activeRole: u.roles[0], branchId: u.branches[0], loginAt: K.clock.now(), token: U.uid('tok') };
    saveSession(); audit('login', 'user', u.id, 'Signed in as ' + u.roles.join(', ')); changed('session');
    return S.getSession();
  };
  S.logout = function () { if (session) audit('logout', 'user', session.userId); session = null; saveSession(); changed('session'); return lat(true); };
  S.getSession = function () {
    if (!session) return lat(null);
    var u = me(); if (!u) { session = null; return lat(null); }
    return lat({ user: { id: u.id, name: u.name, roles: u.roles, regNo: u.regNo || '', qual: u.qual || '', special: u.special || '', branches: u.branches, phone: u.phone },
      activeRole: session.activeRole, branchId: session.branchId, branch: byId(db.clinic.branches, session.branchId), plan: db.clinic.plan, clinicName: db.clinic.name,
      settings: db.clinic.settings, online: db.sync.online, pending: db.sync.pending.length });
  };
  S.switchRole = function (r) { if (session && me().roles.indexOf(r) >= 0) { session.activeRole = r; saveSession(); changed('session'); } return S.getSession(); };
  S.switchBranch = function (branchId) {
    if (!session) return fail('Not signed in');
    if (me().branches.indexOf(branchId) < 0) return fail('No access to that branch'); // [SERVER RULE] CT-00-03
    session.branchId = branchId; saveSession(); audit('branch_switch', 'branch', branchId); changed('session'); return S.getSession();
  };
  S.getClinic = function () { return lat(db.clinic); };
  S.listUsers = function (r) { return lat(db.users.filter(function (u) { return !r || u.roles.indexOf(r) >= 0; }).map(function (u) { var c = U.clone(u); delete c.pin; return c; })); };
  S.listDevices = function (userId) { return lat(db.devices.filter(function (d) { return !userId || d.userId === userId; })); };

  /* ===== Patients ===== */
  S.searchPatients = function (q) {
    q = String(q || '').trim().toLowerCase();
    var list;
    if (!q) {
      var seen = {}; list = [];
      db.visits.slice().sort(U.by('createdAt', true)).forEach(function (v) { if (!seen[v.patientId] && list.length < 12) { seen[v.patientId] = 1; list.push(patient(v.patientId)); } });
    } else {
      list = db.patients.filter(function (p) {
        return p.name.toLowerCase().indexOf(q) >= 0 || p.phone.indexOf(q) >= 0 || p.uhid.toLowerCase().indexOf(q) >= 0 || (p.abha && p.abha.replace(/-/g, '').indexOf(q.replace(/-/g, '')) >= 0);
      }).slice(0, 30);
    }
    return lat(list.filter(Boolean));
  };
  S.getPatient = function (id) { var p = patient(id); return p ? lat(p) : fail('Patient not found', 'not_found'); };
  S.findDuplicates = function (d) {
    var name = String(d.name || '').toLowerCase().trim(), fn = name.split(' ')[0];
    var age = d.age ? Number(d.age) : d.dob ? U.age(d.dob) : null;
    return lat(db.patients.filter(function (p) {
      var samePhone = d.phone && p.phone === d.phone;
      var simName = fn && p.name.toLowerCase().split(' ')[0] === fn;
      var ageClose = age === null || Math.abs(U.age(p.dob) - age) <= 2;
      return (samePhone && simName) || (simName && p.name.toLowerCase() === name && ageClose);
    }));
  };
  S.createPatient = function (d) {
    if (!d.name || !d.phone || !d.sex || !(d.dob || d.age)) return fail('Name, mobile, sex and age or date of birth are required.');
    if (!/^\d{10}$/.test(d.phone)) return fail('Mobile number must be 10 digits.');
    if (!d.consent || !d.consent.treatment) return fail('Treatment-communication consent must be recorded (DPDP).');
    var dob = d.dob || (new Date(K.clock.now()).getFullYear() - Number(d.age)) + '-07-01';
    var p = { id: U.uid('p'), uhid: 'DEC-' + (24100 + db.patients.length + 50), name: d.name.trim(), sex: d.sex, dob: dob, dobEstimated: !d.dob, phone: d.phone, city: d.city || '', pincode: d.pincode || '',
      flags: d.flags || {}, allergies: d.allergies || [], referral: d.referral || 'Walk-in', payer: d.payer || 'Self', abha: d.abha || '', guardian: d.guardian || null,
      consent: { treatment: true, marketing: !!d.consent.marketing, ts: K.clock.now(), version: 'v1.2', channel: 'Care Team app' }, createdAt: K.clock.now(), pendingVerification: !!d.selfRegistered };
    return lat(write('createPatient', 'Register ' + p.name, function () { db.patients.push(p); audit('create', 'patient', p.id, p.name); audit('consent', 'patient', p.id, 'treatment=yes, marketing=' + (p.consent.marketing ? 'yes' : 'no')); return p; }));
  };
  S.updatePatient = function (id, patch) {
    var p = patient(id); if (!p) return fail('Patient not found');
    return lat(write('updatePatient', 'Edit ' + p.name, function () {
      Object.keys(patch).forEach(function (k) { audit('update', 'patient', id, k + ': ' + JSON.stringify(p[k]) + ' → ' + JSON.stringify(patch[k])); p[k] = patch[k]; });
      return p;
    }));
  };
  S.listFamily = function (id) { var p = patient(id); return lat(p ? db.patients.filter(function (x) { return x.phone === p.phone && x.id !== id; }) : []); };
  S.getPatientHistory = function (id) {
    var p = patient(id); if (!p) return fail('Patient not found');
    audit('view', 'patient', id, 'History opened');
    var visits = db.visits.filter(function (v) { return v.patientId === id; }).sort(U.by('createdAt', true));
    var trend = visits.slice().reverse().filter(function (v) { return v.exam && (v.exam.iop || v.exam.vision); }).map(function (v) {
      return { ts: v.createdAt, iopOD: v.exam.iop && v.exam.iop.OD, iopOS: v.exam.iop && v.exam.iop.OS,
        vaOD: v.exam.vision && (v.exam.vision.bcva.OD || v.exam.vision.ua.OD), vaOS: v.exam.vision && (v.exam.vision.bcva.OS || v.exam.vision.ua.OS),
        cdrOD: v.exam.posterior && v.exam.posterior.OD.cdr, cdrOS: v.exam.posterior && v.exam.posterior.OS.cdr };
    });
    return lat({ patient: p, visits: visits.map(enrichVisit), trend: trend,
      jobs: db.jobs.filter(function (j) { return j.patientId === id; }), bills: db.bills.filter(function (b) { return b.patientId === id; }),
      messages: db.messages.filter(function (m) { return m.patientId === id; }), admissions: db.admissions.filter(function (a) { return a.patientId === id; }),
      otCases: db.otCases.filter(function (c) { return c.patientId === id; }), appointments: db.appointments.filter(function (a) { return a.patientId === id; }) });
  };

  /* ===== Appointments & queue ===== */
  S.listAppointments = function (dayIso, doctorId) {
    return lat(db.appointments.filter(function (a) { return U.isoDay(a.ts) === dayIso && (!doctorId || a.doctorId === doctorId); }).sort(U.by('ts'))
      .map(function (a) { var o = U.clone(a); o.patient = patient(a.patientId); o.doctor = byId(db.users, a.doctorId); return o; }));
  };
  S.bookAppointment = function (d) {
    if (!d.patientId || !d.doctorId || !d.ts) return fail('Patient, doctor and time are required.');
    var clash = db.appointments.filter(function (a) { return a.doctorId === d.doctorId && a.ts === d.ts && a.status === 'booked'; })[0];
    var a = { id: d.id || U.uid('ap'), patientId: d.patientId, doctorId: d.doctorId, ts: d.ts, type: d.type || 'review', status: 'booked', source: d.source || 'Care Team app', doubleBooked: !!clash };
    return lat(write('bookAppointment', 'Book appointment', function () {
      if (d.id) { var old = byId(db.appointments, d.id); if (old) { db.appointments.splice(db.appointments.indexOf(old), 1); } }
      db.appointments.push(a); audit('book', 'appointment', a.id, U.dateTime(a.ts));
      message(a.patientId, 'booking_confirmation', 'Your appointment with ' + byId(db.users, a.doctorId).name + ' is confirmed for ' + U.date(a.ts) + ' at ' + U.time(a.ts) + '.');
      return a;
    }));
  };
  S.cancelAppointment = function (id, reason) {
    var a = byId(db.appointments, id); if (!a) return fail('Not found');
    return lat(write('cancelAppointment', 'Cancel appointment', function () { a.status = 'cancelled'; a.cancelReason = reason || ''; audit('cancel', 'appointment', id, reason); return a; }));
  };
  S.getQueue = function () {
    var bid = session ? session.branchId : 'br_1';
    var list = db.visits.filter(function (v) { return isToday(v.createdAt) && v.branchId === bid; }).map(enrichVisit);
    list.sort(function (a, b) { return priScore(a) - priScore(b) || a.arrivedAt - b.arrivedAt; });
    return lat(list);
  };
  S.checkIn = function (patientId, opts) {
    opts = opts || {};
    var p = patient(patientId); if (!p) return fail('Patient not found');
    var open = db.visits.filter(function (v) { return v.patientId === patientId && isToday(v.createdAt) && ['completed', 'lwbs'].indexOf(v.stage) < 0; })[0];
    if (open) return fail(p.name + ' is already in today’s queue (token ' + open.token + ').');
    var now = K.clock.now();
    var v = { id: U.uid('v'), patientId: patientId, branchId: session ? session.branchId : 'br_1', token: nextToken(), type: opts.type || 'review', stage: 'arrived', doctorId: opts.doctorId || 'u_doc1',
      assignee: null, priority: opts.priority || [], arrivedAt: now, stageLog: [{ stage: 'arrived', ts: now, by: session && session.userId }], dilation: null, exam: {}, examBy: {}, examSource: {},
      diagnoses: [], rx: { drugs: [], spectacle: null, cl: null, advice: [], followUpDays: null, signedAt: null, signedBy: null }, services: [], billId: null, signedAt: null, signedBy: null, addenda: [], investigations: [], createdAt: now };
    var age = U.age(p.dob);
    if (age >= 70 && v.priority.indexOf('elderly') < 0) v.priority.push('elderly');
    if (age < 12 && v.priority.indexOf('child') < 0) v.priority.push('child');
    return lat(write('checkIn', 'Check in ' + p.name, function () {
      db.visits.push(v);
      if (opts.appointmentId) { var a = byId(db.appointments, opts.appointmentId); if (a) a.status = 'arrived'; }
      audit('check_in', 'visit', v.id, p.name + ' token ' + v.token);
      message(patientId, 'token', 'Welcome to ' + db.clinic.name + '. Your token number is ' + v.token + '.');
      return enrichVisit(v);
    }));
  };
  S.callNext = function (stage) {
    var uid = session.userId, r = role();
    var today = db.visits.filter(function (v) { return isToday(v.createdAt) && v.branchId === session.branchId; });
    var pool;
    if (r === 'optometrist') pool = today.filter(function (v) { return v.stage === 'arrived'; });
    else if (r === 'doctor') pool = today.filter(function (v) {
      return (v.stage === 'doctor' && !v.assignee) || (v.stage === 'dilating' && v.dilation && U.mins(v.dilation.start) >= v.dilation.minutes) || (v.stage === 'investigations' && v.investigationsDone);
    }).sort(function (a, b) { return (a.doctorId === uid ? 0 : 1) - (b.doctorId === uid ? 0 : 1); });
    else pool = today.filter(function (v) { return v.stage === stage && !v.assignee; });
    pool.sort(function (a, b) { return priScore(a) - priScore(b) || a.arrivedAt - b.arrivedAt; });
    var v = pool[0];
    if (!v) return lat(null);
    return lat(write('callNext', 'Call next', function () {
      var target = r === 'optometrist' ? 'workup' : r === 'doctor' ? 'doctor' : v.stage;
      if (v.stage !== target) stageLog(v, target, uid);
      if (v.dilation) v.dilation.done = true;
      v.assignee = uid;
      if (r === 'doctor') v.doctorId = uid;
      var room = r === 'doctor' ? (uid === 'u_doc1' ? 'Room 2' : 'Room 3') : r === 'optometrist' ? 'Refraction room' : 'counter';
      message(v.patientId, 'token_call', 'Token ' + v.token + ': please come to ' + room + '.');
      audit('call', 'visit', v.id, 'Called by ' + me().name);
      return enrichVisit(v);
    }));
  };
  S.moveVisit = function (visitId, stage, reason) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    return lat(write('moveVisit', 'Move to ' + stage, function () {
      if (['optical', 'pharmacy', 'counselling'].indexOf(v.stage) >= 0 && stage === 'next') { finishStage(v, v.stage); }
      else { stageLog(v, stage); v.assignee = stage === 'workup' || stage === 'doctor' ? v.assignee : null; if (stage === 'billing') buildBill(v); }
      if (stage === 'lwbs') v.lwbsReason = reason || '';
      audit('stage', 'visit', visitId, v.stage + (reason ? ' (' + reason + ')' : ''));
      return enrichVisit(v);
    }));
  };
  S.setPriority = function (visitId, flags) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    return lat(write('setPriority', 'Priority', function () { audit('priority', 'visit', visitId, v.priority.join(',') + ' → ' + flags.join(',')); v.priority = flags; return enrichVisit(v); }));
  };
  S.transferVisit = function (visitId, doctorId, reason) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (!reason) return fail('A reason is required to transfer.');
    return lat(write('transferVisit', 'Transfer', function () {
      v.doctorId = doctorId; v.assignee = null; audit('transfer', 'visit', visitId, 'To ' + byId(db.users, doctorId).name + ': ' + reason);
      notify(['doctor'], 'Patient transferred to you', patient(v.patientId).name + ' — ' + reason, { screen: 'visit', id: v.id }, 'ready');
      return enrichVisit(v);
    }));
  };

  /* ===== Exam ===== */
  S.getVisit = function (id) { var v = byId(db.visits, id); if (!v) return fail('Visit not found'); audit('view', 'visit', id); return lat(enrichVisit(v)); };
  S.saveExamSection = function (visitId, section, data) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (v.signedAt && section !== 'investigations') return fail('Visit is signed. Add an addendum instead.', 'locked'); // [SERVER RULE] CT-04-15
    return lat(write('saveExamSection', 'Save ' + section, function () {
      var before = JSON.stringify(v.exam[section] || null);
      v.exam[section] = data; v.examBy[section] = session.userId;
      if (v.examSource[section] === 'device' && data._confirmed) v.examSource[section] = 'device-confirmed';
      if (before !== JSON.stringify(data)) audit('exam_save', 'visit', visitId, section);
      return enrichVisit(v);
    }));
  };
  S.startDilation = function (visitId, drops, minutes) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    return lat(write('startDilation', 'Start dilation', function () {
      v.dilation = { start: K.clock.now(), minutes: minutes || db.clinic.settings.dilationMinutes, drops: drops || 'Tropicamide + phenylephrine', by: session.userId };
      stageLog(v, 'dilating'); v.assignee = null; audit('dilation', 'visit', visitId, v.dilation.drops + ' ' + v.dilation.minutes + ' min');
      return enrichVisit(v);
    }));
  };
  S.importDeviceData = function (visitId, device) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    var r = function (a, b, step) { return Math.round((a + Math.random() * (b - a)) / step) * step; };
    return U.sleep(900).then(function () {
      return write('importDeviceData', 'Device import ' + device, function () {
        var payload;
        if (device === 'autorefractor') {
          var e = function () { return { sph: r(-3, 1.5, 0.25), cyl: -r(0, 1.5, 0.25), axis: r(5, 180, 5), add: 0 }; };
          payload = { OD: e(), OS: e(), k: { OD: { k1: r(42, 45, 0.25), k2: r(43, 46, 0.25), axis: r(0, 180, 5) }, OS: { k1: r(42, 45, 0.25), k2: r(43, 46, 0.25), axis: r(0, 180, 5) } } };
          v.exam.refraction = v.exam.refraction || {}; v.exam.refraction.auto = { OD: payload.OD, OS: payload.OS }; v.exam.refraction.k = payload.k;
          if (!v.exam.refraction.final) v.exam.refraction.final = U.clone({ OD: payload.OD, OS: payload.OS });
          v.examSource.refraction = 'device';
        } else if (device === 'nct') {
          payload = { OD: r(12, 24, 1), OS: r(12, 24, 1), method: 'NCT' };
          v.exam.iop = { method: 'NCT', OD: payload.OD, OS: payload.OS, time: K.clock.now() }; v.examSource.iop = 'device';
        } else if (device === 'lensmeter') {
          payload = { OD: { sph: r(-2, 1, 0.25), cyl: -r(0, 1, 0.25), axis: r(5, 180, 5), add: r(0, 2.5, 0.25) }, OS: { sph: r(-2, 1, 0.25), cyl: -r(0, 1, 0.25), axis: r(5, 180, 5), add: r(0, 2.5, 0.25) } };
          v.exam.refraction = v.exam.refraction || {}; v.exam.refraction.glasses = payload;
        }
        audit('device_import', 'visit', visitId, device);
        return { device: device, payload: payload, visit: enrichVisit(v) };
      });
    });
  };
  S.signVisit = function (visitId) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (role() !== 'doctor') return fail('Only a doctor can sign the visit.', 'forbidden'); // [SERVER RULE]
    return lat(write('signVisit', 'Sign visit', function () { v.signedAt = K.clock.now(); v.signedBy = session.userId; audit('sign', 'visit', visitId); return enrichVisit(v); }));
  };
  S.addAddendum = function (visitId, text, reason) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (!text || !reason) return fail('Addendum text and reason are required.');
    return lat(write('addAddendum', 'Addendum', function () { v.addenda.push({ ts: K.clock.now(), by: session.userId, text: text, reason: reason }); audit('addendum', 'visit', visitId, reason); return enrichVisit(v); }));
  };

  /* ===== Diagnosis & Rx ===== */
  S.listDiagnosisMaster = function () { return lat(db.diagnoses); };
  S.listDrugMaster = function () { return lat(db.inventory.filter(function (i) { return i.type === 'drug'; })); };
  S.listRxTemplates = function () {
    return lat(db.rxTemplates.map(function (t) { var o = U.clone(t); o.lines.forEach(function (l) { var it = item(l.sku); l.name = it.name; l.cls = it.cls; }); return o; }));
  };
  S.saveRx = function (visitId, rx) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (v.rx.signedAt) return fail('Prescription already signed.', 'locked');
    return lat(write('saveRx', 'Save Rx draft', function () { var keep = v.rx; v.rx = Object.assign({}, keep, rx, { signedAt: null, signedBy: null, draftBy: session.userId }); return enrichVisit(v); }));
  };
  /* payload: { diagnoses, drugs, spectacle, cl, advice, followUpDays, procedure:{name, eye, note}, investigations:[codes], overrides:[{sku, reason}] } */
  S.signRx = function (visitId, payload) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    var u = me(), r = role(), p = patient(v.patientId);
    if (r !== 'doctor' && !(r === 'optometrist' && !payload.drugs.length)) return fail('Only a doctor can sign drug prescriptions.', 'forbidden');
    if (r === 'doctor' && !u.regNo) return fail('Add your registration number and signature in your profile before signing.');
    // [SERVER RULE] allergy check CT-05-05
    for (var i = 0; i < payload.drugs.length; i++) {
      var hit = allergyHit(p, item(payload.drugs[i].sku));
      var ov = (payload.overrides || []).filter(function (o) { return o.sku === payload.drugs[i].sku; })[0];
      if (hit && !ov) return fail('Allergy: ' + p.name + ' is allergic to ' + hit + '. Override with a reason to continue.', 'allergy');
    }
    if (!payload.diagnoses || !payload.diagnoses.length) return fail('Add at least one diagnosis with the eye.');
    var countersignNeeded = r === 'optometrist' && db.clinic.settings.countersignOptomRx;
    return lat(write('signRx', 'Sign Rx', function () {
      v.diagnoses = payload.diagnoses;
      v.rx = { drugs: payload.drugs, spectacle: payload.spectacle || null, cl: payload.cl || null, advice: payload.advice || [], followUpDays: payload.followUpDays || null,
        procedure: payload.procedure || null, overrides: payload.overrides || [], signedAt: countersignNeeded ? null : K.clock.now(), signedBy: countersignNeeded ? null : u.id,
        draftBy: u.id, awaitingCountersign: countersignNeeded };
      if (countersignNeeded) { notify(['doctor'], 'Countersign needed: spectacle Rx', p.name + ' — drafted by ' + u.name, { screen: 'visit', id: v.id }, 'approval'); audit('rx_draft', 'visit', visitId, 'Awaiting countersign'); return enrichVisit(v); }
      v.signedAt = K.clock.now(); v.signedBy = u.id;
      (payload.overrides || []).forEach(function (o) { audit('allergy_override', 'visit', visitId, o.sku + ': ' + o.reason); });
      // services
      var has = function (c) { return v.services.some(function (s) { return s.code === c; }); };
      var fee = v.type === 'new' ? { code: 'CON-N', desc: 'Consultation (new)', rate: 500 } : v.type === 'postop' ? { code: 'CON-PO', desc: 'Post-op review', rate: 0 } : { code: 'CON-R', desc: 'Consultation (review)', rate: 300 };
      if (!has(fee.code)) v.services.push({ code: fee.code, desc: fee.desc, rate: fee.rate, qty: 1, stream: 'OPD', gst: 0 });
      (payload.investigations || []).forEach(function (code) { var s = db.services.filter(function (x) { return x.code === code; })[0]; if (s && !has(code)) v.services.push({ code: s.code, desc: s.desc, rate: s.rate, qty: 1, stream: s.stream, gst: 0 }); });
      v.route = { counselling: !!payload.procedure, optical: !!payload.spectacle, pharmacy: payload.drugs.length > 0 };
      if (payload.procedure) {
        db.counselling.unshift({ id: U.uid('cs'), visitId: v.id, patientId: v.patientId, procedure: payload.procedure.name, eye: payload.procedure.eye, advisedBy: u.id, note: payload.procedure.note || '', packageId: null, estimate: null, status: 'new', consent: null, surgeryTs: null, ts: K.clock.now() });
        notify(['counsellor'], 'New counselling: ' + p.name, payload.procedure.name + ' ' + payload.procedure.eye, { screen: 'counselling' }, 'ready');
      }
      if (payload.spectacle) notify(['optician'], 'Spectacle Rx ready: ' + p.name, 'Signed by ' + u.name, { screen: 'optical' }, 'ready');
      if (payload.drugs.length) notify(['pharmacist'], 'Rx to dispense: ' + p.name, payload.drugs.length + ' item(s)', { screen: 'pharmacy' }, 'ready');
      if (payload.followUpDays) {
        var d = new Date(K.clock.now() + payload.followUpDays * 86400000); d.setHours(10, 30, 0, 0);
        db.appointments.push({ id: U.uid('ap'), patientId: v.patientId, doctorId: u.id, ts: d.getTime(), type: 'review', status: 'booked', source: 'Follow-up from Rx' });
      }
      var next = routeAfterDoctor(v); stageLog(v, next); v.assignee = null; if (next === 'billing') buildBill(v);
      message(v.patientId, 'prescription', 'Your prescription from ' + u.name + ' is ready. Open the PDF: eyespyes.app/rx/' + v.id.slice(-6));
      audit('rx_sign', 'visit', visitId, payload.drugs.length + ' drugs' + (payload.spectacle ? ', spectacle Rx' : '') + (payload.procedure ? ', procedure advised' : ''));
      return enrichVisit(v);
    }));
  };
  S.countersignRx = function (visitId) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (role() !== 'doctor') return fail('Only a doctor can countersign.');
    return lat(write('countersignRx', 'Countersign', function () {
      v.rx.signedAt = K.clock.now(); v.rx.signedBy = session.userId; v.rx.awaitingCountersign = false; v.signedAt = v.rx.signedAt; v.signedBy = session.userId;
      v.route = { optical: !!v.rx.spectacle, pharmacy: false, counselling: false };
      var next = routeAfterDoctor(v); stageLog(v, next); if (next === 'billing') buildBill(v);
      audit('rx_countersign', 'visit', visitId); return enrichVisit(v);
    }));
  };

  /* ===== Counselling ===== */
  S.listPackages = function () { return lat(db.packages); };
  S.listCounselling = function () { return lat(db.counselling.map(function (c) { var o = U.clone(c); o.patient = patient(c.patientId); o.doctor = byId(db.users, c.advisedBy); return o; })); };
  S.updateCounselling = function (id, patch) {
    var c = byId(db.counselling, id); if (!c) return fail('Not found');
    if (patch.status === 'booked' && (!c.consent && !patch.consent)) return fail('Record the patient’s signed consent before booking surgery.');
    return lat(write('updateCounselling', 'Counselling ' + (patch.status || 'update'), function () {
      Object.assign(c, patch);
      var p = patient(c.patientId), v = c.visitId ? byId(db.visits, c.visitId) : null;
      if (patch.estimate) message(c.patientId, 'estimate', 'Estimate for ' + c.procedure + ' (' + c.eye + '): ' + U.inr(patch.estimate) + '. Valid for 30 days.');
      if (patch.status === 'booked') {
        var pk = byId(db.packages, c.packageId);
        db.otCases.push({ id: U.uid('ot'), patientId: c.patientId, admissionId: null, theatre: 'OT-1', ts: c.surgeryTs, surgeonId: c.advisedBy, anaesthesia: 'Topical', procedure: pk && pk.id !== 'pk1' ? 'Phacoemulsification + IOL' : 'SICS + IOL', eye: c.eye,
          iolPlan: { model: pk ? pk.iol : 'OptiFold Monofocal', power: 21.5 }, iolImplanted: null, status: 'scheduled',
          checklist: { preop: { consent: true, biometry: !!(v && v.services.some(function (s) { return s.code === 'BIO'; })), iolSelected: true, iolInStock: false, fitness: false, eyeMarked: false, fasting: false }, signIn: { done: false }, timeOut: { done: false }, signOut: { done: false } }, notes: '', complications: '' });
        message(c.patientId, 'surgery_booked', 'Your ' + c.procedure + ' (' + c.eye + ') is booked on ' + U.dateTime(c.surgeryTs) + '. Pre-op instructions will follow.');
        notify(['ot'], 'New OT booking: ' + p.name, c.procedure + ' ' + c.eye + ' on ' + U.dateTime(c.surgeryTs), { screen: 'ot' }, 'ot');
      }
      if (v && v.stage === 'counselling' && patch.status && patch.status !== 'new') { if (pk) v.services.push({ code: 'PKG-ADV', desc: 'Surgery advance (' + pk.name + ')', rate: patch.advance || 0, qty: 1, stream: 'Surgery', gst: 0 }); finishStage(v, 'counselling'); }
      audit('counselling', 'counselling', id, JSON.stringify(patch).slice(0, 120));
      return c;
    }));
  };

  /* ===== Optical ===== */
  S.lookupBarcode = function (code) {
    code = String(code || '').trim().toUpperCase();
    var it = db.inventory.filter(function (i) { return String(i.barcode).toUpperCase() === code || String(i.sku).toUpperCase() === code; })[0];
    return it ? lat(it) : U.sleep(200).then(function () { return fail('No item with barcode ' + code, 'not_found'); });
  };
  S.listOpticalJobs = function () {
    var leads = db.visits.filter(function (v) { return v.stage === 'optical' && isToday(v.createdAt) && !db.jobs.some(function (j) { return j.visitId === v.id; }); }).map(enrichVisit);
    var jobs = db.jobs.map(function (j) { var o = U.clone(j); o.patient = patient(j.patientId); o.overdue = j.due < K.clock.now() && ['ready', 'delivered'].indexOf(j.status) < 0; return o; }).sort(U.by('createdAt', true));
    return lat({ leads: leads, jobs: jobs });
  };
  S.createOpticalJob = function (d) {
    if (!d.frame || !d.lens) return fail('Select a frame and a lens.');
    if (!d.rx || !d.rx.OD) return fail('Prescription is required.');
    var v = d.visitId ? byId(db.visits, d.visitId) : null;
    if (v && v.rx.spectacle && !v.rx.signedAt) return fail('The spectacle Rx is not signed yet.'); // CT-05-13
    var fr = item(d.frame.sku); if (fr && fr.qty < 1) return fail('Frame out of stock at this branch.');
    var j = { id: U.uid('job'), patientId: d.patientId, visitId: d.visitId || null, rx: d.rx, frame: d.frame, lens: d.lens, measure: d.measure || {}, status: 'ordered', lab: d.lab || 'Outside lab',
      due: K.clock.now() + (d.dueHours || 48) * 3600000, advance: Number(d.advance) || 0, price: d.frame.price + d.lens.price, statusLog: [{ status: 'ordered', ts: K.clock.now(), by: session.userId }], createdAt: K.clock.now(), external: !!d.external };
    return lat(write('createOpticalJob', 'Job card', function () {
      db.jobs.push(j); if (fr) fr.qty--;
      if (v) { v.services.push({ code: d.frame.sku, desc: 'Frame: ' + d.frame.name, rate: d.frame.price, qty: 1, stream: 'Optical', gst: 12 }, { code: d.lens.sku, desc: 'Lenses: ' + d.lens.name, rate: d.lens.price, qty: 1, stream: 'Optical', gst: 12 }); if (v.stage === 'optical') finishStage(v, 'optical'); }
      audit('create', 'job', j.id, d.frame.name + ' + ' + d.lens.name);
      message(d.patientId, 'order_placed', 'Your spectacle order is placed. Expected by ' + U.dateTime(j.due) + '.');
      return j;
    }));
  };
  S.updateOpticalJob = function (id, patch) {
    var j = byId(db.jobs, id); if (!j) return fail('Job not found');
    if (patch.status === 'ready' && j.qc && !j.qc.pass && !patch.qc) return fail('QC failed: lens power does not match the Rx. Send for remake.');
    if (patch.qc) {
      var tol = 0.25, bad = [];
      ['OD', 'OS'].forEach(function (e) { ['sph', 'cyl'].forEach(function (k) { if (Math.abs((patch.qc[e][k] || 0) - (j.rx[e][k] || 0)) > tol) bad.push(e + ' ' + k); }); });
      patch.qc.pass = bad.length === 0; patch.qc.issues = bad;
    }
    return lat(write('updateOpticalJob', 'Job ' + (patch.status || 'update'), function () {
      if (patch.qc) j.qc = patch.qc;
      if (patch.status && patch.status !== j.status) {
        j.status = patch.status; j.statusLog.push({ status: patch.status, ts: K.clock.now(), by: session.userId });
        if (patch.status === 'ready') message(j.patientId, 'order_ready', 'Your spectacles are ready for pickup at ' + db.clinic.name + '.');
        if (patch.status === 'delivered') { j.deliveredTo = patch.deliveredTo || 'Patient'; j.warrantyTill = K.clock.now() + 365 * 86400000; }
        if (patch.status === 'remake') { j.remakeReason = patch.reason || ''; }
      }
      audit('update', 'job', id, JSON.stringify(patch).slice(0, 100));
      return j;
    }));
  };

  /* ===== Pharmacy & inventory ===== */
  S.listInventory = function (type) {
    var now = K.clock.now();
    return lat(db.inventory.filter(function (i) { return !type || i.type === type; }).map(function (i) {
      var o = U.clone(i); o.low = i.reorder > 0 && i.qty <= i.reorder; o.nearExpiry = i.expiry && i.expiry - now < 90 * 86400000; o.expired = i.expiry && i.expiry < now; return o;
    }));
  };
  S.listDispenseQueue = function () {
    return lat(db.visits.filter(function (v) { return v.stage === 'pharmacy' && v.rx.drugs.length && !v.dispensed; }).map(enrichVisit));
  };
  S.dispense = function (visitId, lines) {
    var v = byId(db.visits, visitId); if (!v) return fail('Visit not found');
    if (!v.rx.signedAt) return fail('Prescription is not signed.');
    for (var i = 0; i < lines.length; i++) {
      var it = item(lines[i].sku);
      if (!it) return fail('Unknown item ' + lines[i].sku);
      if (it.expiry && it.expiry < K.clock.now()) return fail(it.name + ': batch ' + it.batch + ' is expired and cannot be dispensed.'); // [SERVER RULE] CT-08-02
      if (it.qty < lines[i].qty) return fail(it.name + ': only ' + it.qty + ' in stock.');
    }
    return lat(write('dispense', 'Dispense', function () {
      lines.forEach(function (l) {
        var it = item(l.sku); it.qty -= l.qty;
        v.services.push({ code: it.sku, desc: it.name + ' (batch ' + it.batch + ')', rate: it.price, qty: l.qty, stream: 'Pharmacy', gst: it.gst });
        if (it.qty <= it.reorder) notify(['pharmacist', 'owner'], 'Low stock: ' + it.name, it.qty + ' left, reorder level ' + it.reorder, { screen: 'stock' }, 'stock');
      });
      v.dispensed = { ts: K.clock.now(), by: session.userId, lines: lines };
      finishStage(v, 'pharmacy'); audit('dispense', 'visit', visitId, lines.length + ' lines');
      return enrichVisit(v);
    }));
  };
  S.raisePurchase = function (sku, qty, note) {
    var it = item(sku); if (!it) return fail('Unknown item');
    return lat(write('raisePurchase', 'Purchase request', function () {
      var a = { id: U.uid('apr'), type: 'purchase', refType: 'item', refId: it.id, sku: sku, qty: qty, title: 'Purchase: ' + it.name + ' × ' + qty, detail: note || ('Stock ' + it.qty + ', reorder level ' + it.reorder), amount: it.price * qty * 0.75, requestedBy: session.userId, ts: K.clock.now(), status: 'pending' };
      db.approvals.unshift(a); notify(['owner'], 'Approval needed: purchase', a.title, { screen: 'approvals' }, 'approval'); audit('request', 'approval', a.id, a.title); return a;
    }));
  };

  /* ===== Billing ===== */
  S.listBillingQueue = function () {
    return lat(db.visits.filter(function (v) { return v.stage === 'billing' && isToday(v.createdAt); }).map(function (v) { buildBill(v); var o = enrichVisit(v); o.bill = U.clone(byId(db.bills, v.billId)); return o; }));
  };
  S.getBill = function (id) { var b = byId(db.bills, id); if (!b) return fail('Bill not found'); var o = U.clone(b); o.paid = paid(b); o.due = Math.max(0, b.total - o.paid); o.patient = patient(b.patientId); return lat(o); };
  S.buildBillForVisit = function (visitId) { var v = byId(db.visits, visitId); if (!v) return fail('Visit not found'); var b = write('buildBill', 'Build bill', function () { return buildBill(v); }); return S.getBill(b.id); };
  S.applyDiscount = function (billId, amount, reason) {
    var b = byId(db.bills, billId); if (!b) return fail('Bill not found');
    amount = Number(amount) || 0; if (!reason) return fail('A reason is required for any discount.');
    var limit = db.clinic.settings.discountLimit[role()] || 0;
    if (amount <= limit) {
      return lat(write('applyDiscount', 'Discount', function () { b.discount = amount; b.discountReason = reason; b.total = billTotal(b); audit('discount', 'bill', billId, U.inr(amount) + ' ' + reason); return { applied: true }; }));
    }
    return lat(write('applyDiscount', 'Discount approval', function () {
      var a = { id: U.uid('apr'), type: 'discount', refType: 'bill', refId: billId, title: 'Discount ' + U.inr(amount) + ' on ' + b.invoiceNo, detail: patient(b.patientId).name + ': ' + reason, amount: amount, requestedBy: session.userId, ts: K.clock.now(), status: 'pending' };
      db.approvals.unshift(a); b.discountPending = a.id;
      notify(['owner'], 'Approval needed: discount', a.title + ' — ' + reason, { screen: 'approvals' }, 'approval');
      audit('request', 'approval', a.id, a.title); return { applied: false, approvalId: a.id, limit: limit };
    }));
  };
  S.addPayment = function (billId, d) {
    var b = byId(db.bills, billId); if (!b) return fail('Bill not found');
    var amt = Number(d.amount) || 0; if (amt <= 0) return fail('Enter an amount.');
    return lat(write('addPayment', 'Payment ' + d.mode, function () {
      var p = { id: U.uid('pay'), mode: d.mode, amount: amt, ts: K.clock.now(), ref: d.ref || '', status: d.mode === 'UPI' ? 'pending' : 'ok', by: session.userId };
      b.payments.push(p);
      audit('payment', 'bill', billId, d.mode + ' ' + U.inr(amt) + (p.status === 'pending' ? ' (awaiting UPI callback)' : ''));
      settle(b);
      return p;
    }));
  };
  function settle(b) {
    if (paid(b) >= b.total) {
      b.status = 'paid';
      var v = byId(db.visits, b.visitId);
      if (v && v.stage === 'billing') { stageLog(v, 'completed'); message(b.patientId, 'invoice', 'Thank you for visiting ' + db.clinic.name + '. Invoice ' + b.invoiceNo + ' for ' + U.inr(b.total) + '.'); }
    }
  }
  S.listBills = function (dayIso) { return lat(db.bills.filter(function (b) { return !dayIso || U.isoDay(b.createdAt) === dayIso; }).map(function (b) { var o = U.clone(b); o.paid = paid(b); o.patient = patient(b.patientId); return o; })); };

  /* ===== IPD ===== */
  S.listBeds = function () {
    return lat(db.beds.map(function (b) { var o = U.clone(b); var a = b.admissionId ? byId(db.admissions, b.admissionId) : null; if (a) { o.admission = U.clone(a); o.patient = patient(a.patientId); } return o; }));
  };
  S.admit = function (d) {
    var bed = byId(db.beds, d.bedId); if (!bed || bed.status !== 'free') return fail('Bed is not free.');
    var a = { id: U.uid('adm'), patientId: d.patientId, bedId: d.bedId, admittedAt: K.clock.now(), surgeonId: d.surgeonId || 'u_doc1', packageId: d.packageId || null, payer: d.payer || 'Self', deposit: Number(d.deposit) || 0,
      status: 'admitted', orders: [{ id: U.uid('o'), type: 'care', text: 'Pre-op: confirm fasting, mark operative eye', times: [] }], nursing: [], mar: [], discharge: null };
    return lat(write('admit', 'Admit', function () { db.admissions.push(a); bed.status = 'occupied'; bed.admissionId = a.id; audit('admit', 'admission', a.id, bed.label); return a; }));
  };
  S.getAdmission = function (id) {
    var a = byId(db.admissions, id); if (!a) return fail('Admission not found');
    var o = U.clone(a); o.patient = patient(a.patientId); o.bed = byId(db.beds, a.bedId); o.surgeon = byId(db.users, a.surgeonId); o.pkg = byId(db.packages, a.packageId);
    o.otCases = db.otCases.filter(function (c) { return c.admissionId === id; });
    return lat(o);
  };
  S.addNursingEntry = function (id, e) {
    var a = byId(db.admissions, id); if (!a) return fail('Admission not found');
    return lat(write('addNursingEntry', 'Nursing entry', function () { e.ts = K.clock.now(); e.by = session.userId; a.nursing.unshift(e); audit('nursing', 'admission', id); return a; }));
  };
  S.recordDose = function (id, orderId, time, status, note) {
    var a = byId(db.admissions, id); if (!a) return fail('Admission not found');
    return lat(write('recordDose', 'MAR', function () { a.mar.push({ orderId: orderId, time: time, ts: K.clock.now(), by: session.userId, status: status || 'given', note: note || '' }); audit('mar', 'admission', id, orderId + ' ' + time + ' ' + (status || 'given')); return a; }));
  };
  S.discharge = function (id, summary) {
    var a = byId(db.admissions, id); if (!a) return fail('Admission not found');
    if (role() !== 'doctor') return fail('A doctor must sign the discharge summary.');
    return lat(write('discharge', 'Discharge', function () {
      a.status = 'discharged'; a.discharge = { ts: K.clock.now(), by: session.userId, summary: summary };
      var bed = byId(db.beds, a.bedId); bed.status = 'cleaning'; bed.admissionId = null;
      var d = new Date(K.clock.now() + 86400000); d.setHours(10, 0, 0, 0);
      db.appointments.push({ id: U.uid('ap'), patientId: a.patientId, doctorId: a.surgeonId, ts: d.getTime(), type: 'postop', status: 'booked', source: 'Auto (post-op day 1)' });
      message(a.patientId, 'discharge', 'Discharge summary and eye-drop schedule are ready. Post-op review tomorrow ' + U.time(d.getTime()) + '.');
      audit('discharge', 'admission', id); return a;
    }));
  };
  S.setBedStatus = function (bedId, status) { var b = byId(db.beds, bedId); return lat(write('setBedStatus', 'Bed ' + status, function () { if (b.status !== 'occupied') b.status = status; return b; })); };

  /* ===== OT ===== */
  S.listOTCases = function (dayIso) {
    return lat(db.otCases.filter(function (c) { return !dayIso || U.isoDay(c.ts) === dayIso; }).sort(U.by('ts')).map(function (c) { var o = U.clone(c); o.patient = patient(c.patientId); o.surgeon = byId(db.users, c.surgeonId); return o; }));
  };
  S.getOTCase = function (id) { var c = byId(db.otCases, id); if (!c) return fail('Case not found'); var o = U.clone(c); o.patient = patient(c.patientId); o.surgeon = byId(db.users, c.surgeonId); return lat(o); };
  var OT_FLOW = ['scheduled', 'preop_ready', 'in_holding', 'in_ot', 'recovery', 'completed'];
  S.updateOTChecklist = function (id, part, data) {
    var c = byId(db.otCases, id); if (!c) return fail('Case not found');
    var ck = c.checklist;
    if (part === 'signIn' && Object.keys(ck.preop).some(function (k) { return !ck.preop[k]; }) && !data.override) return fail('Pre-op checklist has open items. Surgeon override with a reason is required.'); // CT-11-02
    if (part === 'timeOut') {
      if (!ck.signIn.done) return fail('Complete sign-in first.');
      if (!data.patient || !data.procedure || !data.eye || !data.iol) return fail('Time-out needs patient, procedure, eye and IOL confirmed aloud.'); // CT-11-03
    }
    if (part === 'signOut' && !ck.timeOut.done) return fail('Complete time-out first.');
    return lat(write('updateOTChecklist', 'OT ' + part, function () {
      if (part === 'preop') Object.assign(ck.preop, data); else { ck[part] = Object.assign({ done: true, by: session.userId, ts: K.clock.now() }, data); }
      if (part === 'preop' && c.status === 'scheduled' && Object.keys(ck.preop).every(function (k) { return ck.preop[k]; })) c.status = 'preop_ready';
      if (part === 'signIn' && OT_FLOW.indexOf(c.status) < 3) c.status = 'in_ot';
      if (part === 'signOut') c.status = 'recovery';
      audit('ot_checklist', 'ot', id, part + (data.override ? ' (override: ' + data.override + ')' : ''));
      return c;
    }));
  };
  S.scanIOL = function (id, code) {
    var c = byId(db.otCases, id); if (!c) return fail('Case not found');
    var it = db.inventory.filter(function (i) { return i.type === 'iol' && String(i.barcode).toUpperCase() === String(code).trim().toUpperCase(); })[0];
    if (!it) return U.sleep(300).then(function () { return { ok: false, reason: 'Barcode not found in IOL stock.' }; });
    if (it.qty < 1) return lat({ ok: false, reason: 'This IOL (' + it.serial + ') is already used.' });
    var match = it.model === c.iolPlan.model && Math.abs(it.power - c.iolPlan.power) < 0.01;
    if (!match) { audit('iol_mismatch', 'ot', id, 'Scanned ' + it.name + ' vs plan ' + c.iolPlan.model + ' ' + c.iolPlan.power); save(); return lat({ ok: false, mismatch: true, scanned: it, reason: 'MISMATCH: scanned ' + it.model + ' ' + it.power.toFixed(1) + ' D, plan is ' + c.iolPlan.model + ' ' + c.iolPlan.power.toFixed(1) + ' D.' }); }
    return lat(write('scanIOL', 'IOL scan', function () {
      c.iolImplanted = { model: it.model, power: it.power, serial: it.serial, code: it.barcode, ts: K.clock.now(), by: session.userId }; it.qty = 0;
      audit('iol_implant', 'ot', id, it.name + ' ' + it.serial); return { ok: true, scanned: it };
    }));
  };
  S.setOTStatus = function (id, status, notes) {
    var c = byId(db.otCases, id); if (!c) return fail('Case not found');
    if (status === 'completed' && !c.checklist.signOut.done) return fail('Complete sign-out before closing the case.');
    if (status === 'completed' && !c.iolImplanted && /IOL/.test(c.procedure)) return fail('Scan the implanted IOL first (implant log).');
    return lat(write('setOTStatus', 'OT ' + status, function () {
      c.status = status; if (notes) { c.notes = notes.notes || c.notes; c.complications = notes.complications || c.complications; }
      if (status === 'completed') {
        var d = new Date(K.clock.now() + 86400000); d.setHours(10, 0, 0, 0);
        if (!db.appointments.some(function (a) { return a.patientId === c.patientId && a.type === 'postop' && a.ts > K.clock.now(); }))
          db.appointments.push({ id: U.uid('ap'), patientId: c.patientId, doctorId: c.surgeonId, ts: d.getTime(), type: 'postop', status: 'booked', source: 'Auto (post-op day 1)' });
        var p = patient(c.patientId); p.flags.postop = true;
        message(c.patientId, 'postop', 'Surgery completed. Start drops as per the schedule in your prescription. Post-op review tomorrow.');
      }
      audit('ot_status', 'ot', id, status); return c;
    }));
  };

  /* ===== Inbox ===== */
  S.listNotifications = function () {
    var r = role();
    return lat(db.notifications.filter(function (n) { return !n.to || n.to.indexOf(r) >= 0 || (r === 'owner' && n.type === 'approval'); }).slice(0, 60));
  };
  S.markNotificationRead = function (id) { var n = byId(db.notifications, id); if (n) { n.read = true; changed('notifications'); } return lat(true); };
  S.listApprovals = function (status) { return lat(db.approvals.filter(function (a) { return !status || a.status === status; }).map(function (a) { var o = U.clone(a); o.requester = byId(db.users, a.requestedBy); return o; })); };
  S.decideApproval = function (id, approve, reason) {
    var a = byId(db.approvals, id); if (!a) return fail('Not found');
    if (role() !== 'owner') return fail('Only the owner or branch manager can approve.', 'forbidden'); // [SERVER RULE]
    if (!approve && !reason) return fail('Give a reason when rejecting.');
    return lat(write('decideApproval', 'Approval', function () {
      a.status = approve ? 'approved' : 'rejected'; a.decidedBy = session.userId; a.decidedAt = K.clock.now(); a.reason = reason || '';
      if (a.type === 'discount' && a.refId) { var b = byId(db.bills, a.refId); if (b) { if (approve) { b.discount = a.amount; b.discountReason = a.detail; b.total = billTotal(b); } b.discountPending = null; } }
      if (a.type === 'purchase' && approve) notify(['pharmacist'], 'PO approved', a.title + ' — sent to supplier', { screen: 'stock' }, 'stock');
      notify(['front_desk', 'billing', 'optician', 'pharmacist'], 'Approval ' + a.status, a.title, null, 'approval');
      audit('decision', 'approval', id, a.status + (reason ? ': ' + reason : '')); return a;
    }));
  };
  S.sendMessage = function (patientId, template, text) { return lat(write('sendMessage', 'Message', function () { message(patientId, template, text); return true; })); };
  S.listMessages = function (patientId) { return lat(db.messages.filter(function (m) { return !patientId || m.patientId === patientId; }).map(function (m) { var o = U.clone(m); o.patient = patient(m.patientId); return o; })); };
  S.listRecalls = function () { return lat(db.recalls.map(function (r) { var o = U.clone(r); o.patient = patient(r.patientId); return o; }).sort(U.by('due'))); };
  S.updateRecall = function (id, patch) {
    var r = byId(db.recalls, id); if (!r) return fail('Not found');
    return lat(write('updateRecall', 'Recall', function () {
      Object.assign(r, patch); r.lastContact = K.clock.now();
      if (patch.status === 'sent') message(r.patientId, 'recall', 'It is time for your ' + r.rule.toLowerCase() + '. Reply 1 to book, or call us.');
      audit('recall', 'recall', id, patch.status); return r;
    }));
  };

  /* ===== Dashboard & reports ===== */
  S.getDashboard = function () {
    var bid = session ? session.branchId : 'br_1';
    var today = db.visits.filter(function (v) { return isToday(v.createdAt) && v.branchId === bid; });
    var bills = db.bills.filter(function (b) { return isToday(b.createdAt) && b.branchId === bid; });
    var waiting = today.filter(function (v) { return ['completed', 'lwbs'].indexOf(v.stage) < 0; });
    var waits = today.map(function (v) { var d = v.stageLog.filter(function (s) { return s.stage === 'doctor'; })[0]; return d ? U.mins(v.arrivedAt, d.ts) : null; }).filter(function (x) { return x !== null; });
    var streams = {};
    bills.forEach(function (b) {
      var gross = U.sum(b.lines, function (l) { return l.rate * l.qty * (1 + (l.gst || 0) / 100); }) || 1, got = paid(b);
      b.lines.forEach(function (l) { streams[l.stream] = (streams[l.stream] || 0) + got * (l.rate * l.qty * (1 + (l.gst || 0) / 100)) / gross; });
    });
    var collections = U.sum(bills, paid);
    var otToday = db.otCases.filter(function (c) { return isToday(c.ts); });
    var jobsToday = db.jobs.filter(function (j) { return isToday(j.createdAt); });
    var byHour = {}; today.forEach(function (v) { var h = new Date(v.arrivedAt).getHours(); byHour[h] = (byHour[h] || 0) + 1; });
    var docs = db.users.filter(function (u) { return u.roles.indexOf('doctor') >= 0; }).map(function (u) {
      var seen = today.filter(function (v) { return v.signedBy === u.id; });
      return { id: u.id, name: u.name, seen: seen.length, waiting: today.filter(function (v) { return v.doctorId === u.id && ['arrived', 'workup', 'dilating', 'doctor'].indexOf(v.stage) >= 0; }).length,
        surgeriesAdvised: db.counselling.filter(function (c) { return c.advisedBy === u.id && isToday(c.ts); }).length };
    });
    var lw = db.meta.lastWeek || (db.meta.lastWeek = { patients: 24, newPatients: 7, collections: 41850, avgWait: 34, surgeries: 3, optical: 2 });
    var specRx = today.filter(function (v) { return v.rx && v.rx.spectacle; }).length;
    return lat({
      patients: today.length, newPatients: today.filter(function (v) { return v.type === 'new'; }).length, waitingNow: waiting.length,
      avgWait: waits.length ? Math.round(U.sum(waits) / waits.length) : 0, collections: Math.round(collections), streams: streams,
      surgeriesDone: otToday.filter(function (c) { return c.status === 'completed'; }).length, surgeriesBooked: otToday.length,
      opticalOrders: jobsToday.length, opticalValue: U.sum(jobsToday, function (j) { return j.price; }),
      dues: U.sum(db.bills.filter(function (b) { return b.status === 'open'; }), function (b) { return Math.max(0, b.total - paid(b)); }),
      pendingApprovals: db.approvals.filter(function (a) { return a.status === 'pending'; }).length,
      lastWeek: lw, byHour: byHour, doctors: docs,
      funnelCataract: { advised: 42 + db.counselling.filter(function (c) { return isToday(c.ts); }).length, counselled: 36, booked: 24 + db.otCases.filter(function (c) { return c.status === 'scheduled' && c.ts > K.clock.now(); }).length - 1, operated: 19 + otToday.filter(function (c) { return c.status === 'completed'; }).length - 1 },
      funnelOptical: { rx: 58 + specRx, sold: 41 + jobsToday.length },
      compliance: { unsigned: db.visits.filter(function (v) { return !v.signedAt && v.stageLog.some(function (s) { return s.stage === 'doctor'; }) && U.mins(v.arrivedAt) > 1440; }).length,
        noConsent: db.patients.filter(function (p) { return !p.consent || !p.consent.treatment; }).length, failedLogins: db.audit.filter(function (a) { return a.action === 'login_failed'; }).length,
        offlinePending: db.sync.pending.length }
    });
  };
  S.getReport = function (name) {
    var day = U.isoDay(K.clock.now()), rows = [], cols = [];
    var todays = db.bills.filter(function (b) { return U.isoDay(b.createdAt) === day; });
    if (name === 'daybook') { cols = ['Invoice', 'Patient', 'Total', 'Paid', 'Mode']; rows = todays.map(function (b) { return [b.invoiceNo, patient(b.patientId).name, U.inr(b.total), U.inr(paid(b)), b.payments.map(function (p) { return p.mode; }).join('+') || '—']; }); }
    else if (name === 'collections') { cols = ['Mode', 'Count', 'Amount']; var m = {}; todays.forEach(function (b) { b.payments.forEach(function (p) { if (p.status === 'pending') return; m[p.mode] = m[p.mode] || [0, 0]; m[p.mode][0]++; m[p.mode][1] += p.amount; }); }); rows = Object.keys(m).map(function (k) { return [k, m[k][0], U.inr(m[k][1])]; }); }
    else if (name === 'gst') { cols = ['GST rate', 'Taxable', 'GST']; var g = {}; todays.forEach(function (b) { b.lines.forEach(function (l) { var r = l.gst || 0; g[r] = g[r] || [0, 0]; g[r][0] += l.rate * l.qty; g[r][1] += l.rate * l.qty * r / 100; }); }); rows = Object.keys(g).map(function (k) { return [k + '%', U.inr(g[k][0]), U.inr(g[k][1])]; }); }
    else if (name === 'stock') { cols = ['Type', 'Items', 'Value']; var s = {}; db.inventory.forEach(function (i) { s[i.type] = s[i.type] || [0, 0]; s[i.type][0] += i.qty > 0 ? 1 : 0; s[i.type][1] += i.qty * i.price; }); rows = Object.keys(s).map(function (k) { return [U.cap(k), s[k][0], U.inr(s[k][1])]; }); }
    else if (name === 'near_expiry') { cols = ['Item', 'Batch', 'Expiry', 'Qty']; rows = db.inventory.filter(function (i) { return i.expiry && i.expiry - K.clock.now() < 90 * 86400000; }).map(function (i) { return [i.name, i.batch || '', U.date(i.expiry), i.qty]; }); }
    else if (name === 'implant_log') { cols = ['Date', 'Patient', 'Eye', 'IOL', 'Serial']; rows = db.otCases.filter(function (c) { return c.iolImplanted; }).map(function (c) { return [U.date(c.ts), patient(c.patientId).name, c.eye, c.iolImplanted.model + ' ' + c.iolImplanted.power.toFixed(1) + ' D', c.iolImplanted.serial]; }); }
    else if (name === 'surgery_register') { cols = ['Date', 'Patient', 'Procedure', 'Eye', 'Surgeon', 'Status']; rows = db.otCases.slice().sort(U.by('ts')).map(function (c) { return [U.dateTime(c.ts), patient(c.patientId).name, c.procedure, c.eye, byId(db.users, c.surgeonId).name, c.status.replace('_', ' ')]; }); }
    return lat({ name: name, cols: cols, rows: rows, generatedAt: K.clock.now() });
  };
  S.listAudit = function (entity, id) { return lat(db.audit.filter(function (a) { return (!entity || a.entity === entity) && (!id || a.entityId === id); }).slice(0, 200).map(function (a) { var o = U.clone(a); var u = byId(db.users, a.userId); o.user = u ? u.name : a.userId; return o; })); };
  S.getSyncState = function () { return lat({ online: db.sync.online, pending: db.sync.pending }); };

  /* ===== Demo controls (mock only) ===== */
  var names = [['Shreya', 'Kapoor', 'F'], ['Mahendra', 'Salunkhe', 'M'], ['Ritu', 'Agarwal', 'F'], ['Tukaram', 'Mane', 'M'], ['Zoya', 'Khan', 'F'], ['Babu', 'Rao', 'M'], ['Leela', 'Menon', 'F'], ['Sameer', 'Bhide', 'M']];
  S.demo = {
    reset: function () { try { localStorage.removeItem(KEY); } catch (e) { /* storage unavailable */ } K.clock.offsetMs = 0; db = K.seed(); save(true); var keep = session; session = keep; changed('reset'); return lat(true); },
    tick: function () {
      var any = false;
      db.visits.forEach(function (v) {
        if (v.stage === 'dilating' && v.dilation && !v.dilation.notified && U.mins(v.dilation.start) >= v.dilation.minutes) {
          v.dilation.notified = true; any = true;
          notify(['doctor', 'optometrist'], 'Dilation complete: ' + patient(v.patientId).name, 'Token ' + v.token + ' is ready for fundus examination', { screen: 'visit', id: v.id }, 'ready');
        }
      });
      if (any) changed('tick');
    },
    simulateArrival: function (withAppointment) {
      var n = names[Math.floor(Math.random() * names.length)], age = 25 + Math.floor(Math.random() * 50);
      var p = { id: U.uid('p'), uhid: 'DEC-' + (25000 + db.patients.length), name: n[0] + ' ' + n[1], sex: n[2], dob: (new Date(K.clock.now()).getFullYear() - age) + '-04-15', phone: '97' + String(Math.floor(1e7 + Math.random() * 9e7)),
        city: 'Pune', pincode: '411004', flags: Math.random() < 0.3 ? { diabetic: true } : {}, allergies: [], referral: 'Walk-in', payer: 'Self', abha: '', guardian: null, consent: { treatment: true, marketing: false, ts: K.clock.now(), version: 'v1.2' }, createdAt: K.clock.now() };
      db.patients.push(p);
      var prevSession = session; if (!session) session = { userId: 'u_desk', activeRole: 'front_desk', branchId: 'br_1' };
      return S.checkIn(p.id, { type: Math.random() < 0.5 ? 'new' : 'review', doctorId: Math.random() < 0.5 ? 'u_doc1' : 'u_doc2' }).then(function (v) { session = prevSession; return v; });
    },
    fastForward: function (min) { K.clock.advance(min); save(); S.demo.tick(); changed('clock'); return lat(true); },
    setOnline: function (on) {
      db.sync.online = !!on;
      var synced = 0;
      if (on && db.sync.pending.length) { synced = db.sync.pending.length; audit('sync', 'device', '-', synced + ' offline changes synced'); db.sync.pending = []; }
      changed('sync'); return lat({ online: db.sync.online, synced: synced });
    },
    simulateUpiCallback: function (billId) {
      var bills = db.bills.filter(function (b) { return (!billId || b.id === billId) && b.payments.some(function (p) { return p.status === 'pending'; }); });
      if (!bills.length) return lat(0);
      bills.forEach(function (b) { b.payments.forEach(function (p) { if (p.status === 'pending') { p.status = 'ok'; p.ref = 'UPI' + Math.floor(1e9 + Math.random() * 9e9); } }); settle(b); audit('payment_callback', 'bill', b.id, 'UPI confirmed by gateway'); });
      changed('payment'); return lat(bills.length);
    },
    simulateCriticalResult: function () {
      var v = db.visits.filter(function (x) { return isToday(x.createdAt) && x.stage !== 'completed'; })[0] || db.visits[db.visits.length - 1];
      notify(['doctor'], 'CRITICAL: random blood sugar 342 mg/dL', patient(v.patientId).name + ' — pre-op lab. Acknowledge required.', { screen: 'visit', id: v.id }, 'critical');
      changed('critical'); return lat(true);
    },
    simulateLabReturn: function () {
      var j = db.jobs.filter(function (x) { return x.status === 'in_lab' || x.status === 'ordered'; })[0];
      if (!j) return lat(null);
      j.status = 'received'; j.statusLog.push({ status: 'received', ts: K.clock.now(), by: 'lab' });
      notify(['optician'], 'Lab delivered: ' + patient(j.patientId).name, 'Run QC with the lensmeter before marking ready', { screen: 'job', id: j.id }, 'ready');
      changed('lab'); return lat(j);
    },
    setPlan: function (plan) { db.clinic.plan = plan; audit('plan', 'clinic', db.clinic.id, plan); changed('plan'); return lat(plan); },
    snapshot: function () { return lat(db); },
    stats: function () { return lat({ patients: db.patients.length, visits: db.visits.length, bills: db.bills.length, audit: db.audit.length, messages: db.messages.length, bytes: (function () { try { return (localStorage.getItem(KEY) || '').length; } catch (e) { return JSON.stringify(db).length; } })() }); }
  };

  load();
  K.MockDataService = S;
})();
