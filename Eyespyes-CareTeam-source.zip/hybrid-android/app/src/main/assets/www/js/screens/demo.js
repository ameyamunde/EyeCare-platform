/* DEMO CENTRE — mock the working of the whole clinic without a backend.
   Guided story (one patient end to end across 7 roles), simulators, role switch,
   offline mode, plan switch, API call log and data-contract coverage for the DBMS team. */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var SK = 'eyespyes.demo.story';
  var story = (function () { try { return JSON.parse(localStorage.getItem(SK) || 'null') || { step: 0, visitId: null }; } catch (e) { return { step: 0, visitId: null }; } })();
  var saveStory = function () { try { localStorage.setItem(SK, JSON.stringify(story)); } catch (e) { /* ignore */ } };
  var as = function (userId) { return K.data.loginAs(userId).then(K.reloadSession); };
  var logOpen = false;

  var STEPS = [
    { who: 'Front desk', title: 'A walk-in patient arrives and is checked in', run: function () {
      return as('u_desk').then(function () { return K.data.demo.simulateArrival(); }).then(function (v) { story.visitId = v.id; K.ui.toast('Token ' + v.token + ': ' + v.patient.name + ' checked in'); K.go('queue'); });
    } },
    { who: 'Optometrist', title: 'Work-up: call in, import auto-refractor and tonometer', run: function () {
      return as('u_opt1').then(function () { return K.data.moveVisit(story.visitId, 'workup', 'Called by optometrist'); })
        .then(function () { return K.data.saveExamSection(story.visitId, 'vision', { notation: 'snellen', ua: { OD: '6/18', OS: '6/12' }, ph: { OD: '6/9', OS: '6/9' }, bcva: { OD: '', OS: '' }, near: { OD: 'N10', OS: 'N10' } }); })
        .then(function () { return K.data.importDeviceData(story.visitId, 'autorefractor'); }).then(function () { return K.data.importDeviceData(story.visitId, 'nct'); })
        .then(function () { K.ui.toast('Device values imported — outlined until confirmed'); K.go('visit/' + story.visitId); });
    } },
    { who: 'Optometrist', title: 'Dilate, then fast-forward 20 minutes', run: function () {
      return as('u_opt1').then(function () { return K.data.startDilation(story.visitId, 'Tropicamide + phenylephrine', 20); })
        .then(function () { return K.data.demo.fastForward(21); }).then(function () { K.ui.toast('Clock +21 min: dilation complete, doctor alerted'); });
    } },
    { who: 'Doctor', title: 'Doctor calls the patient, diagnoses and signs Smart Rx', run: function () {
      return as('u_doc1').then(function () { return K.data.moveVisit(story.visitId, 'doctor', 'Called by doctor'); })
        .then(function () { return K.data.getVisit(story.visitId); })
        .then(function (v) {
          var fin = (v.exam.refraction && v.exam.refraction.final) || { OD: { sph: 0, cyl: 0, axis: null, add: 0 }, OS: { sph: 0, cyl: 0, axis: null, add: 0 } };
          fin.OD.add = 1.5; fin.OS.add = 1.5;
          return K.data.saveExamSection(story.visitId, 'posterior', { OD: { media: 'Clear', cdr: 0.3, macula: 'Normal', vessels: 'Normal', periphery: 'Normal', dr: 'No DR' }, OS: { media: 'Clear', cdr: 0.3, macula: 'Normal', vessels: 'Normal', periphery: 'Normal', dr: 'No DR' } })
            .then(function () { return K.data.signRx(story.visitId, { diagnoses: [{ code: 'H52.4', name: 'Presbyopia', eye: 'OU' }, { code: 'H04.1', name: 'Dry eye syndrome', eye: 'OU' }],
              drugs: [{ sku: 'DRG004', name: 'Carboxymethylcellulose 0.5% eye drops', eye: 'OU', freq: '4 times/day', duration: '1 month', taper: null, qty: 1 }],
              spectacle: { OD: fin.OD, OS: fin.OS, pd: 63, lensAdvice: 'Progressive', coating: 'Anti-reflective', validMonths: 12 }, advice: ['20-20-20 screen breaks'], followUpDays: 365, procedure: null, investigations: [], overrides: [] }); });
        }).then(function () { K.ui.toast('Signed: Rx on WhatsApp, routed to optical then pharmacy'); K.go('rxview/' + story.visitId); });
    } },
    { who: 'Optician', title: 'Optician builds the job card (frame scan + progressive lens)', run: function () {
      return as('u_optician').then(function () { return K.data.getVisit(story.visitId); }).then(function (v) {
        return K.data.createOpticalJob({ visitId: v.id, patientId: v.patientId, rx: { OD: v.rx.spectacle.OD, OS: v.rx.spectacle.OS, pd: v.rx.spectacle.pd }, frame: { sku: 'FR1005', name: 'Half rim metal, silver', price: 2800 },
          lens: { sku: 'LN05', name: 'Progressive 1.56 standard', price: 6500 }, measure: { pd: 63, fitHeight: 19, a: 52, b: 36, dbl: 18 }, advance: 3000, dueHours: 48, lab: 'Outside lab' });
      }).then(function (j) { K.ui.toast('Job card created'); K.go('job/' + j.id); });
    } },
    { who: 'Pharmacist', title: 'Pharmacist scans and dispenses the drops', run: function () {
      return as('u_pharm').then(function () { return K.data.dispense(story.visitId, [{ sku: 'DRG004', qty: 1 }]); }).then(function () { K.ui.toast('Dispensed (FEFO batch); moved to billing'); K.go('pharmacy'); });
    } },
    { who: 'Billing', title: 'Billing collects by UPI QR; gateway confirms', run: function () {
      return as('u_bill').then(function () { return K.data.buildBillForVisit(story.visitId); }).then(function (b) {
        return K.data.addPayment(b.id, { mode: 'UPI', amount: b.due }).then(function () { K.go('bill/' + b.id); return U.sleep(1800); }).then(function () { return K.data.demo.simulateUpiCallback(b.id); });
      }).then(function () { K.ui.toast('Paid — invoice sent; visit completed'); });
    } },
    { who: 'Owner', title: 'Owner sees today’s numbers move and clears approvals', run: function () {
      return as('u_owner').then(function () { K.go('dashboard'); K.ui.toast('Dashboard includes this patient; approvals are waiting in the card at the top'); });
    } }
  ];

  K.screens.demo = {
    title: 'Demo centre', tab: 'more', noTabs: false,
    render: function () {
      return Promise.all([K.data.getSyncState(), K.data.getClinic(), K.data.listDemoUsers(), K.data.demo ? K.data.demo.stats() : Promise.resolve({})]).then(function (r) {
        var sync = r[0], cl = r[1], users = r[2], stats = r[3];
        var missMock = K.DataContract.verify(K.MockDataService, 'mock'), missApi = K.DataContract.verify(K.ApiDataService, 'api');
        var off = Math.round(K.clock.offsetMs / 60000);
        return '<div class="demo-hero"><b style="font-size:17px">Demo centre</b><p>Mock the clinic’s working end to end. Everything runs on this device through the same data contract the real backend will implement.</p>' +
          '<p class="small">Data mode: <b>' + esc(K.config.dataMode) + '</b> · Clock ' + (off ? '+' + U.dur(off) : 'real time') + ' · ' + (sync.online ? 'Online' : 'Offline (' + sync.pending.length + ' to sync)') + ' · Plan: ' + esc(cl.plan) + '</p></div>' +

          '<div class="h2">Guided story: one patient, seven roles</div><div class="card">' + STEPS.map(function (s, i) {
            var done = i < story.step, cur = i === story.step;
            return '<div class="step ' + (done ? 'done' : '') + '" style="padding:6px 0"><div class="n">' + (done ? '✓' : i + 1) + '</div><div class="grow"><div class="small muted">' + esc(s.who) + '</div><div>' + esc(s.title) + '</div></div>' +
              (cur ? '<button class="btn sm" data-act="step" data-i="' + i + '">Do it</button>' : '') + '</div>';
          }).join('') + '<div class="btn-row" style="margin-top:8px"><button class="btn ghost sm" data-act="storyReset">Restart story</button>' + (story.visitId ? '<button class="btn ghost sm" data-act="storyOpen">Open story patient</button>' : '') + '</div>' +
          '<p class="small muted">Each step signs in as that role, performs the action through the data service and opens the screen. You can also do every step by hand.</p></div>' +

          '<div class="h2">Simulators</div><div class="grid2">' +
          sim('arrive', 'Walk-in arrives', 'New patient checked in') + sim('ff10', '+10 minutes', 'Timers, waits, dilation') +
          sim('ff20', '+20 minutes', 'Completes dilations') + sim('upi', 'UPI callback', 'Confirms pending UPI') +
          sim('critical', 'Critical lab result', 'Doctor must acknowledge') + sim('lab', 'Lab returns spectacles', 'Optician runs QC') +
          sim('offline', sync.online ? 'Go offline' : 'Back online', sync.online ? 'Writes queue on device' : sync.pending.length + ' changes will sync') + sim('dark', 'Dark-room theme', 'Slit-lamp rooms') + '</div>' +

          '<div class="h2">Plan (feature flags, CT-00-05)</div>' + C.seg('plan', K.PLANS.map(function (p) { return [p, p]; }), cl.plan) +
          '<p class="small muted">Solo hides IPD, OT, pharmacy and counselling; Clinic adds counselling and recalls; Hospital adds IPD/OT/pharmacy; Enterprise adds multi-branch.</p>' +

          '<div class="h2">Switch user</div><div class="role-grid">' + users.map(function (u) { return '<button class="role-card" data-act="as" data-id="' + u.id + '" style="' + (K.session.user.id === u.id ? 'border-color:var(--primary);background:var(--sky-50)' : '') + '">' + K.roleIcon(u.roles[0]) + '<span><b>' + esc(u.name) + '</b><span>' + u.roles.map(function (x) { return esc(K.ROLES[x]); }).join(' + ') + '</span></span></button>'; }).join('') + '</div>' +

          '<div class="h2">For the DBMS / backend team</div><div class="card"><div class="small">Data contract: <b>' + K.DataContract.names.length + '</b> methods · mock implements all' + (missMock.length ? ' except ' + esc(missMock.join(', ')) : '') + ' · API stub maps ' + (K.DataContract.names.length - 1 - missApi.length) + ' to REST routes.</div>' +
          '<div class="small muted">Local store: ' + (stats.patients || 0) + ' patients, ' + (stats.visits || 0) + ' visits, ' + (stats.bills || 0) + ' bills, ' + (stats.audit || 0) + ' audit events, ' + Math.round((stats.bytes || 0) / 1024) + ' KB.</div>' +
          '<div class="btn-row" style="margin-top:8px"><button class="btn ghost sm" data-act="log">' + (logOpen ? 'Hide' : 'Show') + ' API call log (' + (K.apiLog || []).length + ')</button><button class="btn ghost sm" data-act="contract">View contract</button><button class="btn ghost sm" data-act="snapshot">Share data snapshot</button></div>' +
          (logOpen ? '<div class="log" style="margin-top:8px">' + (K.apiLog || []).slice(0, 80).map(function (e) { return U.time(e.ts) + '  ' + (e.ok ? 'OK ' : 'ERR') + ' ' + e.ms + 'ms  ' + e.method + '  → ' + e.route + (e.error ? '\n      ' + e.error : '') + (e.args.length ? '\n      args: ' + JSON.stringify(e.args).slice(0, 160) : ''); }).map(esc).join('\n') + '</div>' : '') + '</div>' +

          '<div class="h2">Data</div><div class="btn-row"><button class="btn danger" data-act="reset">Reset demo data</button></div><p class="small muted">Demo data also resets automatically each new day. Nothing leaves this device.</p>';
        function sim(act, t, s) { var ic = { arrive: 'users', ff10: 'ff', ff20: 'ff', upi: 'rupee', critical: 'alert', lab: 'glasses', offline: 'wifioff', dark: 'moon' }[act];
          return '<button class="role-card" data-act="sim" data-s="' + act + '"><span class="ri" style="background:var(--primary)">' + K.icon(ic) + '</span><span><b>' + t + '</b><span>' + esc(s) + '</span></span></button>'; }
      });
    },
    mount: function (root) {
      root.addEventListener('segchange', function (e) { if (e.detail.name === 'plan') K.data.demo.setPlan(e.detail.value).then(K.reloadSession).then(function () { K.ui.toast('Plan: ' + e.detail.value); K.refresh(); }); });
    },
    actions: {
      step: function (el) {
        var i = Number(el.getAttribute('data-i'));
        if (i > 0 && !story.visitId) { K.ui.toast('Restart the story'); return; }
        el.disabled = true; el.textContent = 'Working…';
        return STEPS[i].run().then(function () { story.step = i + 1; saveStory(); }).catch(function (e) { el.disabled = false; el.textContent = 'Do it'; throw e; });
      },
      storyReset: function () { story = { step: 0, visitId: null }; saveStory(); K.refresh(); },
      storyOpen: function () { K.go('visit/' + story.visitId); },
      as: function (el) { return as(el.getAttribute('data-id')).then(function () { K.ui.toast('Signed in as ' + K.session.user.name); K.go('home'); }); },
      sim: function (el) {
        var s = el.getAttribute('data-s'), D = K.data.demo;
        if (s === 'arrive') return D.simulateArrival().then(function (v) { K.ui.toast('Token ' + v.token + ': ' + v.patient.name + ' arrived'); });
        if (s === 'ff10') return D.fastForward(10).then(function () { K.ui.toast('Clock moved 10 minutes ahead'); });
        if (s === 'ff20') return D.fastForward(20).then(function () { K.ui.toast('Clock moved 20 minutes ahead'); });
        if (s === 'upi') return D.simulateUpiCallback().then(function (n) { K.ui.toast(n ? n + ' UPI payment(s) confirmed' : 'No pending UPI payments'); });
        if (s === 'critical') return D.simulateCriticalResult().then(function () { K.ui.toast('Critical result sent to doctors’ inbox'); });
        if (s === 'lab') return D.simulateLabReturn().then(function (j) { K.ui.toast(j ? 'Lab delivered a job — see Optical' : 'No jobs at the lab'); });
        if (s === 'offline') return K.data.getSyncState().then(function (st) { return D.setOnline(!st.online); }).then(function (r) { K.ui.toast(r.online ? 'Back online' + (r.synced ? ' — ' + r.synced + ' changes synced' : '') : 'Offline: keep working, changes queue on the device'); K.updateChrome(); });
        if (s === 'dark') { document.body.classList.toggle('dark'); try { localStorage.setItem('eyespyes.dark', document.body.classList.contains('dark') ? '1' : '0'); } catch (e) { /* ignore */ } }
      },
      log: function () { logOpen = !logOpen; K.refresh(); },
      contract: function () {
        K.ui.sheet('Data contract', '<p class="small muted">Each UI call maps to one backend route. Full entity definitions: docs/DATA_CONTRACT.md.</p><div class="log" style="max-height:60vh">' +
          K.DataContract.names.map(function (n) { var m = K.DataContract.methods[n]; return esc(n) + '\n   ' + esc(m[0]) + '\n   ' + esc(m[1]) + ' [' + esc(m[2]) + ']'; }).join('\n') + '</div>', {});
      },
      snapshot: function () { return K.data.demo.snapshot().then(function (db) { var s = JSON.stringify(db); K.native.share('Eyespyes demo data snapshot', s.length > 90000 ? s.slice(0, 90000) : s); K.ui.toast('Snapshot: ' + Math.round(s.length / 1024) + ' KB of JSON'); }); },
      reset: function () { return K.ui.confirm('Reset demo data', 'Restore the fictional clinic to its starting state? Your sign-in stays.', 'Reset', true).then(function (ok) { if (ok) { story = { step: 0, visitId: null }; saveStory(); return K.data.demo.reset().then(K.reloadSession).then(function () { K.ui.toast('Demo data reset'); K.refresh(); }); } }); }
    }
  };
})();
