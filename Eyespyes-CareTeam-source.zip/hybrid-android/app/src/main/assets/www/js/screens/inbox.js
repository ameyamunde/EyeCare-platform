/* Inbox (PRD Epics 13–14): alerts by role, critical acknowledgement, approvals with reasons */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;
  var ICON = { ready: 'eye', stock: 'box', overdue: 'clock', approval: 'checkc', mar: 'pill', ot: 'ot', critical: 'alert', info: 'info' };

  K.screens.inbox = {
    title: 'Inbox', tab: 'inbox', root: true, live: true,
    render: function () {
      var owner = K.session.activeRole === 'owner';
      return Promise.all([K.data.listNotifications(), owner ? K.data.listApprovals('pending') : Promise.resolve([])]).then(function (r) {
        var n = r[0], ap = r[1];
        return (owner ? '<div class="card tap accent" data-act="approvals"><div class="row between"><b>Approvals</b>' + C.pill(ap.length + ' pending', ap.length ? 'warn' : 'ok') + '</div><div class="small muted">Discounts, refunds, purchase orders, access changes</div></div><div style="height:10px"></div>' : '') +
          '<div class="row between"><div class="h2">Alerts</div>' + (n.some(function (x) { return !x.read; }) ? '<button class="btn ghost sm" data-act="readAll">Mark all read</button>' : '') + '</div>' +
          (n.length ? '<div class="list">' + n.map(function (x) {
            return '<div class="li" data-act="open" data-id="' + x.id + '" style="' + (x.type === 'critical' && !x.read ? 'background:var(--crit-soft)' : '') + '"><span class="lic" style="' + (x.type === 'critical' ? 'background:var(--crit-soft);color:var(--crit)' : '') + '">' + K.icon(ICON[x.type] || 'info') + '</span><div class="grow"><div class="' + (x.read ? '' : 'b') + '" style="font-weight:' + (x.read ? 400 : 700) + '">' + esc(x.title) + '</div><div class="small muted">' + esc(x.body) + ' · ' + U.ago(x.ts) + '</div></div>' + (x.read ? '' : '<span class="badge" style="position:static">new</span>') + '</div>';
          }).join('') + '</div>' : C.empty('All caught up'));
      });
    },
    actions: {
      approvals: function () { K.go('approvals'); },
      readAll: function () { return K.data.listNotifications().then(function (n) { return Promise.all(n.filter(function (x) { return !x.read && x.type !== 'critical'; }).map(function (x) { return K.data.markNotificationRead(x.id); })); }); },
      open: function (el) {
        return K.data.listNotifications().then(function (list) {
          var n = list.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0];
          var nav = function () { if (!n.ref) return; var map = { visit: 'visit/', approvals: 'approvals', stock: 'stock', job: 'job/', admission: 'admission/', otcase: 'otcase/', ot: 'ot', counselling: 'counselling', optical: 'optical', pharmacy: 'pharmacy' }; var r = map[n.ref.screen]; if (r) K.go(r + (r.slice(-1) === '/' ? n.ref.id : '')); };
          if (n.type === 'critical' && !n.read) {
            K.ui.sheet('Critical result', '<div class="banner-note" style="background:var(--crit-soft);color:var(--crit)"><b>' + esc(n.title) + '</b><br>' + esc(n.body) + '</div><p class="small">Acknowledging records your name and time (CT-09-08).</p><button class="btn danger block" data-sact="ack">Acknowledge and open patient</button>', {
              ack: function () { return K.data.markNotificationRead(n.id).then(function () { K.ui.closeSheet(); nav(); }); } });
            return;
          }
          return K.data.markNotificationRead(n.id).then(nav);
        });
      }
    }
  };

  K.screens.approvals = {
    title: 'Approvals', tab: 'inbox', live: true,
    render: function () {
      return K.data.listApprovals().then(function (list) {
        var pend = list.filter(function (a) { return a.status === 'pending'; }), done = list.filter(function (a) { return a.status !== 'pending'; });
        var owner = K.session.activeRole === 'owner';
        var card = function (a) {
          return '<div class="card"><div class="row between"><b>' + esc(a.title) + '</b>' + C.pill(a.status, a.status === 'approved' ? 'ok' : a.status === 'rejected' ? 'crit' : 'warn') + '</div><div class="small">' + esc(a.detail) + '</div>' +
            '<div class="small muted">' + esc(a.requester ? a.requester.name : '') + ' · ' + U.ago(a.ts) + (a.amount ? ' · ' + U.inr(a.amount) : '') + (a.reason ? ' · ' + esc(a.reason) : '') + '</div>' +
            (a.status === 'pending' && owner ? '<div class="btn-row" style="margin-top:8px"><button class="btn ghost" data-act="reject" data-id="' + a.id + '">Reject</button><button class="btn ok" data-act="approve" data-id="' + a.id + '">Approve</button></div>' : '') + '</div>';
        };
        return (owner ? '' : '<div class="banner-info">Only the owner or branch manager can decide approvals.</div>') + '<div class="h2">Pending</div>' + (pend.length ? pend.map(card).join('') : C.empty('Nothing to approve')) + (done.length ? '<div class="h2">Decided</div>' + done.map(card).join('') : '');
      });
    },
    actions: {
      approve: function (el) { return K.data.decideApproval(el.getAttribute('data-id'), true).then(function () { K.native.vibrate(); K.ui.toast('Approved; requester notified'); }); },
      reject: function (el) { return K.ui.prompt('Reject', 'Reason (required)', { required: true }).then(function (r) { if (r) return K.data.decideApproval(el.getAttribute('data-id'), false, r).then(function () { K.ui.toast('Rejected'); }); }); }
    }
  };
})();
