/* Home by role (PRD Epic 3 + Epic 14): queue board, doctor queue, work-up queue, owner dashboard */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;

  var HOME = { owner: 'dashboard', doctor: 'myqueue', optometrist: 'workup', front_desk: 'queue', counsellor: 'counselling', optician: 'optical', pharmacist: 'pharmacy', nurse: 'ward', ot: 'ot', billing: 'billingq' };
  K.homeRoute = function () { return HOME[K.session.activeRole] || 'queue'; };
  K.screens.home = { title: 'Home', tab: 'home', root: true, render: function () { setTimeout(function () { K.go(K.homeRoute(), true); }, 0); return Promise.resolve(''); } };
  K.screens.notfound = { title: 'Not found', render: function () { return Promise.resolve(C.empty('Screen not found')); } };

  /* ---------- Shared queue card ---------- */
  C.qcard = function (v, opts) {
    opts = opts || {};
    var p = v.patient || {};
    var timer = '';
    if (v.stage === 'dilating' && v.dilation) timer = v.dilationReady ? C.pill('Dilated — ready', 'ok') : '<span class="pill pill-info">Dilating <span class="timer">' + v.dilationLeft + ' min</span> left</span>';
    var meta = [C.stagePill(v.stage), '<span class="small waitline ' + C.waitClass(v.waitMin) + '">' + K.icon('clock', 'sm') + U.dur(v.waitMin) + '</span>', timer,
      v.type === 'new' ? C.pill('New', 'brand') : v.type === 'postop' ? C.pill('Post-op', 'brand') : '', v.rx && v.rx.awaitingCountersign ? C.pill('Rx needs countersign', 'warn') : ''].join(' ');
    return '<div class="card tap qcard" style="--stage:' + (K.STAGE_COLOR[v.stage] || '#0EA5E9') + '" data-act="' + (opts.act || 'openVisit') + '" data-id="' + esc(v.id) + '"><div class="token">' + esc(v.token) + '</div><div class="grow">' +
      '<div class="row between"><b class="ellipsis">' + esc(p.name) + '</b><span class="small muted">' + C.ageSex(p) + '</span></div>' +
      '<div class="qmeta">' + meta + '</div>' + '<div class="qmeta">' + C.flags(p, v) + '</div>' +
      (opts.extra ? '<div class="small muted" style="margin-top:4px">' + opts.extra(v) + '</div>' : '') + '</div></div>';
  };
  K.openVisit = function (id) { K.go('visit/' + id); };

  /* ---------- Front desk: queue board (CT-03-04) ---------- */
  var qState = { filter: 'active' };
  K.screens.queue = {
    title: 'Queue board', tab: 'home', root: true, live: true,
    render: function () {
      return K.data.getQueue().then(function (list) {
        var counts = {}; list.forEach(function (v) { counts[v.stage] = (counts[v.stage] || 0) + 1; });
        var active = list.filter(function (v) { return ['completed', 'lwbs'].indexOf(v.stage) < 0; });
        var shown = qState.filter === 'active' ? active : list.filter(function (v) { return v.stage === qState.filter; });
        var chip = function (id, label, n) { return '<button class="chip ' + (qState.filter === id ? 'on' : '') + '" data-act="filter" data-f="' + id + '">' + esc(label) + '<span class="n">' + (n || 0) + '</span></button>'; };
        var avg = active.length ? Math.round(U.sum(active, function (v) { return v.totalMin; }) / active.length) : 0;
        var hero = C.hero('Today\u2019s queue', [[active.length, 'In clinic now'], [U.dur(avg), 'Avg time in clinic'], [counts.completed || 0, 'Seen today'], [counts.arrived || 0, 'Waiting']], '<button class="btn on-hero" data-act="checkin">' + K.icon('plus', 'sm') + ' Check in a patient</button>');
        if (K.isWide()) {
          var cols = ['arrived', 'workup', 'dilating', 'doctor', 'counselling', 'optical', 'pharmacy', 'billing'];
          return C.onboard() + hero + '<div class="row between" style="margin:4px 2px 10px"><div class="h2" style="margin:0">' + K.icon('kanban') + ' Board</div><span class="small muted">Tap a card for actions \u00b7 updates live</span></div><div class="kanban">' + cols.map(function (st) {
            var vs = list.filter(function (v) { return v.stage === st; });
            return '<div class="kcol"><div class="kcol-h"><span><span class="dot" style="background:' + K.STAGE_COLOR[st] + '"></span>' + esc(K.stageLabel(st)) + '</span><span class="pill">' + vs.length + '</span></div>' +
              (vs.length ? vs.map(function (v) { return C.qcard(v, { act: 'cardMenu' }); }).join('') : C.empty('Empty', '', 'check')) + '</div>';
          }).join('') + '</div>';
        }
        return C.onboard() + hero +
          '<div class="chips">' + chip('active', 'All active', active.length) + ['arrived', 'workup', 'dilating', 'doctor', 'counselling', 'optical', 'pharmacy', 'billing', 'completed'].map(function (s) { return chip(s, K.stageLabel(s), counts[s]); }).join('') + '</div>' +
          (shown.length ? shown.map(function (v) { return C.qcard(v, { act: 'cardMenu', extra: function (x) { return 'Arrived ' + U.time(x.arrivedAt) + ' · ' + esc(x.doctor ? x.doctor.name : ''); } }); }).join('') : C.empty('No patients in this stage')) +
          (K.isWide() ? '' : '<button class="btn fab" data-act="checkin">' + K.icon('plus') + ' Check in</button>');
      });
    },
    actions: {
      filter: function (el) { qState.filter = el.getAttribute('data-f'); K.refresh(); },
      checkin: function () { K.go('patients/checkin'); },
      cardMenu: function (el) { K.queueMenu(el.getAttribute('data-id')); }
    }
  };

  K.queueMenu = function (id) {
    return K.data.getVisit(id).then(function (v) {
      var html = C.banner(v.patient, v) + '<div class="list">' +
        '<div class="li" data-sact="open"><span class="grow">Open visit</span><span class="chev">' + K.icon('chev', 'sm') + '</span></div>' +
        '<div class="li" data-sact="profile"><span class="grow">Patient profile</span><span class="chev">' + K.icon('chev', 'sm') + '</span></div>' +
        '<div class="li" data-sact="prio"><span class="grow">Priority flags</span><span class="small muted">' + esc(v.priority.map(function (x) { return K.PRIORITY[x]; }).join(', ') || 'None') + '</span></div>' +
        '<div class="li" data-sact="transfer"><span class="grow">Transfer to another doctor</span><span class="small muted">' + esc(v.doctor ? v.doctor.name : '') + '</span></div>' +
        '<div class="li" data-sact="move"><span class="grow">Move to stage…</span><span class="small muted">' + esc(K.stageLabel(v.stage)) + '</span></div>' +
        '<div class="li" data-sact="wa"><span class="grow">WhatsApp: please come to reception</span></div>' +
        '<div class="li" data-sact="call"><span class="grow">Call patient</span><span class="small muted">' + esc(v.patient.phone) + '</span></div>' +
        '<div class="li" data-sact="lwbs"><span class="grow" style="color:var(--crit)">Left without being seen</span></div></div>';
      K.ui.sheet('Token ' + v.token, html, {
        open: function () { K.ui.closeSheet(); K.openVisit(id); },
        profile: function () { K.ui.closeSheet(); K.go('patient/' + v.patientId); },
        prio: function () {
          var cur = v.priority;
          K.ui.sheet('Priority flags', Object.keys(K.PRIORITY).map(function (k) { return '<label class="check"><input type="checkbox" value="' + k + '"' + (cur.indexOf(k) >= 0 ? ' checked' : '') + '> ' + esc(K.PRIORITY[k]) + '</label>'; }).join('') +
            '<p class="small muted">Flags reorder the queue per clinic rules; every change is logged (CT-03-07).</p><button class="btn block" data-sact="save">Save</button>', {
            save: function () {
              var flags = Array.prototype.map.call(K.ui.sheetEl().querySelectorAll('input:checked'), function (x) { return x.value; });
              return K.data.setPriority(id, flags).then(function () { K.ui.closeSheet(); K.ui.toast('Priority updated'); });
            } });
        },
        transfer: function () {
          return K.data.listUsers('doctor').then(function (docs) {
            K.ui.sheet('Transfer', '<label class="f">To doctor</label><select class="input" id="tr-doc">' + docs.map(function (d) { return '<option value="' + d.id + '"' + (d.id === v.doctorId ? ' selected' : '') + '>' + esc(d.name) + '</option>'; }).join('') + '</select>' +
              '<label class="f">Reason (required)</label><input class="input" id="tr-r" placeholder="e.g. retina opinion"><button class="btn block" style="margin-top:12px" data-sact="go">Transfer</button>', {
              go: function () { return K.data.transferVisit(id, document.getElementById('tr-doc').value, document.getElementById('tr-r').value).then(function () { K.ui.closeSheet(); K.ui.toast('Transferred; doctor notified'); }); } });
          });
        },
        move: function () {
          var opts = ['arrived', 'workup', 'doctor', 'counselling', 'optical', 'pharmacy', 'billing', 'completed'];
          K.ui.sheet('Move to stage', '<div class="list">' + opts.map(function (s) { return '<div class="li" data-sact="to" data-s="' + s + '">' + esc(K.stageLabel(s)) + (s === v.stage ? ' (current)' : '') + '</div>'; }).join('') + '</div>', {
            to: function (el) { return K.data.moveVisit(id, el.getAttribute('data-s'), 'Moved by front desk').then(function () { K.ui.closeSheet(); K.ui.toast('Moved to ' + K.stageLabel(el.getAttribute('data-s'))); }); } });
        },
        wa: function () { return K.data.sendMessage(v.patientId, 'reception_call', 'Token ' + v.token + ': please come to the reception desk.').then(function () { K.ui.closeSheet(); K.ui.toast('WhatsApp sent'); }); },
        call: function () { K.native.dial(v.patient.phone); },
        lwbs: function () {
          return K.ui.prompt('Left without being seen', 'Reason', { options: ['Waited too long', 'Emergency at home', 'Will come another day', 'Other'] }).then(function (r) {
            if (r) return K.data.moveVisit(id, 'lwbs', r).then(function () { K.ui.toast('Marked as left'); });
          });
        }
      });
    });
  };

  /* ---------- Doctor: my queue ---------- */
  K.screens.myqueue = {
    title: 'My queue', tab: 'home', root: true, live: true,
    render: function () {
      var me = K.session.user.id;
      return K.data.getQueue().then(function (list) {
        var withMe = list.filter(function (v) { return v.stage === 'doctor' && v.assignee === me; });
        var ready = list.filter(function (v) { return (v.stage === 'doctor' && !v.assignee) || (v.stage === 'dilating' && v.dilationReady); });
        var dil = list.filter(function (v) { return v.stage === 'dilating' && !v.dilationReady; });
        var upcoming = list.filter(function (v) { return ['arrived', 'workup'].indexOf(v.stage) >= 0; });
        var cs = list.filter(function (v) { return v.rx && v.rx.awaitingCountersign; });
        var seen = list.filter(function (v) { return v.signedBy === me; }).length;
        var mine = function (v) { return v.doctorId === me ? '<b>Your patient</b>' : 'Booked with ' + esc(v.doctor ? v.doctor.name : ''); };
        return C.onboard() + C.hero(ready.length ? ready.length + ' patient' + (ready.length > 1 ? 's' : '') + ' ready for you' : 'Your queue is clear', [[ready.length, 'Ready'], [seen, 'Seen today'], [upcoming.length + dil.length, 'Still to come'], [dil.length, 'Dilating']],
            '<button class="btn on-hero" data-act="next" ' + (ready.length ? '' : 'disabled') + '>' + K.icon('users', 'sm') + ' Call next' + (ready.length ? ': ' + esc(ready[0].patient.name) : '') + '</button>') +
          (withMe.length ? '<div class="h2">With you now <span class="count">' + withMe.length + '</span></div>' + withMe.map(function (v) { return C.qcard(v); }).join('') : '') +
          (cs.length ? '<div class="h2">Countersign spectacle Rx</div>' + cs.map(function (v) { return C.qcard(v); }).join('') : '') +
          '<div class="h2">Ready for you <span class="count">' + ready.length + '</span></div>' + (ready.length ? ready.map(function (v) { return C.qcard(v, { extra: mine }); }).join('') : C.empty('Nobody waiting for you', 'Patients appear here after work-up or dilation')) +
          (dil.length ? '<div class="h2">Dilating</div>' + dil.map(function (v) { return C.qcard(v); }).join('') : '') +
          (upcoming.length ? '<div class="h2">In work-up / waiting</div>' + upcoming.map(function (v) { return C.qcard(v, { extra: mine }); }).join('') : '');
      });
    },
    actions: {
      openVisit: function (el) { K.openVisit(el.getAttribute('data-id')); },
      next: function () { return K.data.callNext('doctor').then(function (v) { if (!v) { K.ui.toast('No one is ready'); return; } K.native.vibrate(); K.ui.toast('Token ' + v.token + ' called to your room'); K.openVisit(v.id); }); }
    }
  };

  /* ---------- Optometrist: work-up queue ---------- */
  K.screens.workup = {
    title: 'Work-up queue', tab: 'home', root: true, live: true,
    render: function () {
      var me = K.session.user.id;
      return K.data.getQueue().then(function (list) {
        var waiting = list.filter(function (v) { return v.stage === 'arrived'; });
        var mine = list.filter(function (v) { return v.stage === 'workup'; });
        var dil = list.filter(function (v) { return v.stage === 'dilating'; });
        return C.onboard() + C.hero(waiting.length ? waiting.length + ' waiting for work-up' : 'Waiting room is clear', [[waiting.length, 'Waiting'], [mine.length, 'In work-up'], [dil.length, 'Dilating']],
            '<button class="btn on-hero" data-act="next" ' + (waiting.length ? '' : 'disabled') + '>' + K.icon('users', 'sm') + ' Call next patient</button>') +
          '<div class="h2">In work-up</div>' + (mine.length ? mine.map(function (v) { return C.qcard(v, { extra: function (x) { return x.assignee === me ? 'With you' : 'With ' + esc(x.assigneeUser ? x.assigneeUser.name : '—'); } }); }).join('') : C.empty('No one in work-up')) +
          '<div class="h2">Dilating</div>' + (dil.length ? dil.map(function (v) { return C.qcard(v, { extra: function (x) { return esc(x.dilation.drops) + ' at ' + U.time(x.dilation.start); } }); }).join('') : C.empty('No one dilating')) +
          '<div class="h2">Waiting</div>' + (waiting.length ? waiting.map(function (v) { return C.qcard(v); }).join('') : C.empty('Waiting room is empty'));
      });
    },
    actions: {
      openVisit: function (el) { K.openVisit(el.getAttribute('data-id')); },
      next: function () { return K.data.callNext('arrived').then(function (v) { if (!v) { K.ui.toast('No one waiting'); return; } K.ui.toast('Token ' + v.token + ' called'); K.openVisit(v.id); }); }
    }
  };

  /* ---------- Owner: today dashboard (CT-14-01..05, 10) ---------- */
  K.screens.dashboard = {
    title: 'Today', tab: 'home', root: true, live: true,
    render: function () {
      return K.data.getDashboard().then(function (d) {
        var lw = d.lastWeek;
        var streams = Object.keys(d.streams).sort(function (a, b) { return d.streams[b] - d.streams[a]; });
        var maxS = Math.max.apply(null, streams.map(function (s) { return d.streams[s]; }).concat([1]));
        var hours = []; for (var h = 8; h <= 20; h++) hours.push(h);
        var maxH = Math.max.apply(null, hours.map(function (h) { return d.byHour[h] || 0; }).concat([1]));
        var fc = d.funnelCataract, fo = d.funnelOptical;
        var fstep = function (label, n, base) { return '<div style="margin:6px 0"><div class="row between small"><span>' + esc(label) + '</span><b>' + n + '</b></div><div class="bar"><i style="width:' + Math.round(n / base * 100) + '%"></i></div></div>'; };
        return C.onboard() + C.hero('Here\u2019s today at ' + (K.session.branch ? K.session.branch.name : 'your clinic'), [[d.patients, 'Patients'], [d.waitingNow, 'Waiting now'], [U.inr(d.collections), 'Collected'], [d.surgeriesDone + '/' + d.surgeriesBooked, 'Surgeries']]) + (d.pendingApprovals ? '<div class="card accent tap" data-act="approvals"><div class="row between"><b class="row">' + K.icon('checkc') + ' ' + d.pendingApprovals + ' approval' + (d.pendingApprovals > 1 ? 's' : '') + ' waiting</b><span class="chev">' + K.icon('chev', 'sm') + '</span></div><div class="small muted">Discounts, refunds, purchase orders</div></div><div style="height:10px"></div>' : '') +
          '<div class="kpis six">' +
          C.kpi('Patients today', d.patients + ' <span class="small muted">(' + d.newPatients + ' new)</span>', C.delta(d.patients, lw.patients), 'queue', 'users') +
          C.kpi('Waiting now', d.waitingNow, '', 'queue', 'clock') +
          C.kpi('Avg wait to doctor', d.avgWait + ' min', C.delta(d.avgWait, lw.avgWait, true), 'steth') +
          C.kpi('Collections', U.inr(d.collections), C.delta(d.collections, lw.collections), 'daybook', 'rupee') +
          C.kpi('Surgeries', d.surgeriesDone + ' / ' + d.surgeriesBooked, '<span class="muted">done / booked today</span>', 'otboard', 'ot') +
          C.kpi('Optical orders', d.opticalOrders + ' · ' + U.inr(d.opticalValue), '', 'opticaljobs', 'glasses') + '</div>' +
          '<div class="grid-wide"><div><div class="h2">Collections by stream</div><div class="card">' + (streams.length ? streams.map(function (s) {
            return '<div style="margin:6px 0"><div class="row between small"><span>' + esc(s) + '</span><b>' + U.inr(d.streams[s]) + '</b></div><div class="bar"><i style="width:' + Math.round(d.streams[s] / maxS * 100) + '%"></i></div></div>';
          }).join('') : C.empty('No collections yet')) + '<div class="small muted" style="margin-top:6px">Outstanding dues: ' + U.inr(d.dues) + '</div></div>' +
          '<div class="h2">Arrivals by hour</div><div class="card"><div class="row" style="align-items:flex-end;height:110px;gap:4px">' + hours.map(function (h) {
            var n = d.byHour[h] || 0; return '<div style="flex:1;text-align:center"><div class="small muted">' + (n || '') + '</div><div style="height:' + Math.round(n / maxH * 80) + 'px;background:linear-gradient(180deg,var(--sky),var(--primary));border-radius:5px 5px 0 0;min-height:' + (n ? 3 : 0) + 'px"></div><div class="small muted">' + (h % 12 || 12) + '</div></div>';
          }).join('') + '</div></div></div>' +
          '<div><div class="h2">Doctors today</div><div class="card"><table class="t"><tr><th>Doctor</th><th class="num">Seen</th><th class="num">Waiting</th><th class="num">Surgery advised</th></tr>' +
          d.doctors.map(function (x) { return '<tr><td>' + esc(x.name) + '</td><td class="num">' + x.seen + '</td><td class="num">' + x.waiting + '</td><td class="num">' + x.surgeriesAdvised + '</td></tr>'; }).join('') + '</table></div>' +
          '<div class="h2">Conversion this month</div><div class="card"><b class="small">Cataract surgery</b>' + fstep('Advised', fc.advised, fc.advised) + fstep('Counselled', fc.counselled, fc.advised) + fstep('Booked', fc.booked, fc.advised) + fstep('Operated', fc.operated, fc.advised) +
          '<div class="hr"></div><b class="small">Spectacle Rx → optical sale</b>' + fstep('Spectacle Rx issued', fo.rx, fo.rx) + fstep('Bought here', fo.sold, fo.rx) +
          '<div class="small muted">' + Math.round(fo.sold / fo.rx * 100) + '% of spectacle prescriptions converted at the clinic’s optical counter.</div></div>' +
          '<div class="h2">Compliance</div><div class="list">' +
          '<div class="li" data-act="audit"><span class="grow">Unsigned visits older than 24 h</span>' + C.pill(d.compliance.unsigned, d.compliance.unsigned ? 'warn' : 'ok') + '</div>' +
          '<div class="li" data-act="audit"><span class="grow">Patients without consent</span>' + C.pill(d.compliance.noConsent, d.compliance.noConsent ? 'crit' : 'ok') + '</div>' +
          '<div class="li" data-act="audit"><span class="grow">Failed logins today</span>' + C.pill(d.compliance.failedLogins, d.compliance.failedLogins ? 'warn' : 'ok') + '</div>' +
          '<div class="li" data-act="audit"><span class="grow">Offline changes waiting to sync</span>' + C.pill(d.compliance.offlinePending, d.compliance.offlinePending ? 'warn' : 'ok') + '</div></div></div></div>' +
          '<p class="small muted">“vs last week” compares with the same weekday last week. Funnel history is demo data plus today’s live activity.</p>';
      });
    },
    actions: {
      approvals: function () { K.go('approvals'); }, queue: function () { K.go('queue'); }, daybook: function () { K.go('report/daybook'); },
      otboard: function () { K.go('ot'); }, opticaljobs: function () { K.go('optical'); }, audit: function () { K.go('audit'); }
    }
  };
})();
