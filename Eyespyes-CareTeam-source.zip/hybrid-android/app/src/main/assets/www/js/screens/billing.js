/* Billing (PRD Epic 12): billing queue, GST bill, discount within limit or approval, UPI QR / cash / card, invoice share */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;

  K.screens.billingq = {
    title: 'Billing', tab: 'home', root: true, live: true,
    render: function () {
      return Promise.all([K.data.listBillingQueue(), K.data.listBills(U.isoDay(K.clock.now()))]).then(function (r) {
        var q = r[0], bills = r[1];
        var open = bills.filter(function (b) { return b.status === 'open'; }), paidT = U.sum(bills, function (b) { return b.paid; });
        return C.onboard() + C.hero(q.length ? q.length + ' at the billing counter' : 'No one waiting to pay', [[q.length, 'At billing'], [U.inr(paidT), 'Collected today'], [open.length, 'Open bills']]) +
          '<div class="h2">Billing queue</div>' + (q.length ? q.map(function (v) { return C.qcard(v, { act: 'bill', extra: function (x) { return 'Bill ' + esc(x.bill.invoiceNo) + ' · ' + U.inr(x.bill.total) + (x.bill.payments.some(function (p) { return p.status === 'pending'; }) ? ' · UPI pending' : ''); } }); }).join('') : C.empty('No one at billing')) +
          '<div class="h2">Today’s bills</div><div class="list">' + bills.slice().reverse().slice(0, 25).map(function (b) {
            return '<div class="li" data-act="openBill" data-id="' + b.id + '"><div class="grow"><b>' + esc(b.patient.name) + '</b><div class="small muted">' + esc(b.invoiceNo) + ' · ' + U.time(b.createdAt) + '</div></div><b>' + U.inr(b.total) + '</b> ' + C.pill(b.status, b.status === 'paid' ? 'ok' : 'warn') + '</div>';
          }).join('') + '</div>';
      });
    },
    actions: {
      bill: function (el) { return K.data.buildBillForVisit(el.getAttribute('data-id')).then(function (b) { K.go('bill/' + b.id); }); },
      openBill: function (el) { K.go('bill/' + el.getAttribute('data-id')); }
    }
  };

  function qr(text) {
    var h = 0; for (var i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) >>> 0;
    var n = 25, s = '', rnd = function () { h ^= h << 13; h >>>= 0; h ^= h >> 17; h ^= h << 5; h >>>= 0; return h % 100; };
    var finder = function (x, y) { return '<rect x="' + x + '" y="' + y + '" width="7" height="7" fill="#000"/><rect x="' + (x + 1) + '" y="' + (y + 1) + '" width="5" height="5" fill="#fff"/><rect x="' + (x + 2) + '" y="' + (y + 2) + '" width="3" height="3" fill="#000"/>'; };
    for (var y = 0; y < n; y++) for (var x = 0; x < n; x++) { var inF = (x < 8 && y < 8) || (x > n - 9 && y < 8) || (x < 8 && y > n - 9); if (!inF && rnd() < 47) s += '<rect x="' + x + '" y="' + y + '" width="1" height="1" fill="#000"/>'; }
    return '<svg viewBox="-2 -2 29 29" width="180" height="180" style="background:#fff;border-radius:8px" role="img" aria-label="UPI QR code (demo)">' + s + finder(0, 0) + finder(n - 7, 0) + finder(0, n - 7) + '</svg>';
  }

  K.screens.bill = {
    title: 'Bill', tab: 'home', noTabs: true, live: true,
    render: function (pr) {
      return K.data.getBill(pr[0]).then(function (b) {
        var sub = U.sum(b.lines, function (l) { return l.rate * l.qty; }), gst = U.sum(b.lines, function (l) { return l.rate * l.qty * (l.gst || 0) / 100; });
        var pending = b.payments.filter(function (p) { return p.status === 'pending'; });
        return C.banner(b.patient) + '<div class="card"><div class="row between"><b>' + esc(b.invoiceNo) + '</b>' + C.pill(b.status, b.status === 'paid' ? 'ok' : 'warn') + '</div>' +
          '<table class="t"><tr><th>Item</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">GST</th></tr>' + b.lines.map(function (l) { return '<tr><td>' + esc(l.desc) + '<div class="small muted">' + esc(l.stream) + '</div></td><td class="num">' + l.qty + '</td><td class="num">' + U.inr(l.rate) + '</td><td class="num">' + (l.gst || 0) + '%</td></tr>'; }).join('') + '</table>' +
          '<table class="t"><tr><td>Subtotal</td><td class="num">' + U.inr(sub) + '</td></tr><tr><td>GST</td><td class="num">' + U.inr(gst) + '</td></tr>' +
          (b.discount ? '<tr><td>Discount <span class="small muted">' + esc(b.discountReason || '') + '</span></td><td class="num">−' + U.inr(b.discount) + '</td></tr>' : '') +
          '<tr><td><b>Total</b></td><td class="num"><b>' + U.inr(b.total) + '</b></td></tr><tr><td>Paid</td><td class="num">' + U.inr(b.paid) + '</td></tr><tr><td><b>Due</b></td><td class="num"><b>' + U.inr(b.due) + '</b></td></tr></table>' +
          (b.discountPending ? '<div class="banner-note">Discount waiting for owner approval</div>' : '') + '</div>' +
          (b.payments.length ? '<div class="h3">Payments</div><div class="list">' + b.payments.map(function (p) { return '<div class="li"><span class="grow">' + esc(p.mode) + ' <span class="small muted">' + U.time(p.ts) + ' ' + esc(p.ref || '') + '</span></span><b>' + U.inr(p.amount) + '</b> ' + C.pill(p.status === 'pending' ? 'awaiting' : 'received', p.status === 'pending' ? 'warn' : 'ok') + '</div>'; }).join('') + '</div>' : '') +
          (pending.length ? '<div class="card" style="text-align:center;margin-top:10px">' + qr(b.invoiceNo + pending[0].amount) + '<div><b>Scan to pay ' + U.inr(pending[0].amount) + '</b></div><div class="small muted">Dynamic UPI QR with the amount filled in. Payment confirms automatically when the gateway calls back (CT-12-03).</div>' +
            '<button class="btn secondary sm" style="margin-top:8px" data-act="simUpi">Demo: simulate payment received</button></div>' : '') +
          (b.status !== 'paid' ? '<div class="btn-row" style="margin-top:12px"><button class="btn ghost" data-act="discount">Discount</button><button class="btn" data-act="pay"' + (b.due <= 0 ? ' disabled' : '') + '>Collect ' + U.inr(b.due) + '</button></div>' : '') +
          '<div class="btn-row" style="margin-top:8px"><button class="btn ghost" data-act="share">Share invoice</button><button class="btn ghost" data-act="print">Print</button></div>';
      });
    },
    actions: {
      discount: function (el, ev, pr) {
        var lim = K.session.settings.discountLimit[K.session.activeRole] || 0;
        K.ui.sheet('Discount', '<p class="small muted">Your limit: ' + (lim > 1e8 ? 'no limit' : U.inr(lim)) + '. Above it, the request goes to the owner’s approvals inbox (CT-12-05).</p><label class="f">Amount (₹)</label><input class="input" id="ds-a" inputmode="numeric"><label class="f">Reason (required)</label><select class="input" id="ds-r"><option>Senior citizen</option><option>Staff family</option><option>Loyal patient</option><option>Camp patient</option><option>Doctor’s instruction</option></select><button class="btn block" style="margin-top:12px" data-sact="ok">Apply</button>', {
          ok: function () { return K.data.applyDiscount(pr[0], document.getElementById('ds-a').value, document.getElementById('ds-r').value).then(function (r) { K.ui.closeSheet(); K.ui.toast(r.applied ? 'Discount applied' : 'Above your limit — sent to owner for approval'); K.refresh(); }); } });
      },
      pay: function (el, ev, pr) {
        return K.data.getBill(pr[0]).then(function (b) {
          K.ui.sheet('Collect payment', '<label class="f">Mode</label>' + C.seg('mode', [['UPI', 'UPI QR'], ['Cash', 'Cash'], ['Card', 'Card'], ['Link', 'Pay link']], 'UPI') +
            '<label class="f">Amount (₹)</label><input class="input" id="py-a" inputmode="numeric" value="' + b.due + '" data-nofocus><p class="small muted">Partial payments allowed; dues stay on the patient banner.</p><button class="btn block" data-sact="ok">Continue</button>', {
            ok: function () {
              var s = K.ui.sheetEl(), mode = C.segVal(s, 'mode'), amt = s.querySelector('#py-a').value;
              if (mode === 'Link') return K.data.sendMessage(b.patientId, 'payment_link', 'Pay ' + U.inr(amt) + ' for invoice ' + b.invoiceNo + ': eyespyes.app/pay/' + b.id.slice(-6)).then(function () { return K.data.addPayment(pr[0], { mode: 'UPI', amount: amt, ref: 'link' }); }).then(function () { K.ui.closeSheet(); K.ui.toast('Payment link sent on WhatsApp'); K.refresh(); });
              return K.data.addPayment(pr[0], { mode: mode, amount: amt, ref: mode === 'Card' ? 'POS-' + Math.floor(Math.random() * 1e6) : '' }).then(function () { K.ui.closeSheet(); K.ui.toast(mode === 'UPI' ? 'Show the QR to the patient' : 'Payment recorded'); K.refresh(); });
            } });
        });
      },
      simUpi: function (el, ev, pr) { return K.data.demo.simulateUpiCallback(pr[0]).then(function () { K.native.vibrate(); K.ui.toast('UPI payment confirmed by gateway'); }); },
      share: function (el, ev, pr) { return K.data.getBill(pr[0]).then(function (b) { K.native.share('Invoice ' + b.invoiceNo, 'Invoice ' + b.invoiceNo + ' for ' + b.patient.name + ': ' + U.inr(b.total) + ' (paid ' + U.inr(b.paid) + ')'); }); },
      print: function () { K.ui.toast('Sent to receipt printer (demo)'); }
    }
  };
})();
