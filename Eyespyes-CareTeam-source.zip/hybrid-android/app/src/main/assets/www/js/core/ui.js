/* UI kit: domain constants, feature flags, toast, bottom sheet, shared components */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc;

  /* ---------------- Domain constants ---------------- */
  K.STAGES = [
    { id: 'booked', label: 'Booked' }, { id: 'arrived', label: 'Waiting', role: 'front_desk' }, { id: 'workup', label: 'Work-up', role: 'optometrist' },
    { id: 'dilating', label: 'Dilating', role: 'optometrist' }, { id: 'doctor', label: 'Doctor', role: 'doctor' }, { id: 'investigations', label: 'Tests', role: 'doctor' },
    { id: 'counselling', label: 'Counselling', role: 'counsellor' }, { id: 'optical', label: 'Optical', role: 'optician' }, { id: 'pharmacy', label: 'Pharmacy', role: 'pharmacist' },
    { id: 'billing', label: 'Billing', role: 'billing' }, { id: 'completed', label: 'Done' }, { id: 'lwbs', label: 'Left' }
  ];
  K.stageLabel = function (id) { var s = K.STAGES.filter(function (x) { return x.id === id; })[0]; return s ? s.label : id; };
  K.PRIORITY = { emergency: 'Emergency', postop: 'Post-op', child: 'Child', elderly: 'Elderly', vip: 'VIP' };
  K.JOB_STATUS = { ordered: 'Ordered', in_lab: 'In lab', received: 'Received / QC', ready: 'Ready', delivered: 'Delivered', remake: 'Remake' };
  K.OT_STATUS = { scheduled: 'Scheduled', preop_ready: 'Pre-op ready', in_holding: 'In holding', in_ot: 'In OT', recovery: 'Recovery', completed: 'Completed' };
  K.VA = ['6/5', '6/6', '6/9', '6/12', '6/18', '6/24', '6/36', '6/60', '5/60', '3/60', '1/60', 'CF', 'HM', 'PL', 'NPL'];
  K.NEAR = ['N5', 'N6', 'N8', 'N10', 'N12', 'N18', 'N24', 'N36'];

  /* Plan-based feature flags (PRD CT-00-05) */
  var PLAN_ORDER = ['Solo', 'Clinic', 'Hospital', 'Enterprise'];
  var FEATURE_MIN = { counselling: 'Clinic', recall: 'Clinic', lab: 'Clinic', multiDoctor: 'Clinic', ipd: 'Hospital', ot: 'Hospital', pharmacy: 'Hospital', roleAccess: 'Hospital', multiBranch: 'Enterprise', bi: 'Enterprise' };
  K.has = function (feature) { var plan = K.session ? K.session.plan : 'Hospital'; var need = FEATURE_MIN[feature]; return !need || PLAN_ORDER.indexOf(plan) >= PLAN_ORDER.indexOf(need); };
  K.PLANS = PLAN_ORDER;

  /* ---------------- Toast ---------------- */
  var ui = K.ui = {};
  var tt;
  ui.toast = function (msg, ms, kind) {
    if (!kind && /^(Signed|Paid|Dispensed|Approved|Saved|Registered|Booked|Delivered|Job card created|Time-out confirmed|Sign-in complete|Imported|Countersigned|Admitted|Discharged|Case closed|Consent saved|Template applied|Moved|Priority updated|Transferred|Payment recorded|Device values confirmed|Copied|Allergies updated|Demo data reset|Back online|QC passed|Dispensed|Estimate sent|Surgery booked|Reminder sent|Sent|Dilation timer started|Discount applied|IOL matches|UPI payment confirmed|Purchase request sent)/.test(msg)) kind = 'success';
    var t = document.getElementById('toast');
    t.className = kind || '';
    t.innerHTML = K.icon(kind === 'error' ? 'alert' : kind === 'success' ? 'checkc' : 'info') + '<span>' + U.esc(msg) + '</span>';
    void t.offsetWidth; t.classList.add('show');
    clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('show'); }, ms || (kind === 'error' ? 4200 : 2600));
  };
  ui.ok = function (msg) { ui.toast(msg, 2600, 'success'); };
  ui.error = function (e) { ui.toast(e && e.message ? e.message : String(e), 4200, 'error'); K.native.vibrate(60); };

  /* ---------------- Bottom sheet ---------------- */
  var sheetActions = {}, sheetOnClose = null;
  ui.sheet = function (title, html, actions, onClose) {
    var s = document.getElementById('sheet'), b = document.getElementById('sheet-backdrop');
    s.innerHTML = '<div class="sheet-h"><h3>' + esc(title) + '</h3><button class="icon-btn" data-sact="__close" aria-label="Close">' + K.icon('x') + '</button></div><div class="sheet-body">' + html + '</div>';
    sheetActions = actions || {}; sheetOnClose = onClose || null;
    s.hidden = false; b.hidden = false;
    var f = s.querySelector('input,select,textarea'); if (f && !f.hasAttribute('data-nofocus')) setTimeout(function () { try { f.focus(); } catch (e) { /* ignore */ } }, 50);
    return s;
  };
  ui.closeSheet = function () {
    var s = document.getElementById('sheet'); if (s.hidden) return false;
    s.hidden = true; document.getElementById('sheet-backdrop').hidden = true; s.innerHTML = '';
    var cb = sheetOnClose; sheetOnClose = null; sheetActions = {}; if (cb) cb();
    return true;
  };
  ui.sheetEl = function () { return document.getElementById('sheet'); };
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-sact]');
    if (el) { var a = el.getAttribute('data-sact'); if (a === '__close') ui.closeSheet(); else if (sheetActions[a]) { ev.preventDefault(); safe(sheetActions[a], el, ev); } return; }
    if (ev.target.id === 'sheet-backdrop') ui.closeSheet();
  });
  /* Runs an action; while its promise is pending the tapped control shows a spinner and ignores taps (no double submits) */
  function safe(fn, el, ev) {
    try {
      var r = fn(el, ev);
      if (r && r.then) {
        var b = el && el.closest ? el.closest('.btn, .chip, .role-card, .li, .card.tap, .kpi') : null;
        var cls = b && b.classList.contains('btn') ? 'busy' : 'busy-dim';
        if (b) { b.classList.add(cls); b.setAttribute('aria-busy', 'true'); }
        var done = function () { if (b) { b.classList.remove(cls); b.removeAttribute('aria-busy'); } };
        r.then(done, function (e) { done(); ui.error(e); });
      }
    } catch (e) { ui.error(e); console.error(e); }
  }
  ui.safe = safe;

  ui.confirm = function (title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var done = false;
      ui.sheet(title, '<p>' + esc(text) + '</p><div class="btn-row"><button class="btn ghost" data-sact="no">Cancel</button><button class="btn ' + (danger ? 'danger' : '') + '" data-sact="yes">' + esc(okLabel || 'OK') + '</button></div>',
        { yes: function () { done = true; ui.closeSheet(); resolve(true); }, no: function () { done = true; ui.closeSheet(); resolve(false); } },
        function () { if (!done) resolve(false); });
    });
  };
  ui.prompt = function (title, label, opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var done = false;
      var input = opts.options ? '<select class="input" id="pr-val">' + opts.options.map(function (o) { return '<option>' + esc(o) + '</option>'; }).join('') + '</select>'
        : opts.multiline ? '<textarea class="input" id="pr-val" placeholder="' + esc(opts.placeholder || '') + '">' + esc(opts.value || '') + '</textarea>'
        : '<input class="input" id="pr-val" type="' + (opts.type || 'text') + '" value="' + esc(opts.value || '') + '" placeholder="' + esc(opts.placeholder || '') + '">';
      ui.sheet(title, '<label class="f">' + esc(label) + '</label>' + input + (opts.help ? '<p class="small muted">' + esc(opts.help) + '</p>' : '') +
        '<div class="btn-row" style="margin-top:12px"><button class="btn ghost" data-sact="no">Cancel</button><button class="btn" data-sact="ok">' + esc(opts.ok || 'Save') + '</button></div>',
        { ok: function () { var v = document.getElementById('pr-val').value; if (opts.required && !String(v).trim()) { ui.toast('This field is required'); return; } done = true; ui.closeSheet(); resolve(v); },
          no: function () { done = true; ui.closeSheet(); resolve(null); } }, function () { if (!done) resolve(null); });
    });
  };

  /* ---------------- Components ---------------- */
  var C = K.c = {};
  C.avatar = function (name) { return '<div class="avatar" aria-hidden="true">' + esc(U.initials(name)) + '</div>'; };
  C.pill = function (text, kind) { return '<span class="pill ' + (kind ? 'pill-' + kind : '') + '">' + esc(text) + '</span>'; };
  C.flags = function (p, v) {
    if (!p) return '';
    var out = [];
    (p.allergies || []).forEach(function (a) { out.push(C.pill('Allergy: ' + a, 'crit')); });
    if (p.flags && p.flags.diabetic) out.push(C.pill('Diabetic', 'warn'));
    if (p.flags && p.flags.glaucoma) out.push(C.pill('Glaucoma', 'info'));
    if (p.flags && p.flags.cl) out.push(C.pill('CL wearer', 'info'));
    if (v && v.priority) v.priority.forEach(function (x) { out.push(C.pill(K.PRIORITY[x] || x, x === 'emergency' ? 'crit' : 'brand')); });
    if (p.payer && p.payer !== 'Self') out.push(C.pill(p.payer, ''));
    if (p.abha) out.push(C.pill('ABHA linked', 'ok'));
    return out.join(' ');
  };
  C.ageSex = function (p) { return p ? (U.age(p.dob) + ' y · ' + p.sex) : ''; };
  /* Patient banner (PRD CT-02-05): on every clinical screen */
  C.banner = function (p, v) {
    if (!p) return '';
    return '<div class="banner">' + C.avatar(p.name) + '<div class="grow"><div class="row between"><b class="ellipsis">' + esc(p.name) + '</b>' +
      (v ? '<span class="pill pill-brand">Token ' + esc(v.token) + '</span>' : '') + '</div>' +
      '<div class="small muted">' + C.ageSex(p) + ' · ' + esc(p.uhid) + ' · ' + esc(p.phone) + '</div><div class="flags">' + C.flags(p, v) + '</div></div></div>';
  };
  C.waitClass = function (m) { var s = K.session ? K.session.settings : { waitAmber: 30, waitRed: 60 }; return m >= s.waitRed ? 'wait-crit' : m >= s.waitAmber ? 'wait-warn' : 'wait-ok'; };
  C.empty = function (text, sub, icon) { return '<div class="empty"><div class="eic">' + K.icon(icon || 'eye', 'lg') + '</div><b>' + esc(text) + '</b>' + (sub ? '<div class="small">' + esc(sub) + '</div>' : '') + '</div>'; };
  K.STAGE_COLOR = { booked: '#94A3B8', arrived: '#F59E0B', workup: '#0EA5E9', dilating: '#6366F1', doctor: '#0277BD', investigations: '#14B8A6', counselling: '#8B5CF6', optical: '#06B6D4', pharmacy: '#10B981', billing: '#F97316', completed: '#16A34A', lwbs: '#DC2626' };
  K.greeting = function () { var h = new Date(K.clock.now()).getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };
  K.firstName = function (n) { n = String(n || ''); return /^Dr\. /.test(n) ? 'Dr. ' + n.split(' ')[1] : n.split(' ')[0]; };
  /* Greeting hero used on every role home: stats = [[value, label], ...] */
  C.hero = function (title, stats, action, hi) {
    var d = new Date(K.clock.now()), days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var who = K.session ? K.firstName(K.session.user.name) : '';
    return '<section class="hero"><div class="hi">' + esc(hi || (K.greeting() + ', ' + who)) + ' \u00b7 ' + days[d.getDay()] + ' ' + d.getDate() + ' ' + mon[d.getMonth()] + '</div>' +
      '<div class="ht">' + esc(title) + '</div>' +
      (stats && stats.length ? '<div class="stats">' + stats.map(function (s) { return '<div class="stat"><div class="v">' + s[0] + '</div><div class="l">' + esc(s[1]) + '</div></div>'; }).join('') + '</div>' : '') +
      (action ? '<div class="hero-act">' + action + '</div>' : '') + '</section>';
  };
  C.ico = function (name, cls) { return K.icon(name, cls); };
  /* First-run tip on role homes; dismissal remembered on this device */
  C.onboard = function () {
    try { if (localStorage.getItem('eyespyes.tip.done') === '1') return ''; } catch (e) { return ''; }
    return '<div class="tip" id="ob-tip"><span class="ti2">' + K.icon('sparkle') + '</span><div class="grow small"><b>New here?</b> The Demo centre walks one patient through every role in eight taps.</div>' +
      '<button class="btn sm" data-tip="demo">Open</button><button class="icon-btn" data-tip="x" aria-label="Dismiss tip">' + K.icon('x', 'sm') + '</button></div>';
  };
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-tip]'); if (!b) return;
    try { localStorage.setItem('eyespyes.tip.done', '1'); } catch (e) { /* ignore */ }
    var t = document.getElementById('ob-tip'); if (t) t.remove();
    if (b.getAttribute('data-tip') === 'demo') K.go('demo');
  });
  C.stagePill = function (stage) {
    var kind = { arrived: 'warn', workup: 'info', dilating: 'info', doctor: 'brand', counselling: 'brand', optical: 'info', pharmacy: 'info', billing: 'warn', completed: 'ok', lwbs: 'crit' }[stage] || '';
    return C.pill(K.stageLabel(stage), kind);
  };
  C.seg = function (name, options, value) {
    return '<div class="seg" data-seg="' + esc(name) + '">' + options.map(function (o) {
      var val = typeof o === 'string' ? o : o[0], lab = typeof o === 'string' ? o : o[1];
      return '<button type="button" data-val="' + esc(val) + '" class="' + (String(value) === String(val) ? 'on' : '') + '">' + esc(lab) + '</button>';
    }).join('') + '</div>';
  };
  /* Generic seg-control behaviour */
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('.seg button'); if (!b) return;
    var seg = b.parentNode; Array.prototype.forEach.call(seg.children, function (x) { x.classList.remove('on'); }); b.classList.add('on');
    seg.dispatchEvent(new CustomEvent('segchange', { bubbles: true, detail: { name: seg.getAttribute('data-seg'), value: b.getAttribute('data-val') } }));
  });
  C.segVal = function (root, name) { var b = root.querySelector('[data-seg="' + name + '"] button.on'); return b ? b.getAttribute('data-val') : null; };

  /* Stepper for dioptres / axis / IOP (PRD CT-04-04): no keyboard needed */
  C.stepper = function (id, label, value, opts) {
    opts = opts || {};
    var fmt = opts.fmt === 'axis' ? (value === null || value === undefined || value === '' ? '—' : value + '°') : opts.fmt === 'int' ? (value === null || value === undefined || value === '' ? '—' : value) : U.dio(value);
    return '<div class="stepper ' + (opts.cls || '') + '" data-step="' + esc(id) + '" data-min="' + opts.min + '" data-max="' + opts.max + '" data-inc="' + opts.inc + '" data-fmt="' + (opts.fmt || 'dio') + '" data-v="' + (value === null || value === undefined ? '' : value) + '">' +
      '<button type="button" data-d="-1" aria-label="Decrease ' + esc(label) + '">&minus;</button><div class="val"><span class="lbl">' + esc(label) + '</span><span class="vv">' + fmt + '</span></div>' +
      '<button type="button" data-d="1" aria-label="Increase ' + esc(label) + '">+</button></div>';
  };
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('.stepper button'); if (!b) return;
    var s = b.parentNode, d = Number(b.getAttribute('data-d')), inc = Number(s.getAttribute('data-inc')), min = Number(s.getAttribute('data-min')), max = Number(s.getAttribute('data-max'));
    var cur = s.getAttribute('data-v'); cur = cur === '' ? (s.getAttribute('data-fmt') === 'axis' ? 90 - d * 5 : s.getAttribute('data-fmt') === 'int' ? 15 - d : 0) : Number(cur);
    var nv = Math.round((cur + d * inc) * 100) / 100;
    if (s.getAttribute('data-fmt') === 'axis') { if (nv > 180) nv = 5; if (nv < 1) nv = 180; } else { nv = Math.max(min, Math.min(max, nv)); }
    s.setAttribute('data-v', nv); s.classList.remove('copied', 'dev');
    var f = s.getAttribute('data-fmt');
    s.querySelector('.vv').textContent = f === 'axis' ? nv + '°' : f === 'int' ? nv : U.dio(nv);
    s.dispatchEvent(new CustomEvent('stepchange', { bubbles: true, detail: { id: s.getAttribute('data-step'), value: nv } }));
  });
  C.stepVal = function (root, id) { var s = root.querySelector('[data-step="' + id + '"]'); if (!s) return null; var v = s.getAttribute('data-v'); return v === '' ? null : Number(v); };
  C.setStep = function (root, id, value, cls) {
    var s = root.querySelector('[data-step="' + id + '"]'); if (!s) return;
    s.setAttribute('data-v', value === null || value === undefined ? '' : value);
    var f = s.getAttribute('data-fmt'); s.querySelector('.vv').textContent = value === null || value === undefined || value === '' ? '—' : f === 'axis' ? value + '°' : f === 'int' ? value : U.dio(value);
    s.classList.remove('copied', 'dev'); if (cls) s.classList.add(cls);
  };
  C.select = function (id, options, value, placeholder) {
    return '<select class="field-sel" data-field="' + esc(id) + '">' + (placeholder !== undefined ? '<option value="">' + esc(placeholder) + '</option>' : '') +
      options.map(function (o) { return '<option' + (String(o) === String(value) ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>';
  };
  C.fieldVal = function (root, id) { var el = root.querySelector('[data-field="' + id + '"]'); return el ? el.value : null; };
  C.rxText = function (r) { if (!r) return '—'; return U.dio(r.sph) + (r.cyl ? ' / ' + U.dio(r.cyl) + ' × ' + (r.axis || 0) + '°' : ' DS') + (r.add ? ' Add ' + U.dio(r.add) : ''); };
  C.kpi = function (label, value, delta, act, icon) {
    return '<div class="kpi" ' + (act ? 'data-act="' + act + '" role="button" tabindex="0"' : '') + '>' + (icon ? '<span class="ki">' + K.icon(icon, 'sm') + '</span>' : '') + '<div class="l">' + esc(label) + '</div><div class="v">' + value + '</div>' + (delta ? '<div class="d">' + delta + '</div>' : '') + '</div>';
  };
  C.delta = function (now, before, lowerIsBetter) {
    if (!before) return '';
    var diff = now - before, pct = Math.round(diff / before * 100);
    var good = lowerIsBetter ? diff <= 0 : diff >= 0;
    return '<span class="' + (good ? 'up' : 'down') + '">' + (diff >= 0 ? '▲ ' : '▼ ') + Math.abs(pct) + '%</span> <span class="muted">vs last week</span>';
  };
  C.form = function (root) {
    var o = {};
    Array.prototype.forEach.call(root.querySelectorAll('[name]'), function (el) {
      if (el.type === 'checkbox') o[el.name] = el.checked; else o[el.name] = el.value;
    });
    return o;
  };
})();
