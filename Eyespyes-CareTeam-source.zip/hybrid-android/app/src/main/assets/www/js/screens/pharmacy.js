/* Pharmacy & inventory (PRD Epic 8): dispense queue, scan-to-dispense (FEFO, expiry block), stock with alerts, purchase requests */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;

  K.screens.pharmacy = {
    title: 'Pharmacy', tab: 'home', root: true, live: true,
    render: function () {
      return Promise.all([K.data.listDispenseQueue(), K.data.listInventory('drug')]).then(function (r) {
        var q = r[0], low = r[1].filter(function (i) { return i.low; }), exp = r[1].filter(function (i) { return i.nearExpiry; });
        return C.onboard() + C.hero(q.length ? q.length + ' prescription' + (q.length > 1 ? 's' : '') + ' to dispense' : 'Dispense queue is clear', [[q.length, 'To dispense'], [low.length, 'Low stock'], [exp.length, 'Near expiry']], '<button class="btn on-hero" data-act="stock">' + K.icon('box', 'sm') + ' Open stock</button>') +
          '<div class="h2">Dispense queue</div>' + (q.length ? q.map(function (v) { return C.qcard(v, { act: 'disp', extra: function (x) { return x.rx.drugs.map(function (d) { return esc(d.name); }).join(', '); } }); }).join('') : C.empty('No prescriptions waiting')) +
          (low.length ? '<div class="h2">Low stock</div><div class="list">' + low.map(function (i) { return '<div class="li" data-act="po" data-sku="' + i.sku + '"><span class="grow">' + esc(i.name) + '<div class="small muted">' + i.qty + ' left · reorder at ' + i.reorder + '</div></span><span class="btn secondary sm">Request PO</span></div>'; }).join('') + '</div>' : '');
      });
    },
    actions: {
      disp: function (el) { K.go('dispense/' + el.getAttribute('data-id')); },
      stock: function () { K.go('stock'); },
      po: function (el) { return K.poSheet(el.getAttribute('data-sku')); }
    }
  };
  K.poSheet = function (sku) {
    return K.ui.prompt('Purchase request', 'Quantity to order', { type: 'number', value: '30', help: 'Goes to the owner’s approvals inbox (CT-08-06).', ok: 'Send for approval' }).then(function (q) {
      if (q) return K.data.raisePurchase(sku, Number(q)).then(function () { K.ui.toast('Purchase request sent to owner'); });
    });
  };

  var scanned = {};
  K.screens.dispense = {
    title: 'Dispense', tab: 'home', noTabs: true,
    render: function (pr) {
      return Promise.all([K.data.getVisit(pr[0]), K.data.listInventory('drug')]).then(function (r) {
        var v = r[0], inv = r[1];
        if (scanned.id !== v.id) scanned = { id: v.id, ok: {} };
        var lines = v.rx.drugs.map(function (d) {
          var it = inv.filter(function (i) { return i.sku === d.sku; })[0];
          var ok = scanned.ok[d.sku];
          return '<div class="card' + (ok ? '' : ' accent') + '"><div class="row between"><b>' + esc(d.name) + '</b>' + (ok ? C.pill('Scanned', 'ok') : C.pill('Scan to confirm', 'warn')) + '</div>' +
            '<div class="small">' + d.eye + ' · ' + esc(d.freq) + ' · ' + esc(d.duration) + '</div>' +
            '<div class="small muted">Batch ' + esc(it.batch) + ' (FEFO) · exp ' + U.date(it.expiry) + ' · stock ' + it.qty + ' · ' + U.inr(it.price) + '</div>' +
            (it.expired ? C.pill('Batch expired — cannot dispense', 'crit') : it.nearExpiry ? C.pill('Near expiry', 'warn') : '') +
            '<div class="row" style="margin-top:6px"><span class="small">Qty</span><input class="input" style="width:80px" data-field="q_' + d.sku + '" inputmode="numeric" value="' + (d.qty || 1) + '"><button class="btn ghost sm" data-act="tap" data-sku="' + d.sku + '" data-code="' + esc(it.barcode) + '">Simulate scan</button></div></div>';
        }).join('');
        var all = v.rx.drugs.every(function (d) { return scanned.ok[d.sku]; });
        return C.banner(v.patient, v) + '<div class="row"><input class="input grow" id="sc" placeholder="Scan barcode on the pack"><button class="btn" data-act="scan">Scan</button></div><p class="small muted">Scanning each pack confirms the right drug and picks the first-expiring batch (CT-08-02).</p>' + lines +
          '<div class="btn-row" style="margin-top:12px"><button class="btn" data-act="dispense"' + (all ? '' : ' disabled') + '>Dispense and send to billing</button></div>';
      });
    },
    actions: {
      tap: function (el) { document.getElementById('sc').value = el.getAttribute('data-code'); return K.screens.dispense.actions.scan(el, null, K.currentScreen().params); },
      scan: function (el, ev, pr) {
        var code = document.getElementById('sc').value;
        return K.data.lookupBarcode(code).then(function (it) {
          return K.data.getVisit(pr[0]).then(function (v) {
            if (!v.rx.drugs.some(function (d) { return d.sku === it.sku; })) { K.native.vibrate(300); K.ui.toast('Wrong item: ' + it.name + ' is not on this prescription'); return; }
            scanned.ok[it.sku] = true; K.native.vibrate(); K.refresh();
          });
        });
      },
      dispense: function (el, ev, pr) {
        return K.data.getVisit(pr[0]).then(function (v) {
          var root = document.getElementById('content');
          var lines = v.rx.drugs.map(function (d) { return { sku: d.sku, qty: Number(C.fieldVal(root, 'q_' + d.sku)) || 1 }; });
          return K.data.dispense(pr[0], lines).then(function () { K.ui.toast('Dispensed; patient moved to billing'); K.go('pharmacy'); });
        });
      }
    }
  };

  var sState = { type: 'drug', q: '', only: '' };
  K.screens.stock = {
    title: 'Stock', tab: 'more', live: true,
    render: function () {
      return K.data.listInventory(sState.type).then(function (list) {
        var q = sState.q.toLowerCase();
        var shown = list.filter(function (i) { return (!q || i.name.toLowerCase().indexOf(q) >= 0 || String(i.barcode).toLowerCase().indexOf(q) >= 0) && (!sState.only || i[sState.only]); });
        return '<div class="chips">' + [['drug', 'Drugs'], ['frame', 'Frames'], ['lens', 'Lenses'], ['iol', 'IOLs']].map(function (t) { return '<button class="chip ' + (sState.type === t[0] ? 'on' : '') + '" data-act="type" data-t="' + t[0] + '">' + t[1] + '</button>'; }).join('') +
          '<button class="chip ' + (sState.only === 'low' ? 'on' : '') + '" data-act="only" data-o="low">Low</button><button class="chip ' + (sState.only === 'nearExpiry' ? 'on' : '') + '" data-act="only" data-o="nearExpiry">Near expiry</button></div>' +
          '<input class="input" data-change="q" placeholder="Search name or barcode" value="' + esc(sState.q) + '" style="margin-bottom:8px">' +
          '<div class="list">' + (shown.map(function (i) {
            return '<div class="li" data-act="item" data-sku="' + i.sku + '"><div class="grow"><b>' + esc(i.name) + '</b><div class="small muted">' + esc(i.barcode) + (i.batch ? ' · batch ' + esc(i.batch) : '') + (i.expiry ? ' · exp ' + U.date(i.expiry) : '') + (i.consignment ? ' · consignment' : '') + '</div></div>' +
              '<div style="text-align:right"><b>' + i.qty + '</b><div class="small muted">' + U.inr(i.price) + '</div></div>' + (i.low ? C.pill('Low', 'warn') : '') + (i.nearExpiry ? C.pill('Exp', 'crit') : '') + '</div>';
          }).join('') || C.empty('No items')) + '</div>';
      });
    },
    actions: {
      type: function (el) { sState.type = el.getAttribute('data-t'); K.refresh(); },
      only: function (el) { var o = el.getAttribute('data-o'); sState.only = sState.only === o ? '' : o; K.refresh(); },
      q: function (el) { sState.q = el.value; K.refresh(); },
      item: function (el) { if (sState.type === 'drug') return K.poSheet(el.getAttribute('data-sku')); K.ui.toast('Stock adjustments need owner approval (CT-08-08, Phase 3)'); }
    }
  };
})();
