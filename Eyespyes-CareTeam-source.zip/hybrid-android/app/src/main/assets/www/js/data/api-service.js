/* ============================================================================
   API DATA SERVICE — STUB FOR THE DBMS / BACKEND TEAM
   ----------------------------------------------------------------------------
   Every contract method is mapped to the REST route declared in contract.js.
   Path params (":id", ":section", ":name") are filled from the arguments in
   order; the next argument (if an object) becomes the JSON body (POST/PUT/
   PATCH/DELETE) or the query string (GET).

   TO DO for the backend team:
     1. Set K.config.apiBase and switch K.config.dataMode to 'api' in app.js.
     2. Implement the routes against the database (see docs/DATA_CONTRACT.md).
     3. Enforce every rule marked [SERVER RULE] in mock-service.js server-side.
     4. Replace the polling hook with a WebSocket/SSE push for queue updates
        (PRD CT-03-04: < 3 s across devices).
   ========================================================================== */
(function () {
  'use strict';
  var K = window.EYESPYES;

  function buildCall(name, spec) {
    var parts = spec.split(' '), verb = parts[0], path = parts[1] || '';
    if (verb.charAt(0) === '(') return function () { return Promise.reject(new Error(name + ' is client-side only')); };
    return function () {
      var args = Array.prototype.slice.call(arguments), url = path;
      url = url.replace(/:([a-zA-Z]+)/g, function () { return encodeURIComponent(args.length ? args.shift() : ''); });
      url = url.replace(/\?.*$/, '');
      var payload = args.length === 1 && typeof args[0] === 'object' ? args[0] : args.length ? { args: args } : null;
      var opts = { method: verb, headers: { 'Content-Type': 'application/json', 'X-Client': 'eyespyes-careteam-android' } };
      if (K.api.token) opts.headers.Authorization = 'Bearer ' + K.api.token;
      if (payload && verb !== 'GET') opts.body = JSON.stringify(payload);
      if (payload && verb === 'GET') url += '?' + Object.keys(payload).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(payload[k]); }).join('&');
      return fetch(K.config.apiBase + url, opts).then(function (r) {
        if (r.status === 401) { K.bus.emit('auth-expired'); }
        return r.json().catch(function () { return null; }).then(function (body) {
          if (!r.ok) { var e = new Error((body && body.message) || ('HTTP ' + r.status)); e.code = body && body.code; throw e; }
          if (name === 'login' && body && body.token) K.api.token = body.token;
          return body;
        });
      });
    };
  }

  var S = {};
  Object.keys(K.DataContract.methods).forEach(function (name) {
    if (name === 'demo') return;
    S[name] = buildCall(name, K.DataContract.methods[name][0]);
  });
  // Client-side sync state for the real app (offline queue lives on the device)
  S.getSyncState = function () { return Promise.resolve({ online: navigator.onLine, pending: [] }); };
  // Demo controls do not exist in production
  S.demo = null;

  K.api = { token: null };
  K.ApiDataService = S;
})();
