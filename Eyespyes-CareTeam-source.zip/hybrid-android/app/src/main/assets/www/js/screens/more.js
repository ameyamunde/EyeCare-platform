/* More: profile, role/branch switch, reports, recalls, messages, audit, devices, settings, sign out */
(function () {
  'use strict';
  var K = window.EYESPYES, U = K.util, esc = U.esc, C = K.c;

  K.screens.more = {
    title: 'More', tab: 'more', root: true,
    render: function () {
      return K.data.getClinic().then(function (cl) {
        var s = K.session, u = s.user, owner = s.activeRole === 'owner';
        var MI = { dashboard: 'chart', queue: 'kanban', stock: 'box', recalls: 'refresh', optical: 'glasses', ward: 'bed', ot: 'ot', counselling: 'heart', reports: 'file', messages: 'message', audit: 'shield', settings: 'sliders', devices: 'device', demo: 'sparkle', logout: 'logout' };
        var item = function (act, label, sub, show) { return show === false ? '' : '<div class="li" data-act="' + act + '"><span class="lic">' + K.icon(MI[act] || 'chev') + '</span><div class="grow">' + esc(label) + (sub ? '<div class="small muted">' + esc(sub) + '</div>' : '') + '</div><span class="chev">' + K.icon('chev', 'sm') + '</span></div>'; };
        return '<div class="card"><div class="row">' + C.avatar(u.name) + '<div class="grow"><b>' + esc(u.name) + '</b><div class="small muted">' + esc(u.qual || '') + (u.regNo ? ' · Reg. ' + esc(u.regNo) : '') + '</div><div class="small muted">' + esc(cl.name) + ' · ' + esc(s.plan) + ' plan</div></div></div>' +
          (u.roles.length > 1 ? '<label class="f">Active role</label>' + C.seg('role', u.roles.map(function (r) { return [r, K.ROLES[r]]; }), s.activeRole) : '') +
          (u.branches.length > 1 ? '<label class="f">Branch</label>' + C.seg('branch', u.branches.map(function (b) { var br = cl.branches.filter(function (x) { return x.id === b; })[0]; return [b, br.name]; }), s.branchId) : '') + '</div>' +
          '<div class="h3">Work</div><div class="list">' + item('dashboard', 'Today dashboard', 'KPIs, funnels, compliance', owner) + item('queue', 'Queue board', 'All stages, live') + item('stock', 'Stock', 'Drugs, frames, lenses, IOLs') +
          item('recalls', 'Recall worklist', K.has('recall') ? 'Due reminders and call outcomes' : 'Clinic plan and above') + item('optical', 'Optical jobs', '', s.activeRole !== 'optician') + item('ward', 'Ward board', '', K.has('ipd') && s.activeRole !== 'nurse') + item('ot', 'OT board', '', K.has('ot') && s.activeRole !== 'ot') + item('counselling', 'Counselling', '', K.has('counselling') && s.activeRole !== 'counsellor') + '</div>' +
          '<div class="h3">Reports and records</div><div class="list">' + item('reports', 'Reports', 'Day book, GST, stock, implant log…') + item('messages', 'Message log', 'WhatsApp / SMS sent to patients') + item('audit', 'Audit trail', 'Every view, edit, sign and export', owner) + '</div>' +
          '<div class="h3">App</div><div class="list">' + item('settings', 'Settings', 'Theme, dark-room mode, clinic settings') + item('devices', 'My devices', 'Remote logout (CT-01-05)') + item('demo', 'Demo centre', 'Simulators, guided story, API log') + item('logout', 'Sign out') + '</div>' +
          '<p class="small muted" style="text-align:center;margin-top:14px">Eyespyes Care Team · ' + esc(K.native.appInfo().platform) + ' · v' + esc(K.native.appInfo().version) + '</p>';
      });
    },
    mount: function (root) {
      root.addEventListener('segchange', function (e) {
        var d = e.detail;
        if (d.name === 'role') K.data.switchRole(d.value).then(K.reloadSession).then(function () { K.ui.toast('Now working as ' + K.ROLES[d.value]); K.go('home'); });
        if (d.name === 'branch') K.data.switchBranch(d.value).then(K.reloadSession).then(function () { K.ui.toast('Branch switched'); K.refresh(); }).catch(K.ui.error);
      });
    },
    actions: {
      dashboard: function () { K.go('dashboard'); }, queue: function () { K.go('queue'); }, stock: function () { K.go('stock'); }, recalls: function () { K.go('recalls'); },
      optical: function () { K.go('optical'); }, ward: function () { K.go('ward'); }, ot: function () { K.go('ot'); }, counselling: function () { K.go('counselling'); },
      reports: function () { K.go('reports'); }, messages: function () { K.go('messages'); }, audit: function () { K.go('audit'); }, settings: function () { K.go('settings'); },
      devices: function () { K.go('devices'); }, demo: function () { K.go('demo'); },
      logout: function () { return K.ui.confirm('Sign out', 'Sign out of Eyespyes Care Team on this device?', 'Sign out').then(function (ok) { if (ok) return K.data.logout().then(function () { K.session = null; K.go('login', true); }); }); }
    }
  };

  var REPORTS = [['daybook', 'Day book', 'Bills and payments today'], ['collections', 'Collections by mode', 'Cash, UPI, card'], ['gst', 'GST summary', 'Taxable value and GST by rate'],
    ['stock', 'Stock valuation', 'By item type'], ['near_expiry', 'Near expiry', 'Within 90 days'], ['implant_log', 'IOL implant log', 'For recalls and audits'], ['surgery_register', 'Surgery register', 'All OT cases']];
  K.screens.reports = {
    title: 'Reports', tab: 'more',
    render: function () { return Promise.resolve('<div class="list">' + REPORTS.map(function (r) { return '<div class="li" data-act="open" data-r="' + r[0] + '"><div class="grow">' + esc(r[1]) + '<div class="small muted">' + esc(r[2]) + '</div></div><span class="chev">' + K.icon('chev', 'sm') + '</span></div>'; }).join('') + '</div>'); },
    actions: { open: function (el) { K.go('report/' + el.getAttribute('data-r')); } }
  };
  K.screens.report = {
    title: function (pr) { var r = REPORTS.filter(function (x) { return x[0] === pr[0]; })[0]; return r ? r[1] : 'Report'; }, tab: 'more',
    render: function (pr) {
      return K.data.getReport(pr[0]).then(function (r) {
        return '<div class="card" style="overflow-x:auto"><table class="t"><tr>' + r.cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>' + (r.rows.length ? r.rows.map(function (row) { return '<tr>' + row.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') : '<tr><td colspan="' + r.cols.length + '">' + C.empty('No rows') + '</td></tr>') + '</table></div>' +
          '<p class="small muted">Generated ' + U.dateTime(r.generatedAt) + ' · ' + r.rows.length + ' rows</p><div class="btn-row"><button class="btn ghost" data-act="exp" data-f="PDF">Export PDF</button><button class="btn ghost" data-act="exp" data-f="Excel">Export Excel</button></div>';
      });
    },
    actions: { exp: function (el) { K.ui.toast(el.getAttribute('data-f') + ' export is logged in the audit trail (demo: not generated)'); } }
  };

  K.screens.recalls = {
    title: 'Recall worklist', tab: 'more', live: true,
    render: function () {
      if (!K.has('recall')) return Promise.resolve(C.empty('Recalls are part of the Clinic plan', 'Switch plan in the Demo centre'));
      return K.data.listRecalls().then(function (l) {
        return '<p class="small muted">Rules by diagnosis and interval are set by the clinic (CT-13-02). Messages go only to patients with treatment-communication consent.</p><div class="list">' + l.map(function (r) {
          var overdue = r.due < K.clock.now();
          return '<div class="li" data-act="rc" data-id="' + r.id + '"><div class="grow"><b>' + esc(r.patient.name) + '</b><div class="small muted">' + esc(r.rule) + '</div><div class="small ' + (overdue ? 'wait-crit' : 'muted') + '">Due ' + U.date(r.due) + (r.lastContact ? ' · last contact ' + U.date(r.lastContact) : '') + '</div></div>' +
            C.pill(r.status.replace('_', ' '), r.status === 'booked' ? 'ok' : r.status === 'not_reachable' ? 'crit' : r.status === 'sent' ? 'info' : 'warn') + '</div>';
        }).join('') + '</div>';
      });
    },
    actions: {
      rc: function (el) {
        var id = el.getAttribute('data-id');
        return K.data.listRecalls().then(function (l) {
          var r = l.filter(function (x) { return x.id === id; })[0];
          K.ui.sheet(r.patient.name, '<p class="small">' + esc(r.rule) + ' · due ' + U.date(r.due) + '</p><div class="list"><div class="li" data-sact="send">Send WhatsApp reminder</div><div class="li" data-sact="call">Call ' + esc(r.patient.phone) + '</div><div class="li" data-sact="book">Book appointment</div><div class="li" data-sact="nr">Mark not reachable</div></div>', {
            send: function () { return K.data.updateRecall(id, { status: 'sent' }).then(function () { K.ui.closeSheet(); K.ui.toast('Reminder sent'); }); },
            call: function () { K.native.dial(r.patient.phone); },
            book: function () { K.ui.closeSheet(); return K.bookSheet(r.patientId).then(function () { return K.data.updateRecall(id, { status: 'booked' }); }); },
            nr: function () { return K.data.updateRecall(id, { status: 'not_reachable' }).then(function () { K.ui.closeSheet(); }); }
          });
        });
      }
    }
  };

  K.screens.messages = {
    title: 'Message log', tab: 'more', live: true,
    render: function () {
      return Promise.all([K.data.listMessages(), K.data.getClinic()]).then(function (r) {
        var st = r[1].settings;
        return '<div class="card"><div class="row between"><b>WhatsApp quota this month</b><span>' + st.messagesUsed + ' / ' + st.messageQuota + '</span></div><div class="bar" style="margin-top:6px"><i style="width:' + Math.min(100, Math.round(st.messagesUsed / st.messageQuota * 100)) + '%"></i></div><div class="small muted" style="margin-top:4px">Per-message pricing applies; extra messages are charged above the plan quota (CT-13-06).</div></div>' +
          '<div class="list" style="margin-top:10px">' + r[0].slice(0, 80).map(function (m) { return '<div class="li"><div class="grow"><div class="small"><b>' + esc(m.patient ? m.patient.name : '') + '</b> · ' + esc(m.template.replace(/_/g, ' ')) + ' · ' + U.ago(m.ts) + '</div><div class="small">' + esc(m.text) + '</div></div>' + C.pill(m.status, m.status === 'read' ? 'ok' : m.status === 'delivered' ? 'info' : '') + '</div>'; }).join('') + '</div>';
      });
    }
  };

  K.screens.audit = {
    title: 'Audit trail', tab: 'more', live: true,
    render: function () {
      return K.data.listAudit().then(function (l) {
        return '<p class="small muted">Immutable, server-side in production. Shows views, edits, signs, shares, exports and permission changes (PRD section 24).</p><div class="list">' + l.map(function (a) {
          return '<div class="li" style="cursor:default"><div class="grow"><div class="small"><b>' + esc(a.action.replace(/_/g, ' ')) + '</b> · ' + esc(a.entity) + ' ' + esc(a.entityId) + (a.offline ? ' ' + C.pill('offline', 'warn') : '') + '</div><div class="small muted">' + esc(a.user) + (a.role ? ' (' + esc(K.ROLES[a.role] || a.role) + ')' : '') + ' · ' + U.dateTime(a.ts) + '</div>' + (a.detail ? '<div class="small">' + esc(a.detail) + '</div>' : '') + '</div></div>';
        }).join('') + '</div>';
      });
    }
  };

  K.screens.devices = {
    title: 'My devices', tab: 'more',
    render: function () {
      return K.data.listDevices(K.session.user.id).then(function (l) {
        var info = K.native.appInfo();
        return '<div class="card"><b>This device</b><div class="small muted">' + esc(info.device || '') + ' · ' + esc(info.platform) + '</div></div>' + (l.length ? '<div class="list" style="margin-top:10px">' + l.map(function (d) { return '<div class="li"><div class="grow">' + esc(d.name) + '<div class="small muted">Last seen ' + U.ago(d.lastSeen) + (d.shared ? ' · shared device' : '') + '</div></div><button class="btn ghost sm" data-act="wipe">Log out</button></div>'; }).join('') + '</div>' : '') +
          '<p class="small muted">Remote logout clears the local database on that device at its next connection.</p>';
      });
    },
    actions: { wipe: function () { K.ui.toast('Remote logout queued (demo)'); } }
  };

  K.screens.settings = {
    title: 'Settings', tab: 'more',
    render: function () {
      var s = K.session.settings, dark = document.body.classList.contains('dark');
      return Promise.resolve('<div class="card"><label class="check"><input type="checkbox" data-change="dark"' + (dark ? ' checked' : '') + '> Dark-room theme (slit-lamp and fundus rooms)</label>' +
        '<label class="f">Text size</label>' + C.seg('fs', [['14', 'Small'], ['15', 'Default'], ['17', 'Large'], ['19', 'Extra large']], String(parseInt(getComputedStyle(document.documentElement).fontSize, 10) || 15)) + '</div>' +
        '<div class="h3">Clinic settings (edited on web by the admin)</div><div class="card"><table class="t">' +
        [['VA notation', s.vaNotation], ['IOP alert above', s.iopThreshold + ' mmHg'], ['IOP OD–OS difference alert', s.iopDiff + ' mmHg'], ['Default dilation timer', s.dilationMinutes + ' min'], ['Wait amber / red', s.waitAmber + ' / ' + s.waitRed + ' min'], ['Optometrist Rx needs countersign', s.countersignOptomRx ? 'Yes' : 'No'], ['Your discount limit', (s.discountLimit[K.session.activeRole] || 0) > 1e8 ? 'No limit' : U.inr(s.discountLimit[K.session.activeRole] || 0)]]
          .map(function (r) { return '<tr><td class="muted">' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td></tr>'; }).join('') + '</table></div>');
    },
    mount: function (root) { root.addEventListener('segchange', function (e) { if (e.detail.name === 'fs') { document.documentElement.style.fontSize = e.detail.value + 'px'; document.body.style.fontSize = e.detail.value + 'px'; try { localStorage.setItem('eyespyes.fs', e.detail.value); } catch (x) { /* ignore */ } } }); },
    actions: { dark: function (el) { document.body.classList.toggle('dark', el.checked); try { localStorage.setItem('eyespyes.dark', el.checked ? '1' : '0'); } catch (x) { /* ignore */ } } }
  };
})();
