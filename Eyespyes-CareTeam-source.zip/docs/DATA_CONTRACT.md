# Eyespyes Care Team — Data Contract (hand-off to the DBMS / backend team)

The app never talks to a database directly. Every screen calls **one data service** with the
operations listed below. The demo build runs them against an on-device mock
(`js/data/mock-service.js`); production replaces it with `js/data/api-service.js`
(hybrid) or `ApiRepository.kt` (Compose), both already mapped to these routes.

**What the DBMS team owns:** schema, storage, REST API, push channel for the queue,
server-side enforcement of the business rules below, audit storage, backups, retention.

**How to switch the hybrid app to your API:** in `js/app.js` set
`K.config.dataMode = 'api'` and `K.config.apiBase = 'https://<your-host>/v1'`.
For the Compose app set `DATA_MODE` / `API_BASE` in `app/build.gradle.kts`.

Conventions: JSON, UTF-8, timestamps in epoch milliseconds (UTC), money in whole rupees,
IDs are opaque strings, `Authorization: Bearer <token>` after login, errors as
`{ "code": "rule|forbidden|not_found|locked|allergy", "message": "human readable" }` with
HTTP 4xx — the app shows `message` to the user as is.

## 1. Entities

| Entity | Key fields | Notes |
| --- | --- | --- |
| Clinic | id, name, plan (Solo/Clinic/Hospital/Enterprise), branches[], theatres[], settings | settings: vaNotation, iopThreshold, iopDiff, dilationMinutes, waitAmber, waitRed, discountLimit{role:amount}, countersignOptomRx, messageQuota, messagesUsed |
| Branch | id, name, city | |
| User | id, name, roles[], branches[], phone, regNo, qual, special | PIN/OTP handled by auth service; never returned to the app |
| Device | userId, name, lastSeen, shared | Remote logout / wipe (CT-01-05) |
| Patient | id, uhid, name, sex, dob, dobEstimated, phone, city, pincode, abha, allergies[], flags{diabetic,glaucoma,cl,postop}, referral, payer, guardian{name,phone}, consent{treatment,marketing,ts,version,channel}, createdAt | Family = patients sharing `phone` |
| Appointment | id, patientId, doctorId, ts, type (new/review/postop/tele), status (booked/arrived/cancelled), source, doubleBooked | |
| Visit | id, patientId, branchId, token, type, stage, doctorId, assignee, priority[], arrivedAt, stageLog[{stage,ts,by}], dilation{start,minutes,drops,by,done}, exam{…}, examBy{section:userId}, examSource{section:'device'}, diagnoses[{code,name,eye}], rx{…}, services[], billId, signedAt, signedBy, addenda[{ts,by,text,reason}], route{counselling,optical,pharmacy} | One OPD encounter. Stages: booked, arrived, workup, dilating, doctor, investigations, counselling, optical, pharmacy, billing, completed, lwbs |
| Exam (inside Visit) | history, vision{ua,ph,bcva,near per eye}, refraction{auto,final,k,glasses per eye; pd}, iop{method,OD,OS,time}, anterior{OD,OS: lids,conjunctiva,cornea,ac,iris,pupil,lens}, posterior{OD,OS: media,cdr,macula,vessels,periphery,dr}, investigations{ordered[],results{}} | Refraction per eye: sph, cyl (0.25 D), axis 1–180, add |
| Prescription (inside Visit) | drugs[{sku,name,eye,freq,duration,taper[],qty}], spectacle{OD,OS,pd,lensAdvice,coating,validMonths}, cl, advice[], followUpDays, procedure{name,eye,note}, overrides[{sku,reason}], signedAt, signedBy, draftBy, awaitingCountersign | |
| Counselling | id, visitId, patientId, procedure, eye, advisedBy, note, packageId, estimate, status (new/thinking/booked/declined), consent{ts,witness,signature}, surgeryTs, reason | |
| Package | id, name, price, iol, notes | |
| InventoryItem | id, type (drug/frame/lens/iol), name, cls, sku, barcode, batch, expiry, qty, reorder, price, gst, lensType, model, power, serial, consignment | Production: batches as child rows (FEFO) |
| OpticalJob | id, patientId, visitId, rx, frame, lens, measure{pd,fitHeight,a,b,dbl}, status (ordered/in_lab/received/ready/delivered/remake), statusLog[], lab, due, advance, price, qc{OD,OS,pass,issues}, external, deliveredTo, warrantyTill | |
| Bill | id, invoiceNo, visitId, patientId, branchId, lines[{code,desc,rate,qty,stream,gst}], discount, discountReason, discountPending, total, payments[{id,mode,amount,ts,ref,status}], status (open/paid/zero) | UPI payments stay `pending` until the gateway callback |
| Bed | id, ward, label, status (free/occupied/cleaning/reserved/blocked), admissionId | |
| Admission | id, patientId, bedId, admittedAt, surgeonId, packageId, payer, deposit, status, orders[{id,type,text,times[]}], nursing[{ts,by,bp,pulse,sugar,pain,eye,note}], mar[{orderId,time,ts,by,status,note}], discharge{ts,by,summary} | |
| OTCase | id, patientId, admissionId, theatre, ts, surgeonId, anaesthesia, procedure, eye, iolPlan{model,power}, iolImplanted{model,power,serial,code,ts,by}, status (scheduled/preop_ready/in_holding/in_ot/recovery/completed), checklist{preop{…}, signIn, timeOut, signOut}, notes, complications | |
| Approval | id, type (discount/refund/purchase/access), refType, refId, title, detail, amount, requestedBy, ts, status, decidedBy, decidedAt, reason | |
| Notification | id, to[roles], type, title, body, ts, read, ref{screen,id} | |
| Message | id, patientId, channel, template, text, ts, status (sent/delivered/read) | Only with treatment consent |
| Recall | id, patientId, rule, due, status (due/sent/booked/not_reachable), lastContact | |
| AuditEvent | id, ts, userId, role, action, entity, entityId, detail, offline | Immutable, append-only |

## 2. Operations and routes

| Method | Route | Purpose | PRD |
| --- | --- | --- | --- |
| `listDemoUsers` | `GET /auth/demo-users` | Users shown on the demo login screen | CT-01 |
| `login` | `POST /auth/login {phone, pin}` | Mobile + PIN login; returns user + token | CT-01-01 |
| `loginAs` | `POST /auth/login-as {userId}` | Demo only: sign in as a seeded user | Demo |
| `logout` | `POST /auth/logout` | End session | CT-01 |
| `getSession` | `GET /auth/session` | Current user, branch, clinic plan | CT-00-02 |
| `switchBranch` | `POST /auth/branch {branchId}` | Change active branch | CT-00-02 |
| `switchRole` | `POST /auth/role {role}` | Change active role (multi-role users) | CT-00-01 |
| `getClinic` | `GET /clinic` | Clinic profile, plan, branches, settings | CT-00-05 |
| `listUsers` | `GET /users` | Staff directory (doctors, optometrists...) | CT-00 |
| `listDevices` | `GET /users/:id/devices` | Registered devices for remote logout | CT-01-05 |
| `searchPatients` | `GET /patients?q=` | Search by name, mobile, UHID, ABHA | CT-02-04 |
| `getPatient` | `GET /patients/:id` | Patient with flags, allergies, consents | CT-02-05 |
| `findDuplicates` | `POST /patients/duplicates {name, phone, age}` | Possible duplicate patients | CT-02-02 |
| `createPatient` | `POST /patients` | Register patient (+ consent record) | CT-02-01 |
| `updatePatient` | `PATCH /patients/:id` | Edit demographics / flags | CT-02 |
| `listFamily` | `GET /patients/:id/family` | Patients sharing a mobile number | CT-02-03 |
| `getPatientHistory` | `GET /patients/:id/history` | Visits, Rx, bills, jobs, trends | CT-04-09 |
| `listAppointments` | `GET /appointments?date=&doctorId=` | Calendar for a day | CT-03-01 |
| `bookAppointment` | `POST /appointments` | Book / reschedule | CT-03-02 |
| `cancelAppointment` | `DELETE /appointments/:id` | Cancel | CT-03-02 |
| `getQueue` | `GET /queue?branchId=` | All visits today with stage + times | CT-03-04 |
| `checkIn` | `POST /visits {patientId, type, priority}` | Check in, issue token | CT-03-03 |
| `callNext` | `POST /queue/call-next {stage}` | Call next patient for a stage | CT-03-05 |
| `moveVisit` | `POST /visits/:id/stage {stage, reason}` | Move a visit to another stage | CT-03 |
| `setPriority` | `POST /visits/:id/priority {flags}` | Priority flags reorder the queue | CT-03-07 |
| `transferVisit` | `POST /visits/:id/transfer {doctorId, reason}` | Transfer to another doctor | CT-03-08 |
| `getVisit` | `GET /visits/:id` | Visit with exam, Rx, stage log | CT-04 |
| `saveExamSection` | `PUT /visits/:id/exam/:section` | Autosave one exam tab | CT-04-14 |
| `startDilation` | `POST /visits/:id/dilation {drops, minutes}` | Drops instilled, timer starts | CT-03-06 |
| `importDeviceData` | `POST /visits/:id/device-import {device, payload}` | Values from device bridge | CT-04-12 |
| `signVisit` | `POST /visits/:id/sign` | Sign and lock the visit | CT-04-15 |
| `addAddendum` | `POST /visits/:id/addenda {text}` | Post-sign correction | CT-04-15 |
| `listDiagnosisMaster` | `GET /masters/diagnoses` | ICD-coded favourites | CT-05-01 |
| `listDrugMaster` | `GET /masters/drugs` | Drug master | CT-05-03 |
| `listRxTemplates` | `GET /masters/rx-templates` | Smart Rx templates | CT-05-02 |
| `saveRx` | `PUT /visits/:id/rx` | Save prescription draft | CT-05 |
| `signRx` | `POST /visits/:id/rx/sign` | Sign Rx; creates optical lead + pharmacy order | CT-05-10/11 |
| `countersignRx` | `POST /visits/:id/rx/countersign` | Doctor countersigns optometrist spectacle Rx | CT-05-13 |
| `listCounselling` | `GET /counselling` | Counselling queue | CT-06-01 |
| `updateCounselling` | `PATCH /counselling/:id` | Package, estimate, consent, outcome | CT-06 |
| `listPackages` | `GET /masters/packages` | Surgery packages / IOL categories | CT-06-02 |
| `listOpticalJobs` | `GET /optical/jobs?status=` | Job cards | CT-07 |
| `createOpticalJob` | `POST /optical/jobs` | Create job card | CT-07-05 |
| `updateOpticalJob` | `PATCH /optical/jobs/:id` | Status change / QC / delivery | CT-07-06 |
| `lookupBarcode` | `GET /inventory/barcode/:code` | Frame / lens / drug / IOL by barcode | CT-07-02 |
| `listInventory` | `GET /inventory?type=` | Stock by item / batch / expiry | CT-08-03 |
| `listDispenseQueue` | `GET /pharmacy/queue` | Signed drug Rx awaiting dispense | CT-08-01 |
| `dispense` | `POST /pharmacy/dispense {visitId, lines}` | Dispense against Rx (FEFO) | CT-08-02 |
| `raisePurchase` | `POST /purchase-requests` | Raise PO request (goes to approvals) | CT-08-06 |
| `listBillingQueue` | `GET /billing/queue` | Visits with unbilled services | CT-12-01 |
| `getBill` | `GET /bills/:id` | Bill with lines and payments | CT-12 |
| `buildBillForVisit` | `POST /bills/from-visit/:visitId` | Auto-add services to a bill | CT-12-01 |
| `applyDiscount` | `POST /bills/:id/discount {amount, reason}` | Within limit or to approvals | CT-12-05 |
| `addPayment` | `POST /bills/:id/payments {mode, amount, ref}` | Collect payment | CT-12-03 |
| `listBills` | `GET /bills?date=` | Bills for reports | CT-14-07 |
| `listBeds` | `GET /ipd/beds` | Bed board | CT-10-01 |
| `admit` | `POST /ipd/admissions` | Admit to a bed | CT-10-02 |
| `getAdmission` | `GET /ipd/admissions/:id` | Admission with orders, nursing, MAR | CT-10 |
| `addNursingEntry` | `POST /ipd/admissions/:id/nursing` | Vitals / notes | CT-10-05 |
| `recordDose` | `POST /ipd/admissions/:id/mar` | Medication administration | CT-10-06 |
| `discharge` | `POST /ipd/admissions/:id/discharge` | Discharge summary + bed release | CT-10-08 |
| `setBedStatus` | `POST /ipd/beds/:id/status {status}` | Free / cleaning / reserved / blocked | CT-10-01 |
| `listOTCases` | `GET /ot/cases?date=` | OT board | CT-11-01 |
| `getOTCase` | `GET /ot/cases/:id` | Case with checklist and implant | CT-11 |
| `updateOTChecklist` | `PATCH /ot/cases/:id/checklist` | Pre-op / sign-in / time-out / sign-out | CT-11-02/03 |
| `scanIOL` | `POST /ot/cases/:id/iol-scan {code}` | Match implanted IOL to plan | CT-11-04 |
| `setOTStatus` | `POST /ot/cases/:id/status` | Case status change | CT-11 |
| `listNotifications` | `GET /notifications` | Alerts for the current user | CT-13 |
| `markNotificationRead` | `POST /notifications/:id/read` | Mark read | CT-13 |
| `listApprovals` | `GET /approvals?status=` | Approvals inbox | CT-14-04 |
| `decideApproval` | `POST /approvals/:id/decision {approve, reason}` | Approve / reject | CT-14-04 |
| `sendMessage` | `POST /messages {patientId, template, channel}` | WhatsApp / SMS via BSP | CT-13-01 |
| `listMessages` | `GET /messages?patientId=` | Outbound message log | CT-13-01 |
| `listRecalls` | `GET /recalls` | Recall worklist | CT-13-03 |
| `updateRecall` | `PATCH /recalls/:id` | Call outcome | CT-13-03 |
| `getDashboard` | `GET /dashboard?range=&branchId=` | KPI tiles and funnels | CT-14-01 |
| `getReport` | `GET /reports/:name?range=` | Standard report rows | CT-14-07 |
| `listAudit` | `GET /audit?entity=&id=` | Audit trail | Section 24 |
| `getSyncState` | `(client)` | Pending offline writes | CT-04-14 |
| `demo` | `(mock only)` | Simulators: reset, arrivals, device import, payments, clock | Demo |

## 3. Business rules the server must enforce

The mock enforces these on the device for the demo; the backend must enforce them again
(the app can be modified, the server cannot).

1. Permissions by role, branch and plan on every call; forbidden calls return 403 and are audited (CT-00-03, CT-00-05).
2. Patient creation requires treatment-communication consent; marketing consent is separate (DPDP).
3. Signed visits are locked; changes only as addenda with a reason (CT-04-15).
4. Only doctors sign drug prescriptions; a registration number is required; optometrist spectacle Rx needs countersign when the clinic setting is on (CT-05-13).
5. Allergy check on sign: drug name or class in the patient's allergy list blocks signing unless an override reason is supplied; overrides are audited (CT-05-05).
6. Discounts above the user's role limit become approvals; only owner/branch manager can decide (CT-12-05, CT-14-04).
7. UPI payments are confirmed only by the payment-gateway callback, never by the client (CT-12-03).
8. Expired batches cannot be dispensed; FEFO batch selection (CT-08-02).
9. Spectacle job cannot be created from an unsigned Rx; QC failure blocks "ready" (CT-07-07).
10. OT: sign-in needs a complete pre-op checklist or a surgeon override with reason; time-out needs patient, procedure, eye and IOL confirmed; scanned IOL must match the planned model and power; case cannot close without sign-out and implant log (CT-11-02/03/04).
11. Discharge summary signed by a doctor; bed goes to cleaning; post-op review auto-booked (CT-10-08).
12. Messages only to patients with treatment consent; marketing only with marketing consent (CT-13-01/05).
13. Every view, edit, sign, share, export, approval and permission change writes an AuditEvent.

## 4. Real-time and offline

- Queue, inbox badge and OT board need push updates (WebSocket or SSE) within 3 seconds (CT-03-04).
- The app queues writes while offline and replays them in order; the API must accept an
  idempotency key per write (`X-Idempotency-Key`) and report conflicts per field rather than overwrite.
- Host all patient data in India; encrypt at rest; daily backups with tested restore.
