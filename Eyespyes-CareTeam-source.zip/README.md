# Eyespyes Care Team — Android app (demo build + production skeleton)

Built from the *Care Team App PRD* (staff and doctors app for Eyespyes EyeCare).
The database is intentionally **not** built: every screen talks to one data service, and
`docs/DATA_CONTRACT.md` tells the DBMS / backend team exactly what to implement.

| Folder | What it is | Status |
| --- | --- | --- |
| `Eyespyes-CareTeam-demo.apk` | Installable demo app (Android 6.0+), works fully offline with fictional data | Built and signed; UI tested end to end in a phone and tablet viewport |
| `Eyespyes-CareTeam-web.html` | The same app as a single-file web app (desktop sidebar, kanban queue, phone layout); open in any browser or host it | Built with `hybrid-android/build-web.py`; tested at 1440 px and 390 px |
| `hybrid-android/` | Source of the demo APK: native Android shell (Java, WebView) + offline UI (HTML/CSS/JS) + data layer | Builds with `./build-apk.sh` |
| `compose-android/` | Kotlin + Jetpack Compose skeleton for the production app: models, repository contract, mock + API stub, theme, OD/OS steppers, queue, visit, Smart Rx, dashboard, demo screens | **Not compiled here** — open in Android Studio and sync |
| `docs/DATA_CONTRACT.md` | Entities, 80 operations with REST routes, server-side rules, real-time and offline needs | Hand-off to DBMS team |
| `test/smoke.js` | Playwright end-to-end test of the demo UI (20 checks, 36 screenshots) | Passing, 0 JS errors |

## Brand

The official Eyespyes logo is in `brand/`: `eyespyes-logo.png` (full logo, transparent, for light backgrounds), `eyespyes-mark.png` (eye mark only), `icon-512.png` (app icon tile) and the original upload. The app embeds them through `js/core/brand-assets.js` (login, sidebar, phone header, prescription printout, favicon) and the Android launcher icons are generated from `icon-512.png`.

## Design system (v2)

- **Colours:** sky blue + white. Primary `#0277BD` (white text 4.8:1, WCAG AA), strong `#0369A1`, accent sky `#0EA5E9` for gradients and highlights, light sky backgrounds `#F0F9FF` / `#E0F2FE`, navy text `#0F2A43`, logo navy `#0B1F5C` for headings. Eye convention kept: OD red, OS indigo (so it never blends with the brand blue).
- **Layouts:** phone = bottom navigation; tablet (768 px+) = icon rail; web (1200 px+) = full sidebar, search box with `/` shortcut, and the queue board as a kanban by stage.
- **UX:** greeting hero with today's numbers on every role home; global search for patients and actions; buttons show a spinner while saving (no double submits); colour-coded toasts; skeleton loading; stage colour stripe on queue cards; consistent SVG icon set; first-run tip pointing to the Demo centre; dark-room theme and text-size setting.

## Install the demo APK

1. Copy `Eyespyes-CareTeam-demo.apk` to an Android phone or tablet (Android 6.0 or newer).
2. Open it and allow "Install unknown apps" for your file manager when asked.
3. Launch **Eyespyes Care Team** and tap any role card to sign in (or mobile `9000000002`, PIN `1234`).

It is signed with a demo key (`hybrid-android/demo-release.keystore`, password `eyespyesdemo`).
Use your own release key before distributing beyond the team.

## What works in the demo

Every role has its own home screen, and the 5 bottom tabs are Home, Patients, Calendar, Inbox, More.

| Role | Try this |
| --- | --- |
| Front desk | Live queue board with stage filters; register a patient (duplicate check, family on same mobile, DPDP consent); check in and issue a token; priority, transfer, move stage, left-without-being-seen |
| Optometrist | Call next; visit workspace with OD/OS side by side; steppers for sphere/cylinder/axis/add/IOP; auto-refractor, NCT and lensmeter import (outlined until confirmed); copy OD→OS; same as last visit; transpose; start dilation timer; send to doctor; draft spectacle Rx for countersign |
| Doctor | My queue (ready, dilating, upcoming); call next; full exam tabs with autosave and range checks; trends (IOP, VA, CDR per eye); Smart Rx: ICD diagnosis with laterality, templates, taper builder, allergy block with override reason, spectacle Rx, advice, procedure advised, follow-up; sign and route; bilingual printout; share; addendum after signing |
| Counsellor | Package comparison, WhatsApp estimate, on-screen signature consent, book surgery (creates OT case) |
| Optician | New spectacle Rx leads; job card with frame barcode, lens filtered by advice, measurements; lab status; QC with ±0.25 D tolerance; remake; delivery with warranty |
| Pharmacist | Dispense queue; scan each pack (wrong item rejected); FEFO batch; expiry block; low-stock alerts; purchase request to owner |
| Billing | Bill built from the visit; GST; discount within limit or sent for approval; UPI QR (confirmed by simulated gateway callback), cash, card, payment link; invoice share |
| Nurse | Ward board; admit; medication administration record per dose; nursing chart; discharge (doctor) |
| OT coordinator | OT board by day and theatre; pre-op checklist; sign-in / time-out / sign-out; IOL barcode must match plan (mismatch shows STOP); implant log; close case books post-op review |
| Owner | Today dashboard with deltas vs last week, collections by stream, arrivals by hour, doctors, cataract and optical funnels, compliance panel; approvals inbox; reports (day book, collections, GST, stock, near expiry, implant log, surgery register); audit trail |

### Demo centre (DEMO button, top right)

- **Guided story:** one walk-in patient through 7 roles in 8 taps — check-in, device work-up, dilation, doctor Rx, optical job, dispensing, UPI billing, owner dashboard.
- **Simulators:** walk-in arrival, fast-forward 10/20 minutes, UPI callback, critical lab result, lab returns spectacles, go offline / back online (writes queue and sync), dark-room theme.
- **Plan switch:** Solo / Clinic / Hospital / Enterprise to show feature gating.
- **Switch user** without signing out.
- **For the DBMS team:** live API call log (every data-service call with its route and timing), contract viewer, JSON snapshot of the demo data.
- **Reset demo data** (also resets automatically each new day).

## Build the demo APK yourself

```bash
cd hybrid-android
# Debian/Ubuntu tools: apt install android-sdk-platform-23 android-sdk-build-tools dalvik-exchange apksigner zipalign
./build-apk.sh          # -> build/Eyespyes-CareTeam-demo.apk
```

The UI can also be opened directly in a desktop browser: `hybrid-android/app/src/main/assets/www/index.html`.

## Connect a real backend

1. Implement the routes in `docs/DATA_CONTRACT.md`.
2. Hybrid app: in `js/app.js` set `dataMode: 'api'` and `apiBase`. `js/data/api-service.js` already maps every method to its route.
3. Compose app: set `DATA_MODE = "api"` and `API_BASE` in `compose-android/app/build.gradle.kts`, then fill in `ApiRepository.kt`.
4. Enforce the server-side rules in section 3 of the contract; rules are also marked `[SERVER RULE]` in `mock-service.js`.

## Known limits of the demo

- Camera scanning, stylus eye drawing, Bluetooth printing, real WhatsApp/SMS, ABDM, teleconsult video and AI scribe are simulated or marked "production build".
- Device import returns plausible random values.
- Clinical templates and prices are fictional and must be reviewed by the clinic's ophthalmologist before real use.
- The Compose skeleton covers the core flows only and has not been compiled in this environment.
