// Web (desktop) layout screenshots + tablet rail
const { chromium } = require('playwright'); const path = require('path');
const WWW = 'file://' + path.resolve(__dirname, '../hybrid-android/app/src/main/assets/www/index.html');
(async () => {
  const b = await chromium.launch(); const errors = [];
  for (const [w, h, tag] of [[1440, 900, 'web'], [900, 1200, 'tab']]) {
    const page = await (await b.newContext({ viewport: { width: w, height: h } })).newPage();
    page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    const wait = ms => page.waitForTimeout(ms), shot = async n => { await wait(600); await page.screenshot({ path: path.join(__dirname, 'shots', tag + '-' + n + '.png') }); };
    await page.goto(WWW); await page.evaluate(() => localStorage.clear()); await page.reload(); await wait(800);
    await shot('login');
    const as = async id => { await page.evaluate(id => EYESPYES.data.loginAs(id).then(EYESPYES.reloadSession), id); };
    const go = async r => { await page.evaluate(r => EYESPYES.go(r), r); await wait(600); };
    await as('u_desk'); await go('home'); await shot('queue');
    await page.keyboard.press('/'); await wait(400); await page.keyboard.type('ramesh'); await wait(600); await shot('palette'); await page.keyboard.press('Escape');
    await as('u_owner'); await go('dashboard'); await shot('dashboard');
    await as('u_doc1'); await go('visit/v_p01'); await page.click('[data-act=tab][data-t=refraction]'); await wait(500); await shot('visit');
    await go('rx/v_p01'); await shot('rx');
    await as('u_nurse'); await go('ward'); await shot('ward');
  }
  console.log('errors', errors); await b.close();
})();
