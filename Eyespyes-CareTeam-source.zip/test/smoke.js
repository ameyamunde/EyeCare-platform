// Smoke test: drives the hybrid UI in a phone viewport, records JS errors, screenshots key screens.
const { chromium } = require('playwright');
const path = require('path');
const WWW = 'file://' + path.resolve(__dirname, '../hybrid-android/app/src/main/assets/www/index.html');
const OUT = path.resolve(__dirname, 'shots');
require('fs').mkdirSync(OUT, { recursive: true });
const WIDE = process.env.WIDE === '1';

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const wait = ms => page.waitForTimeout(ms);
  const shot = async name => { await wait(450); await page.screenshot({ path: path.join(OUT, name + '.png') }); };
  const go = async r => { await page.evaluate(r => EYESPYES.go(r), r); await wait(500); };
  const as = async id => { await page.evaluate(id => EYESPYES.data.loginAs(id).then(EYESPYES.reloadSession), id); };
  const toastText = () => page.evaluate(() => document.getElementById('toast').textContent);
  const bodyHas = async (txt) => (await page.textContent('#content')).includes(txt);
  const check = async (label, cond) => { if (!cond) errors.push('CHECK FAILED: ' + label); else console.log('ok -', label); };

  await page.goto(WWW); await wait(800);
  await page.evaluate(() => { localStorage.clear(); }); await page.reload(); await wait(800);
  await shot('01-login');
  await check('login shows role cards', await bodyHas('Try a role'));

  // Login via phone + PIN wrong then right
  await page.click('[data-seg=lmode] [data-val=pin]'); await wait(500);
  await page.fill('#lg-pin', '9999'); await page.click('[data-act=login]'); await wait(700);
  await check('wrong PIN rejected', (await toastText()).includes('Wrong PIN'));
  await page.fill('#lg-pin', '1234'); await page.click('[data-act=login]'); await wait(900);
  await check('doctor lands on My queue', (await page.textContent('#top-title')) === 'My queue');
  await shot('02-doctor-myqueue');

  // Front desk queue
  await as('u_desk'); await go('home'); await wait(400);
  await check('front desk home is queue board', (await page.textContent('#top-title')) === 'Queue board');
  await shot('03-frontdesk-queue');
  await page.click('.qcard >> nth=0'); await wait(500); await shot('04-queue-menu'); await page.evaluate(() => EYESPYES.ui.closeSheet());

  // Register patient with duplicate check
  await go('register');
  await page.fill('[name=name]', 'Asha Patil'); await page.fill('[name=phone]', '9822001101'); await page.click('[data-seg=sex] [data-val=F]'); await page.fill('[name=age]', '68');
  await page.click('[data-act=save]'); await wait(700);
  await check('duplicate sheet shown', (await page.textContent('#sheet')).includes('Possible duplicate'));
  await shot('05-duplicate');
  await page.click('[data-sact=new]'); await wait(900);
  await check('check-in sheet after register', (await page.textContent('#sheet')).includes('Check in'));
  await page.click('[data-sact=go]'); await wait(700);
  await shot('06-token');
  await page.click('[data-sact=done]'); await wait(500);

  // Optometrist work-up with device import
  await as('u_opt1'); await go('home');
  await shot('07-workup');
  await page.click('[data-act=next]'); await wait(900);
  await check('visit opened after call next', (await page.textContent('#top-title')) === 'Visit');
  await page.click('[data-act=tab][data-t=refraction]'); await wait(600);
  await page.click('[data-act=device][data-d=autorefractor]'); await wait(1800);
  await check('device banner shown', await bodyHas('auto-refractor are outlined'));
  await shot('08-refraction-device');
  await page.click('[data-act=confirmDevice]'); await wait(600);
  await page.click('[data-act=tab][data-t=iop]'); await wait(600);
  await page.click('[data-act=device][data-d=nct]'); await wait(1800);
  await shot('09-iop');
  await page.click('[data-act=tab][data-t=vision]'); await wait(600);
  await page.selectOption('[data-field=va_ua_OD]', '6/12'); await page.click('[data-act=copyEye]'); await wait(1300);
  await shot('10-vision');
  await page.click('[data-act=toDoctor]'); await wait(900);

  // Doctor: open Asha Patil (v_p01) Smart Rx, template with allergy patient p05
  await as('u_doc1'); await go('home');
  await go('visit/v_p05'); await page.click('[data-act=tab][data-t=plan]'); await wait(600);
  await page.click('[data-act=openRx]'); await wait(900);
  await page.fill('#dxq', 'pseudo'); await wait(600);
  await page.click('[data-act=addDx] >> nth=0'); await wait(600);
  await page.click('[data-act=tpl][data-id=tpl_postcat]'); await wait(600);
  await check('allergy block shown', await bodyHas('Blocked: allergy to Fluoroquinolone'));
  await shot('11-rx-allergy');
  await page.click('[data-act=sign]'); await wait(800);
  await check('sign rejected for allergy', (await toastText()).includes('Allergy'));
  await page.click('[data-act=rmDrug] >> nth=0'); await wait(500);
  await page.click('[data-act=sign]'); await wait(1000);
  await check('rx view after sign', (await page.textContent('#top-title')) === 'Prescription');
  await shot('12-rx-view');

  // Optician
  await as('u_optician'); await go('home'); await shot('13-optical');
  await page.click('[data-act=lead] >> nth=0'); await wait(900);
  await page.click('[data-act=frame] >> nth=0'); await wait(500);
  await page.click('[data-act=lens] >> nth=0'); await wait(500);
  await shot('14-newjob');
  await page.click('[data-act=create]'); await wait(900);
  await check('job created', (await page.textContent('#top-title')) === 'Job card');

  // Pharmacist
  await as('u_pharm'); await go('home'); await shot('15-pharmacy');
  await page.click('[data-act=disp] >> nth=0'); await wait(800);
  const nTap = await page.$$eval('[data-act=tap]', n => n.length);
  for (let i = 0; i < nTap; i++) { await page.click(`[data-act=tap] >> nth=${i}`); await wait(600); }
  await shot('15b-dispense');
  await page.click('[data-act=dispense]'); await wait(900);
  await check('dispensed', (await toastText()).includes('Dispensed'));

  // Billing
  await as('u_bill'); await go('home'); await shot('16-billing');
  await page.click('[data-act=bill] >> nth=0'); await wait(900);
  await page.click('[data-act=discount]'); await wait(400); await page.fill('#ds-a', '2000'); await page.click('[data-sact=ok]'); await wait(700);
  await check('discount to approval', (await toastText()).includes('owner'));
  await page.click('[data-act=pay]'); await wait(500); await page.click('[data-sact=ok]'); await wait(900);
  await shot('17-upi');
  await page.click('[data-act=simUpi]'); await wait(900);

  // Owner
  await as('u_owner'); await go('home'); await shot('18-dashboard');
  await page.evaluate(() => document.getElementById('content').scrollTo(0, 900)); await shot('18b-dashboard-scroll');
  await go('approvals'); await shot('19-approvals');
  await page.click('[data-act=approve] >> nth=0'); await wait(700);

  // Nurse / OT / Counsellor
  await as('u_nurse'); await go('home'); await shot('20-ward');
  await go('admission/adm_2'); await shot('21-admission');
  await as('u_ot'); await go('home'); await shot('22-otboard');
  await go('otcase/ot_2'); await wait(300);
  await page.click('[data-act=signIn]'); await wait(600);
  for (const id of ['#to-p', '#to-pr', '#to-e', '#to-i']) await page.check(id);
  await page.click('[data-act=timeOut]'); await wait(700);
  await page.click('[data-act=fill] >> nth=1'); await page.click('[data-act=scan]'); await wait(700);
  await check('IOL mismatch blocked', await bodyHas('STOP.'));
  await shot('23-iol-mismatch');
  await page.click('[data-act=fill] >> nth=0'); await page.click('[data-act=scan]'); await wait(800);
  await page.click('[data-act=signOut]'); await wait(800); await page.click('[data-act=complete]'); await wait(800);
  await check('OT case completed', await bodyHas('Completed'));
  await as('u_couns'); await go('home'); await shot('24-counselling');
  await page.click('[data-act=open] >> nth=0'); await wait(900); await shot('25-counsel');

  // Patients, calendar, inbox, more
  await as('u_desk'); await go('patient/p02'); await page.click('[data-act=tab][data-t=trends]'); await wait(700); await shot('26-trends');
  await go('calendar'); await shot('27-calendar');
  await page.click('[data-act=book]'); await wait(800); await shot('28-book');
  await page.evaluate(() => EYESPYES.ui.closeSheet());
  await as('u_doc1'); await go('inbox'); await shot('29-inbox');
  await go('more'); await shot('30-more');
  for (const r of ['reports', 'report/daybook', 'report/implant_log', 'recalls', 'messages', 'audit', 'stock', 'settings', 'devices']) { await go(r); }

  // Demo centre: story end to end
  await go('demo'); await shot('31-demo');
  await page.click('[data-act=storyReset]'); await wait(500);
  for (let i = 0; i < 8; i++) {
    await go('demo');
    const btn = await page.$('[data-act=step]'); if (!btn) { errors.push('story step button missing at ' + i); break; }
    await btn.click(); await wait(i === 6 ? 3200 : 2200);
  }
  await go('demo'); await check('story completed', (await page.$$('.step.done')).length === 8);
  await shot('32-demo-story-done');
  await page.click('[data-act=sim][data-s=offline]'); await wait(600);
  await go('queue'); await page.click('.qcard >> nth=0'); await wait(400); await page.evaluate(() => EYESPYES.ui.closeSheet());
  await as('u_desk'); await page.evaluate(() => EYESPYES.data.demo.simulateArrival()); await wait(600);
  await check('offline pill visible', await page.isVisible('#net-pill'));
  await shot('33-offline');
  await go('demo'); await page.click('[data-act=sim][data-s=offline]'); await wait(600);
  await check('back online synced', (await toastText()).includes('synced'));
  await page.click('[data-seg=plan] [data-val=Solo]'); await wait(800);
  await as('u_nurse'); await go('ward'); await check('Solo gates IPD', await bodyHas('Hospital plan'));
  await as('u_owner'); await go('demo'); await page.click('[data-seg=plan] [data-val=Hospital]'); await wait(600);
  await page.click('[data-act=log]'); await wait(500); await shot('34-api-log');

  // Tablet layout
  await page.setViewportSize({ width: 1200, height: 800 });
  await as('u_doc1'); await go('visit/v_p01'); await page.click('[data-act=tab][data-t=refraction]'); await wait(600); await shot('35-tablet-refraction');
  await as('u_owner'); await go('dashboard'); await shot('36-tablet-dashboard');

  console.log('\nERRORS (' + errors.length + '):\n' + errors.join('\n'));
  await browser.close();
  process.exit(errors.length ? 1 : 0);
})();
