// Tests the single-file hosted web build (memory router) in desktop and phone sizes
const { chromium } = require('playwright'); const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '../hybrid-android/build/eyespyes-careteam-web.html');
(async () => {
  const b = await chromium.launch(); const errors = []; let fails = 0;
  const ok = (l, c) => { if (!c) { fails++; errors.push('FAIL ' + l); } else console.log('ok -', l); };
  for (const vp of [{ width: 1440, height: 900 }, { width: 390, height: 844 }]) {
    const page = await (await b.newContext({ viewport: vp })).newPage();
    page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    const wait = ms => page.waitForTimeout(ms);
    await page.goto(FILE); await page.evaluate(() => localStorage.clear()); await page.reload(); await wait(800);
    ok('login rendered ' + vp.width, (await page.textContent('#content')).includes('Try a role'));
    await page.click('[data-act=as][data-id=u_doc1]'); await wait(900);
    ok('hash untouched (memory router)', (await page.evaluate(() => location.hash)) === '');
    ok('doctor home', (await page.textContent('#top-title')) === 'My queue');
    await page.click('.qcard >> nth=0'); await wait(900);
    ok('visit opened', (await page.textContent('#top-title')) === 'Visit');
    await page.click('#btn-back'); await wait(700);
    ok('back returns to queue', (await page.textContent('#top-title')) === 'My queue');
    await page.click('#tabbar [data-tab=patients], #sidebar [data-tab=patients] >> visible=true'); await wait(700);
    ok('patients tab', (await page.textContent('#top-title')) === 'Patients');
    await page.evaluate(() => EYESPYES.go('demo')); await wait(600);
    await page.click('[data-act=storyReset]'); await wait(400);
    for (let i = 0; i < 8; i++) { await page.evaluate(() => EYESPYES.go('demo')); await wait(500); const bt = await page.$('[data-act=step]'); if (!bt) break; await bt.click(); await wait(i === 6 ? 3400 : 2700); }
    await page.evaluate(() => EYESPYES.go('demo')); await wait(600);
    ok('story complete ' + vp.width, (await page.$$('.step.done')).length === 8);
    await page.screenshot({ path: path.join(__dirname, 'shots', 'webbuild-' + vp.width + '.png') });
  }
  console.log('ERRORS', errors); await b.close(); process.exit(fails || errors.length ? 1 : 0);
})();
